import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Mentor {
  id: string;
  name: string;
  role: string;
  courses: number;
  followers: string;
  avatar: string;
}

@Component({
  selector: 'app-mentors',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './mentors.component.html',
  styleUrls: ['./mentors.component.css']
})
export class MentorsComponent {
  mentors: Mentor[] = [
    {
      id: '1',
      name: 'Olivia Smith',
      role: 'UI/UX Designer',
      courses: 18,
      followers: '1200',
      avatar: '👩‍💼'
    },
    {
      id: '2',
      name: 'Mikul',
      role: 'Marketer',
      courses: 24,
      followers: '900',
      avatar: '👨‍💼'
    },
    {
      id: '3',
      name: 'Tahul gokkar',
      role: 'Andrioid Developer',
      courses: 64,
      followers: '1350',
      avatar: '👨‍💻'
    },
    {
      id: '4',
      name: 'Md Sakib',
      role: 'Frontend Developer',
      courses: 85,
      followers: '3400',
      avatar: '👨‍🎨'
    }
  ];
}
