import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-subscription-banner',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './subscription-banner.component.html',
  styleUrls: ['./subscription-banner.component.css']
})
export class SubscriptionBannerComponent {
  daysLeft: number = 5;
  
  onUpgrade(): void {
    // Implement upgrade logic
    console.log('Upgrade to Pro clicked');
  }
}
