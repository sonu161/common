import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Course {
  id: string;
  title: string;
  description: string;
  date: string;
  progress: number;
  icon: string;
  iconBg: string;
  color: string;
}

@Component({
  selector: 'app-courses-in-progress',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './courses-in-progress.component.html',
  styleUrls: ['./courses-in-progress.component.css']
})
export class CoursesInProgressComponent {
  courses: Course[] = [
    {
      id: '1',
      title: 'App Design',
      description: 'Learn App design from our prestigious tutor',
      date: 'Dec 15, 2020',
      progress: 20,
      icon: '🎨',
      iconBg: '#e8d5ff',
      color: '#9b59d0'
    },
    {
      id: '2',
      title: 'Web Design',
      description: 'Finally a comprehensive guide to using sketch for designing',
      date: 'Dec 15, 2020',
      progress: 80,
      icon: '🌐',
      iconBg: '#ffe8d9',
      color: '#ff8c42'
    },
    {
      id: '3',
      title: 'Dashboard',
      description: 'Learn Typography from our beginner-friendly trainer',
      date: 'Dec 15, 2020',
      progress: 50,
      icon: '📊',
      iconBg: '#d9f0ff',
      color: '#4a90e2'
    }
  ];
}
