import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Category {
  id: string;
  name: string;
  courseCount: number;
  icon: string;
  iconBg: string;
}

@Component({
  selector: 'app-categories',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent {
  categories: Category[] = [
    {
      id: '1',
      name: 'UI/UX Design',
      courseCount: 120,
      icon: '🎨',
      iconBg: '#e8d5ff'
    },
    {
      id: '2',
      name: 'Marketing',
      courseCount: 34,
      icon: '📢',
      iconBg: '#ffe8d9'
    },
    {
      id: '3',
      name: 'Development',
      courseCount: 160,
      icon: '💻',
      iconBg: '#d9f0ff'
    },
    {
      id: '4',
      name: 'Business',
      courseCount: 213,
      icon: '📊',
      iconBg: '#d4f4dd'
    }
  ];
}
