import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface MenuItem {
  icon: string;
  label: string;
  active?: boolean;
  badge?: string;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent {
  menuItems: MenuItem[] = [
    { icon: '📚', label: 'Declaration & Claims', active: true },
    { icon: '📝', label: 'Transfer Facility' },
    { icon: '🎓', label: 'Scholarship/Book Grant/Fin. Assist. -SC/ST' },
    { icon: '🛒', label: 'Fin. Assist. -SC/ST' },
    { icon: '📖', label: 'Book Grant -SC/ST' },
    { icon: '👥', label: 'Scholarship -SC/ST' }
  ];

  settingsItems: MenuItem[] = [
    { icon: '👤', label: 'Profile' },
    { icon: '⚙️', label: 'Setting' },
    { icon: '🚪', label: 'Logout' }
  ];
}
