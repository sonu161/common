import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { HeaderComponent } from './components/header/header.component';
import { CoursesInProgressComponent } from './components/courses-in-progress/courses-in-progress.component';
import { CategoriesComponent } from './components/categories/categories.component';
import { MentorsComponent } from './components/mentors/mentors.component';
import { SubscriptionBannerComponent } from './components/subscription-banner/subscription-banner.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    SidebarComponent,
    HeaderComponent,
    CoursesInProgressComponent,
    CategoriesComponent,
    MentorsComponent,
    SubscriptionBannerComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Eduhouse Dashboard';
}
