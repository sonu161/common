abstract class UploadLifeCertEntity{
  uploadLifeCert();
}