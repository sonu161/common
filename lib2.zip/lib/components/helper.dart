import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sidbi_app/app/login/views/login_page.dart';
import 'package:sidbi_app/components/main_button.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import 'package:http/http.dart' as http;

import '../network/app_config.dart';

enum AlertBoxType { Error, Success }

class Helper extends GetxController {
  messageAlert(
      {required String title,
      required String message,
      Color? boxColor,
      required AlertBoxType type,
      Duration? duration}) {
    Get.snackbar("", "",
        backgroundColor:
            type == AlertBoxType.Error ? Colors.red : boxColor ?? Colors.white,
        snackPosition: SnackPosition.BOTTOM,
        margin: EdgeInsets.zero,
        colorText: type == AlertBoxType.Error ? Colors.white : Colors.black,
        titleText: Text(
          "$title",
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 18, color: Colors.white),
        ),
        messageText: Text(
          "$message",
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 15, color: Colors.white),
        ),
        snackStyle: SnackStyle.GROUNDED, onTap: (val) {
      Get.back();
    }, duration: duration ?? Duration(seconds: 5));
  }

  setSharedPrefString({keyName, value}) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(keyName, value);
  }

  getSharedPrefString({keyName}) async {
    final sp = await SharedPreferences.getInstance();
    var val = await sp.getString(keyName);
    return val;
  }

  clearSharedPrefs() async {
    final sp = await SharedPreferences.getInstance();
    sp.clear();
  }

  Future<bool> sharedContaineKey({keyName}) async {
    final sp = await SharedPreferences.getInstance();
    bool check = sp.containsKey(keyName);
    return check;
  }

  appDialogBox(
      {required String title,
      required String message,
      Function()? onTap,
      bool? isCancelable,
      bool? show_confirm}) {
    Get.dialog(
        barrierDismissible: true,
        Dialog(
            backgroundColor: Colors.transparent,
            child: WillPopScope(
                onWillPop: () async => true,
                child: Container(
                    width: MediaQuery.of(Get.context!).size.width / 1.5,
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20)),
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: 10,
                          ),
                          Center(
                            child: Text(
                              "$title",
                              style: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.w700),
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          // Image.asset(AppImage.internetConnection,height:30),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10),
                            child: Text("$message",
                                style: TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.w500)),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Divider(
                            color: Colors.grey.shade100,
                            thickness: 1,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                              child: show_confirm == null ||
                                      show_confirm == true
                                  ? Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Material(
                                          color: Colors.blue.shade50,
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: InkWell(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            onTap: () {
                                              Get.back();
                                            },
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(10.0),
                                              child: Center(
                                                child: Text("Cancel".tr),
                                              ),
                                            ),
                                          ),
                                        ), // cancel btn
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Material(
                                          color: Colors.red,
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: InkWell(
                                            onTap: onTap,
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(10.0),
                                              child: Center(
                                                child: Text(
                                                  "Confirm".tr,
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ), // Ok btn
                                      ],
                                    )
                                  : Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Material(
                                          color: Colors.red,
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          child: InkWell(
                                            onTap: onTap ??
                                                () {
                                                  Get.back();
                                                },
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      20, 10, 20, 10),
                                              child: Center(
                                                child: Text(
                                                  "Ok".tr,
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ), // Ok btn
                                      ],
                                    )),
                          SizedBox(
                            height: 10,
                          ),
                        ])))));
  }

  calenderShow(
      {DateRangePickerController? controller,
      context,
      TextEditingController? textEditingController,
      String? dataformateSet,
      String? dateDivider,
      DateTime? startDate,
      DateTime? endDate}) async {
    var date = await showDatePicker(
      context: context,
      firstDate: startDate ?? DateTime.now().subtract(Duration(days: 18000)),
      lastDate: endDate ?? DateTime.now().add(Duration(days: 365)),
      switchToCalendarEntryModeIcon: Icon(Icons.calendar_month),
      confirmText: "Done",
    );
    if (dataformateSet == null) {
      if (date != null) {
        // var dateF = DateFormat("yyyy-MM-dd hh:mm:ss").parse(date.toString());
        var dateF =
            DateFormat(dataformateSet ?? "yyyy-MM-dd").parse(date.toString());
        var day =
            "${dateF.year}${dateDivider ?? '-'}${dateF.month}${dateDivider ?? '-'}${dateF.day}";
        textEditingController?.text = day.replaceAll("/", " / ");
      }
    } else {
      if (date != null) {
        var dateF = DateFormat(dataformateSet).format(date);
        var day = dateF.toString();
        textEditingController?.text = day.replaceAll("/", " / ");
      }
    }
  }

  showTimePicker() async {
    // var selectedTime = await showTimePicker(
    //   initialTime: TimeOfDay.now(),
    //   context: context,
    //   confirmText: "Done",
    // );
    // var time = "${selectedTime!.hour}";
  }

  postService({url, Map<String, dynamic>? data, bool? tokenRequired}) async {
    try {
      var token = "";
      if (tokenRequired == null || tokenRequired == true) {
        token = await getSharedPrefString(keyName: "token");
      }
      print("$token");
      print("${config?[baseUrl]}$url");
      var dataJson = json.encode(data);
      http.Response res = await http
          .post(Uri.parse("${config?[baseUrl]}$url"),
              body: dataJson,
              headers: tokenRequired == null
                  ? {
                      'Content-Type': 'application/json',
                      'Authorization': "Bearer $token"
                    }
                  : {'Content-Type': 'application/json'})
          .timeout(Duration(seconds: 50));
      var chkData = jsonDecode(res.body);
      print(chkData['status']);
      // if(chkData['status']){
      //
      // }
      return res;
    } on TimeoutException catch (e) {
      Get.back();
      return http.Response('statusCode', 408);
    }
  }

  postFormField(
      {url,
      Map<String, String>? data,
      String? path,
      bool? tokenRequired,
      fileKey,
      List? multifile}) async {
    try {
      print("${config?[baseUrl]}$url");
      // print(data);
      var token = "";
      if (tokenRequired == null || tokenRequired == true) {
        token = await getSharedPrefString(keyName: "token");
        print("Bearer $token");
      }
      var headers = tokenRequired == null
          ? {
              'Content-Type': 'application/json',
              'Authorization': "Bearer $token"
            }
          : {'Content-Type': 'multipart/form-data'};
      var request = http.MultipartRequest(
          'POST',
          // Uri.parse(
          //     'http://172.30.1.235:8080/newretireeportal/indoorHospFormSave'));
          Uri.parse("${config?[baseUrl]}$url"));
      request.fields.addAll(data!);
      if (multifile != null && multifile.length > 0) {
        print("Len ${multifile.length}");
        for (var i = 0; i < multifile.length; i++) {
          print(multifile[i]['fileNmae']);
          request.files.add(await http.MultipartFile.fromPath(
              fileKey ?? '${multifile[i]!['fileName']}',
              "${multifile[i]!['path']}"));
        }
      } else {
        request.files
            .add(await http.MultipartFile.fromPath(fileKey ?? 'file', path!));
      }

      if (tokenRequired == null || tokenRequired == true) {
        request.headers.addAll(headers);
      }
      // print(request.files);
      var response = await request.send();

      // print(response.stream.bytesToString());

      if (response.statusCode == 200) {
        // print(await response.stream.bytesToString());
        return response.stream.bytesToString();
      } else {
        // print(response.reasonPhrase);
      }

      //   var request = http.MultipartRequest(
      //       'POST',
      //       Uri.parse(
      //           'https://retireeportal-uat.sidbi.in/newretireeportal/opdAmount'));
      //   var token = "";
      //   if (tokenRequired == null || tokenRequired == true) {
      //     token = await getSharedPrefString(keyName: "token");
      //     print("Bearer $token");
      //   }
      //   var headers = tokenRequired == null
      //       ? {
      //           'Content-Type': 'application/json',
      //           'Authorization': "Bearer $token"
      //         }
      //       : {'Content-Type': 'multipart/form-data'};
      //   request.fields.addAll(data!);
      //   if (multifile != null && multifile.length > 0) {
      //     print("Len ${multifile.length}");
      //     for (var i = 0; i < multifile.length; i++) {
      //       print(multifile[i]['fileNmae']);
      //       request.files.add(await http.MultipartFile.fromPath(
      //           fileKey ?? '${multifile[i]!['fileName']}',
      //           "${multifile[i]!['path']}"));
      //     }
      //   } else {
      //     request.files
      //         .add(await http.MultipartFile.fromPath(fileKey ?? 'file', path!));
      //   }
      //   request.headers.addAll(headers);

      //   http.StreamedResponse response = await request.send();

      //   if (response.statusCode == 200) {
      //     print(await response.stream.bytesToString());
      //     return await response.stream.bytesToString();
      //   } else {
      //     print(response.reasonPhrase);
      //   }
    } catch (e) {
      print("Error got: $e");
    }
  }

  postNew(
      {url,
      Map<String, String>? data,
      String? path,
      bool? tokenRequired,
      fileKey,
      List? multifile}) async {
    try {
      var token = "";
      if (tokenRequired == null || tokenRequired == true) {
        token = await getSharedPrefString(keyName: "token");
        print("Bearer $token");
      }
      var headers = tokenRequired == null
          ? {
              'Content-Type': 'application/json',
              'Authorization': "Bearer $token"
            }
          : {'Content-Type': 'multipart/form-data'};
      var request =
          http.MultipartRequest('POST', Uri.parse("${config?[baseUrl]}$url"));
      request.fields.addAll(data!);
      if(path != null){
        request.files
          .add(await http.MultipartFile.fromPath(fileKey ?? 'file', path));
      }
      request.headers.addAll(headers);

      http.StreamedResponse response = await request.send();

      if (response.statusCode == 200) {
        // print(await response.stream.bytesToString());
      } else {
        print(response.reasonPhrase);
      }
      return response.stream.bytesToString();
    } catch (e) {
      print("Error get: $e");
    }
  }

  getService(url, {bool? tokenRequired}) async {
    try {
      debugPrint("${config?[baseUrl]}$url");
      var token = "";
      if (tokenRequired == null || tokenRequired == true) {
        token = await getSharedPrefString(keyName: "token");
        print({
          'Content-Type': 'application/json',
          'Authorization': "Bearer $token"
        });
      }
      var res = await http
          .get(Uri.parse("${config?[baseUrl]}$url"),
              headers: tokenRequired == null
                  ? {
                      'Content-Type': 'application/json',
                      'Authorization': "Bearer $token"
                    }
                  : {
                      'Content-Type': 'application/json',
                    })
          .timeout(Duration(seconds: 50));
      var chkData = jsonDecode(res.body);
      // print(chkData);
      return res;
      // }
    } on TimeoutException catch (e) {
      return http.Response('statusCode', 408);
    } catch (e) {
      return http.Response('statusCode', 408);
    }
  }

  getStreamedService({url, body, bool? tokenRequired}) async {
    try {
      var token = "";
      token = await getSharedPrefString(keyName: "token");
      // if (tokenRequired == null || tokenRequired == true) {
      //   token = await getSharedPrefString(keyName: "token");
      //   print({
      //     'Content-Type': 'application/json',
      //     'Authorization': "Bearer $token"
      //   });
      // }
      var headers = tokenRequired == null
          ? {
              'Content-Type': 'application/json',
              'Authorization': "Bearer $token"
            }
          : {'Content-Type': 'application/json'};
      debugPrint("${config?[baseUrl]}$url");
      var request = http.Request('GET', Uri.parse("${config?[baseUrl]}$url"));
      request.body = json.encode(body);
      // if(tokenRequired != null){
      request.headers.addAll(headers);
      // }
      http.StreamedResponse response =
          await request.send().timeout(Duration(seconds: 50));
      if (response.statusCode == 200) {
        return response;
      } else {}
    } on TimeoutException catch (e) {
      return http.Response('statusCode', 408);
    } catch (e) {
      return http.Response('statusCode', 3009);
    }
  }

  postStreamedService({url, body, bool? tokenRequired}) async {
    try {
      var token = "";
      if (tokenRequired == null || tokenRequired == true) {
        token = await getSharedPrefString(keyName: "token");
        print({
          'Content-Type': 'application/json',
          'Authorization': "Bearer $token"
        });
      }
      var headers = tokenRequired == null
          ? {
              'Content-Type': 'application/x-www-form-urlencoded',
              'Authorization': "Bearer $token"
            }
          : {'Content-Type': 'application/json'};
      debugPrint("${config?[baseUrl]}$url");
      var request = http.Request('post', Uri.parse("${config?[baseUrl]}$url"));
      request.body = json.encode(body);
      request.headers.addAll(headers);

      http.StreamedResponse response =
          await request.send().timeout(Duration(seconds: 50));

      if (response.statusCode == 200) {
        // print(await response.stream.bytesToString());
        return response;
      } else {}
    } on TimeoutException catch (e) {
      return http.Response('statusCode', 408);
    } catch (e) {
      return http.Response('statusCode', 3009);
    }
  }

  shaConverter({required String newString}) {
    var bytes = utf8.encode(newString);
    var shaEncryp = sha256.convert(bytes);
    return shaEncryp.toString();
  }

  fullAppLoading() {
    Get.dialog(
        barrierDismissible: false,
        Dialog(
          backgroundColor: Colors.transparent,
          child: PopScope(
            canPop: false,
            onPopInvoked: (val) async => val,
            child: Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(20)),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    child: Transform.scale(
                      scale: 0.3,
                      child: Image.asset("assets/icons/loading4.gif"),
                    ),
                  )
                ],
              ),
            ),
          ),
        ));
  }

  doneDialog({String? msg, onClose}) {
    Get.dialog(
        barrierDismissible: true,
        Dialog(
          backgroundColor: Colors.white,
          child: PopScope(
            canPop: true,
            onPopInvoked: (val) async => val,
            child: Container(
              padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
              decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(20)),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    child: Image.asset(
                      "assets/icons/done.png",
                      width: 100,
                      height: 100,
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    child: Center(
                      child: Text(
                        msg?.tr ?? "Data save successfully".tr,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 17),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Divider(
                    color: Colors.black12,
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                    child: MainButton(
                        buttonLable: "Close",
                        onTap: onClose ?? () => Get.back()),
                  ),
                  // SizedBox(
                  //   height: 10,
                  // ),
                ],
              ),
            ),
          ),
        ));
  }

  downloadPdfFile(
      {year,
      tokenRequired,
      setFileName,
      type,
      url,
      Map<String, String>? data}) async {
    // var userid = await helper.getSharedPrefString(keyName: "userFor");
    // var token = await Helper().getSharedPrefString(keyName: "token");
    var headers;
    var token = "";
    if (tokenRequired == null || tokenRequired == true) {
      token = await getSharedPrefString(keyName: "token");
      headers = {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json'
      };
      print(headers);
    }
    //downloadLifeCertiPDFAdmin/000003/2024
    print("${config?[baseUrl]}$url");
    var request = await http.MultipartRequest(
        type, Uri.parse('${config?[baseUrl]}$url'));
    // request.headers.addAll(headers);
    if (tokenRequired == true || tokenRequired == null) {
      request.headers.addAll(headers);
    }
    if (data != null) {
      request.fields.addAll(data);
    }

    http.StreamedResponse response = await request.send();
    var res = await http.Response.fromStream(response);

    if (res.statusCode == 200) {
      final Directory? appDir = Platform.isAndroid
          ? await getExternalStorageDirectory()
          : await getApplicationDocumentsDirectory();
      var dir = await getExternalStorageDirectory();
      var direct =dir?.path
          .toString()
          .replaceAll("Android/data/com.sidbi.retireesidbiportal/files", "Download");
      print(direct);
      // final String fileName =
      //     "${userid}_${year}.pdf";
      final String fileName = setFileName;
      File file = new File('$direct/$fileName');
      print(file.path);
      if (await file.exists()) {
        await file.create();
      }
      var list = await res.bodyBytes;
      // Uint8List bytes = await Uint8List.fromList(list);
      print(list);
      await file.writeAsBytes(list);
      print(res.statusCode);
      return file;
    } else {
      print(res.reasonPhrase);
    }
  }
}
