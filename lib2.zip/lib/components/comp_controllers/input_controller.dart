import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class InputController extends GetxController{

  var obsecure = false;


  setObsecure({TextEditingController? fieldName}){
  }

  clearInput(TextEditingController tControler) async{
    if(tControler.text == "<"){
      tControler.text = "";
    }
  }
}