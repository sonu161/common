import 'dart:io';

import 'package:get/get.dart';

class FilepickerController extends GetxController {
  removeFile({required File file}) async {
    file.delete();
    refresh();
  }
}
