import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/entities/upload_life_cert_entity/upload_life_cert_entity.dart';

class UploadLifeCertRepo extends UploadLifeCertEntity {
  Helper helper = new Helper();

  @override
  uploadLifeCert({filePath}) async {
    try {
      var logUserid = await helper.getSharedPrefString(keyName: "userid");
      var empName = await helper.getSharedPrefString(keyName: "fullName");
      var dobs = await helper.getSharedPrefString(keyName: "empDOB");
      var addr = await helper.getSharedPrefString(keyName: "empAddress");
      var email = await helper.getSharedPrefString(keyName: "emailId");
      var dataa = {
        "userName":"$empName",
        "userId":"$logUserid",
        "userDOB":"$dobs",
        "userAddress":"$addr",
        "userEmail":"$email",
        "year":new DateTime.now().year.toString(),
        "applicationUsed":"M",
        "message":""
      };
      print(dataa);
      var res = await helper.postFormField(
          url: "lifecertificateFileUpload",
          data: dataa,
          path: filePath,
          fileKey: "file");
      return res;
    } catch (e) {}
  }
}
