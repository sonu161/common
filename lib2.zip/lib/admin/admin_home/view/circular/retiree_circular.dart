import 'package:flutter/Material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/controller/retiree_circular_controller.dart';
import 'package:sidbi_app/admin/admin_home/model/CircularData.dart';
import 'package:sidbi_app/admin/admin_home/view/circular/upload_circular.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/loading.dart';
import 'package:sidbi_app/components/no_data.dart';

import '../../repo/retiree_circular_repo.dart';

class RetireeCircular extends StatelessWidget {
  const RetireeCircular({super.key});

  @override
  Widget build(BuildContext context) {
    return RetireeCircularLoader();
  }
}

class RetireeCircularLoader extends StatefulWidget {
  const RetireeCircularLoader({super.key});

  @override
  State<RetireeCircularLoader> createState() => _RetireeCircularLoaderState();
}

class _RetireeCircularLoaderState extends State<RetireeCircularLoader> {
  showAction({Rx<CircularData>? datas}) {
    showModalBottomSheet(
        isScrollControlled: false,
        context: context,
        backgroundColor: Color(0xffF4F4F4),
        showDragHandle: true,
        builder: (context) {
          return Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                color: Color(0xffF4F4F4),
                borderRadius: BorderRadius.horizontal(
                    left: Radius.circular(10), right: Radius.circular(10))),
            child: Container(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
              child: Column(
                children: [
                  SizedBox(
                    height: 15,
                  ),
                  Container(
                    child: Text(
                      "Select year to filter",
                      style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Container(
                    height: MediaQuery.of(context).size.height / 4,
                    child: GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        childAspectRatio: MediaQuery.of(context).size.width /
                            (MediaQuery.of(context).size.height / 4),
                      ),
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: (){
                            var ctrl = Get.find<RetireeCircularController>();
                            ctrl.filterByYear(year: "${datas?.value.data![index].year}");
                          },
                          child: Chip(
                            label: Text("${datas?.value.data![index].year}"),
                          ),
                        );
                      },
                      itemCount: datas?.value.data!.length,
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  TextButton(
                      onPressed: (){
                        var ctrl = Get.find<RetireeCircularController>();
                        ctrl.filteYear.value = "";
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.clear),
                          Text("Clear")
                        ],
                      )
                  )
                ],
              ),
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: GetX(
          init: RetireeCircularController(),
          builder: (ctrl) {
            return Container(
              margin: EdgeInsets.only(bottom: 10),
              child: Material(
                color: Colors.white,
                elevation: 1,
                child: InkWell(
                  onTap: () {
                    showAction(datas: ctrl.data);
                  },
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(15, 10, 15, 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "${ctrl.filterHint.value}",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Row(
                          children: [
                            Chip(
                              label: Text(
                                "Filter",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold),
                              ),
                              avatar: Icon(
                                Icons.filter_alt_rounded,
                                color: Colors.white,
                              ),
                              backgroundColor:
                                  Theme.of(context).colorScheme.error,
                            ),
                            // SizedBox(
                            //   width: 10,
                            // ),
                            // IconButton(
                            //     style: ButtonStyle(
                            //         backgroundColor: WidgetStateProperty.all(
                            //             Theme.of(context).colorScheme.primary)),
                            //     onPressed: () {},
                            //     icon: Icon(
                            //       Icons.upload,
                            //     ))
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
      body: RefreshIndicator(
        onRefresh: (){
          var ctrl = Get.find<RetireeCircularController>();
          return ctrl.getCircularData();
        },
        child: Container(
          child: GetX(
            init: RetireeCircularController(),
            builder: (ctrl) {
              if(ctrl.loading.value == AppLoadingState.Loading){
                return Center(
                  child: SizedBox(
                    height: 50,
                    width: 50,
                    child: CircularProgressIndicator(),
                  ),
                );
              }
              else if (ctrl.data.value.data == null) {
                  return NoData(
                    refresh: (){
                      ctrl.getCircularData();
                    },
                  );
              }
              else if(ctrl.data.value.data!.length > 0 ||
                    ctrl.data.value.data?.length != null){
                  if(ctrl.filteYear.value == ""){
                    return ListView(
                      padding: EdgeInsets.only(
                          bottom: 70
                      ),
                      children: [
                        ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: ctrl.data.value.data?.length,
                          itemBuilder: (context, index) {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  padding:
                                  EdgeInsets.only(top: 10, bottom: 10, left: 10),
                                  decoration: BoxDecoration(
                                      color: Theme.of(context)
                                          .primaryColor
                                          .withOpacity(0.1)),
                                  child: Row(
                                    children: [
                                      Text(
                                        "${ctrl.data.value.data?[index].year}",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  margin: const EdgeInsets.only(bottom: 10),
                                  decoration: BoxDecoration(color: Colors.white),
                                  child: ListView.builder(
                                    physics: NeverScrollableScrollPhysics(),
                                    shrinkWrap: true,
                                    itemCount: ctrl.data.value.data?[index]
                                        .documentsName!.length,
                                    itemBuilder: (context, ind) {
                                      return Container(
                                        padding: EdgeInsets.only(
                                            top: 5, bottom: 5, left: 10, right: 10),
                                        child: Row(
                                          children: [
                                            Flexible(
                                              child: Row(
                                                children: [
                                                  Image.asset(
                                                    "assets/icons/pdf-icon.png",
                                                    height: 20,
                                                    width: 20,
                                                  ),
                                                  SizedBox(
                                                    width: 15,
                                                  ),
                                                  Flexible(
                                                      child: Text(
                                                          "${ctrl.data.value.data?[index].documentsName![ind]}")),
                                                ],
                                              ),
                                            ),
                                            IconButton(
                                                onPressed: () {
                                                  ctrl.downloadFile(fileName: "${ctrl.data.value.data?[index].documentsName![ind]}");
                                                },
                                                icon: Icon(
                                                  Icons.download,
                                                  color: Theme.of(context)
                                                      .colorScheme
                                                      .primary,
                                                ))
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                // SizedBox(
                                //   height: 0,
                                // ),
                              ],
                            );
                          },
                        ),
                      ],
                    );
                  }else{
                    return ListView(
                      children: [
                        ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: ctrl.data.value.data?.length,
                          itemBuilder: (context, index) {
                            if(ctrl.filteYear.value == "${ctrl.data.value.data?[index].year}"){
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    padding:
                                    EdgeInsets.only(top: 10, bottom: 10, left: 10),
                                    decoration: BoxDecoration(
                                        color: Theme.of(context)
                                            .primaryColor
                                            .withOpacity(0.1)),
                                    child: Row(
                                      children: [
                                        Text(
                                          "${ctrl.data.value.data?[index].year}",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.only(bottom: 10),
                                    decoration: BoxDecoration(color: Colors.white),
                                    child: ListView.builder(
                                      physics: NeverScrollableScrollPhysics(),
                                      shrinkWrap: true,
                                      itemCount: ctrl.data.value.data?[index]
                                          .documentsName!.length,
                                      itemBuilder: (context, ind) {
                                        return Container(
                                          padding: EdgeInsets.only(
                                              top: 5, bottom: 5, left: 10, right: 10),
                                          child: Row(
                                            children: [
                                              Flexible(
                                                child: Row(
                                                  children: [
                                                    Image.asset(
                                                      "assets/icons/pdf-icon.png",
                                                      height: 20,
                                                      width: 20,
                                                    ),
                                                    SizedBox(
                                                      width: 15,
                                                    ),
                                                    Flexible(
                                                        child: Text(
                                                            "${ctrl.data.value.data?[index].documentsName![0]}")),
                                                  ],
                                                ),
                                              ),
                                              IconButton(
                                                  onPressed: () {},
                                                  icon: Icon(
                                                    Icons.download,
                                                    color: Theme.of(context)
                                                        .colorScheme
                                                        .primary,
                                                  ))
                                            ],
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              );
                            }
                          },
                        ),
                      ],
                    );
                  }
              }
              else{
                return LoadingApp();
              }
            },
          ),
        ),
      ),
      floatingActionButton: Container(
        width: 100,
        child: FloatingActionButton(
          onPressed: (){
            Get.to(()=>UploadCircular());
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.upload,
              ),
              SizedBox(
                width: 10,
              ),
              Text(
                "Upload",
                style: TextStyle(
                  fontWeight: FontWeight.bold
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
