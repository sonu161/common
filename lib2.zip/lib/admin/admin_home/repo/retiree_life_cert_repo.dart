import 'dart:io';

import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/entities/admin_home_entiry/retiree_life_cert_entity.dart';
import 'package:http/http.dart' as http;
import 'package:sidbi_app/network/app_config.dart';

class RetireeLifeCertRepo extends RetireeLifeCertEntity {
  Helper helper = new Helper();

  @override
  getLifeCertsList({year}) async {
    try {
      var logUserid = await helper.getSharedPrefString(keyName: "userid");
      var res =
          await helper.getService("getRetireeLifeCerificates/$year/$logUserid");
      return res;
    } catch (e) {}
  }

  @override
  getFinancialYears() async {
    try {
      var logUserid = await helper.getSharedPrefString(keyName: "userid");
      var res = await helper.getService("getFinancialYearList/$logUserid");
      return res;
    } catch (e) {}
  }

  downloadCertificate({fileNames, userid}) async {
    try{
      var adminId = await helper.getSharedPrefString(keyName: "userid");
    // var userid = await helper.getSharedPrefString(keyName: "userFor");
    // var file = await helper.downloadPdfFile(
    //   setFileName: "${fileNames.toString().replaceAll(" ", "_")}.pdf",
    //   url: "downloadLifeCertiPDFAppByFileName/$adminId/$userid/$fileNames",
    //   type: "GET",
    // );

    // return file;
    var url = "${config?[baseUrl]}downloadLifeCertiPDFAppByFileName/$adminId/$userid/$fileNames";
    print(url);
      var token = await helper.getSharedPrefString(keyName: "token");
      var headers = {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json'
      };
      print(headers);
    var request = http.Request(
        'GET',
        Uri.parse(url));

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      final Directory? appDir = Platform.isAndroid
            ? await getExternalStorageDirectory()
            : await getApplicationDocumentsDirectory();
        var dir = await getExternalStorageDirectory();
        print(dir?.path);
        var direct = dir?.path
            .toString()
            .replaceAll("Android/data/com.sidbi.retireesidbiportal/files", "Download");
        final String fileName =
            "${fileNames.toString().replaceAll(" ", "_")}.pdf";
        File file = new File('$direct/$fileName');

        if (await file.exists()) {
          await file.create();
        }
        var list = await response.stream.toBytes();
        // Uint8List bytes = await Uint8List.fromList(list);
        print(list);
        await file.writeAsBytes(list);
        return file;
    } else {
    }
    }catch(e){
      Get.back();
      helper.messageAlert(title: "Error", message: "$e", type: AlertBoxType.Error);
    }
  }
}
