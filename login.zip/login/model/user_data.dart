// To parse this JSON data, do
//
//     final userData = userDataFromJson(jsonString);

import 'dart:convert';

UserData userDataFromJson(String str) => UserData.fromJson(json.decode(str));

String userDataToJson(UserData data) => json.encode(data.toJson());

class UserData {
  String? userId;
  String? password;
  String? captcha;
  String? errorMsg;
  String? orgCaptcha;
  String? requestType;
  String? platform;
  String? version;

  UserData({
    this.userId,
    this.password,
    this.captcha,
    this.errorMsg,
    this.orgCaptcha,
    this.requestType,
    this.platform,
    this.version
  });

  UserData copyWith({
    String? userId,
    String? password,
    String? captcha,
    String? errorMsg,
    String? orgCaptcha,
    String? requestType,
    String? platform,
    String? version

  }) =>
      UserData(
        userId: userId ?? this.userId,
        password: password ?? this.password,
        captcha: captcha ?? this.captcha,
        errorMsg: errorMsg ?? this.errorMsg,
        orgCaptcha: orgCaptcha ?? this.orgCaptcha,
        requestType: requestType ?? this.requestType,
        platform: platform ?? this.platform,
        version: version ?? this.version
      );

  factory UserData.fromJson(Map<String, dynamic> json) => UserData(
    userId: json["userId"],
    password: json["password"],
    captcha: json["captcha"],
    errorMsg: json["errorMsg"],
    orgCaptcha: json["orgCaptcha"],
    requestType: json["requestType"],
    platform: json["platform"],
    version: json["version"],
  );

  Map<String, dynamic> toJson() => {
    "userId": userId,
    "password": password,
    "captcha": captcha,
    "errorMsg": errorMsg,
    "orgCaptcha": orgCaptcha,
    "requestType" : requestType,
    "platform" : platform,
    "version" : version
  };
}
