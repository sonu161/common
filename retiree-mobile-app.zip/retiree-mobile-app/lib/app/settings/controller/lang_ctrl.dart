import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/components/lang_list.dart';
import 'package:sidbi_app/components/presets.dart';

class LangController extends GetxService {
  var useid = "".obs;
  Helper helper = new Helper();
  changeLanguage({languageId}) {
    var langs = Locale(languageId);
    Get.updateLocale(langs);
    helper.setSharedPrefString(keyName: "langId", value: languageId);
  }

  setLanguage() async{
    if(await helper.sharedContaineKey(keyName: "langId")){
      var langid = await helper.getSharedPrefString(keyName: "langId");
      var langs = Locale(langid);

      Get.updateLocale(langs);
    }
  }

  languageList({required Widget data}) {
    Get.bottomSheet(
      backgroundColor: Colors.white,
      enableDrag: true,
      isScrollControlled: true,
      SizedBox(
        height: 300,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: 15,
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                child: Text(
              "Choose Language".tr,
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17,color: Presets.boldSizeColor),
            )),
            data,
          ],
        ),
      ),
    );
  }

  getUserDetail() async{
    var getUser = await helper.getSharedPrefString(keyName: "userid");
    if(getUser != null){
      useid.value = getUser;
      print(getUser);
    }

  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    setLanguage();
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
    getUserDetail();
  }
}
