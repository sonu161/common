import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sidbi_app/app/hospitalization_request/contrller/hospit_controller.dart';
import 'package:sidbi_app/app/hospitalization_request/indoor_hosp_repo.dart';
import 'package:sidbi_app/components/helper.dart';

import '../model/AccFormData.dart';

class AddClaimController extends GetxController {
  var formKey = GlobalKey<FormState>().obs;
  var textControllers = <TextEditingController>[].obs;
  var comment = TextEditingController().obs;
  var textAreaCtrl = <TextEditingController>[].obs;
  var totalFields = 9;
  var textArea = 2;

  var hosTypeVal = "".obs;
  var hosTypeName = "Hospital Location Type".obs;
  var hospitalLocationType = "Hospital Location".obs;
  var hospitalLocationTypeval = "Hospital Location".obs;

  var relationVal = "".obs;
  var relationName = "Select Relation".obs;

  var fileName = "Please choose (.pdf) file (1mb)".obs;
  var file = new File("").obs;
  var clickable = false.obs;
  var startDate = "".obs;
  var fileSize = "".obs;

  IndoorHospRepo repo = new IndoorHospRepo();
  Helper helper = new Helper();

  createFormFields() {
    for (var i = 0; i < totalFields; i++) {
      textControllers.add(TextEditingController());
    }

    for (var i = 0; i < 2; i++) {
      textAreaCtrl.add(TextEditingController());
    }

    print(textControllers.length);
  }

  void validateForm() {
    final isValid = formKey.value.currentState?.validate();
    if (!isValid!) {
      // submitForm();
      return;
    } else {
      submitForm();
    }
    formKey.value.currentState?.save();
  }

  submitForm() async {
    helper.fullAppLoading();
    var userid = await helper.getSharedPrefString(keyName: "userid");
    var fName = await helper.getSharedPrefString(keyName: "fullName");
    var email = await helper.getSharedPrefString(keyName: "emailId");
    var hospDate = await formateDate(data: textAreaCtrl[0].text);
    var billDate = await formateDate(data: textControllers[6].text);
    var formDatas = AccFormData(
        userId: userid,
        amtPaidByEmp: textControllers[7].text,
        billAmt: textControllers[7].text,
        billDate: billDate,
        billNo: textControllers[5].text,
        cityName: textControllers[2].text,
        comment: comment.value.text,
        userEmail: email,
        empName: fName,
        empRelation: relationVal.value,
        hospitalizedDate: hospDate,
        hospitalLocation: hospitalLocationTypeval.value,
        hospitalName: textControllers[3].text,
        hospitalType: hosTypeVal.value,
        patientName: textControllers[1].text,
        applicationUsed: "M");

    if (file.value.path == null) {
      helper.messageAlert(
          title: "Form error",
          message: "Please select file",
          type: AlertBoxType.Error);
    } 
    else if(await file.value.length() > 1000000){
      helper.messageAlert(title: "File size error", message: "Please select file less then or equal to 1MB", type: AlertBoxType.Error);
    }
    else {
      var res =
          await repo.submitAccForm(datas: formDatas, files: file.value.path);
      // print(await res);
      var jsonD = jsonDecode(res);
      print(jsonD['message']);
      if (jsonD['responseCode'] == "F") {
        Get.back();
        helper.messageAlert(
            title: "Message",
            message: "${jsonD['message']}",
            type: AlertBoxType.Error);
      } else {
        var ctrl = Get.find<HospitalController>();
        ctrl.getRefreshHospitalData();
        Get.back();
        helper.doneDialog(
            msg: "${jsonD['message']}",
            onClose: () {
              Get.back();
              Get.back();
            });
      }
      // if(jsonD['httpStatus'] == "CREATED"){
      //   var ctrl = Get.find<HospitalController>();
      //   ctrl.getHospitalData();
      //   Get.back();
      //   Get.back();
      // }
    }
  }

  selectFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        allowMultiple: true);
    result?.files.first.bytes;
    fileName.value = result!.files.first.name.toString();
    List<File> files = result.paths.map((path) => File(path!)).toList();
    file.value = files.first;
    fileSize.value = ((await file.value.length())/1000000).toString();
    print("file.value.length()");
  }

  setUserName({dropVal}) async {
    var name = await helper.getSharedPrefString(keyName: "fullName");
    if (dropVal.toUpperCase() == "SELF") {
      textControllers[1].text = name;
    } else {
      textControllers[1].text = "";
    }
  }

  formateDate({data}) async {
    var dateF = await DateFormat("dd-MM-yyyy").parse(data.toString());
    var day = "${dateF.year}-${dateF.month}-${dateF.day}";
    print("formate : $day");
    return day.toString();
  }

  getDateTime() async {
    var date = textControllers[6].value.text == ""
        ? "Date"
        : textControllers[6].value.text;
    print(date);
  }

  _printLatestValue() {
    print('Second text field');
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    createFormFields();
    textControllers[4].text = "Reimbursement";
    textAreaCtrl[0].addListener((){
      if(textAreaCtrl[0].value.text == ""){
        clickable.value = false;
      }
      else{
        textControllers[6].clear();
        startDate.value = DateFormat("dd-MM-yyyy").parse(textAreaCtrl[0].value.text).toString();
        clickable.value = true;
      }
    });
  }
}
