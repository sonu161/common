import 'dart:convert';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/forget_password/views/forget_ppasword_view.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/form_field.dart';
import 'package:sidbi_app/components/input_field.dart';
import 'package:sidbi_app/components/load_d.dart';
import 'package:sidbi_app/components/presets.dart';
import 'package:sizer/sizer.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => LoginPageLoader();
}

class LoginPageLoader extends State<LoginPage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      backgroundColor: Color(0xffffffff),
      body: SingleChildScrollView(
        child: Container(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 200,
                  decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary,
                      image: DecorationImage(
                          image: AssetImage("assets/images/holiday.jpg"),
                          fit: BoxFit.cover),
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(30),
                          bottomRight: Radius.circular(30))),
                  child: Align(
                    alignment: Alignment.bottomLeft,
                    child: Column(
                      children: [
                        SizedBox(
                          height: 120,
                        ),
                        Row(
                          children: [
                            Expanded(
                              child: Container(
                                height: 70,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 25),
                                  child: Stack(
                                    // crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Welcome".tr,
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 25,
                                            shadows: [
                                              BoxShadow(
                                                  color: Colors.black54,
                                                  blurRadius: 5)
                                            ]),
                                      ),
                                      Positioned(
                                        top: 30,
                                        child: Container(
                                          margin: EdgeInsets.only(top: 0),
                                          child: Text("To retiree portal".tr,
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 17,
                                                  shadows: [
                                                    BoxShadow(
                                                        color: Colors.black,
                                                        blurRadius: 5)
                                                  ])),
                                        ),
                                      )
                                      // Text("To retiree portal"),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Hero(
                              tag: "logo",
                              child: Container(
                                margin: EdgeInsets.only(right: 25),
                                width: 50,
                                height: 50,
                                decoration: BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(300)),
                                  // color: Colors.white.withOpacity(0.5),
                                  // gradient: RadialGradient(
                                  //     colors: [
                                  //       Color(0xffffffff),
                                  //       Color(0xffffffff),
                                  //       Color(0xffBEE1EE),
                                  //       Color(0xff24ACE1),
                                  //     ]
                                  // )
                                ),
                                child: Center(
                                  child: Image(
                                    image: AssetImage(
                                        "assets/images/sidbi_logo2.png"),
                                    height: 30,
                                    width: 30,
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 40,
                ),
                Column(
                  children: [
                    Column(
                      children: [
                        Container(
                          padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.all(Radius.circular(15)),
                          ),
                          child: Column(
                            children: [
                              SizedBox(
                                height: 20,
                              ),
                              Container(
                                margin: EdgeInsets.only(left: 10),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text("Sign In".tr,
                                      style: TextStyle(
                                        color: Presets.boldBigSizeColor,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 22,
                                      )),
                                ),
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              GetX(
                                init: LogingCtrl(),
                                builder: (ctrl) {
                                  return Column(
                                    children: [
                                      FormFields(
                                        hint: "Enter your userid".tr,
                                        textEditingController:
                                            ctrl.emailCtrl.value,
                                        fieldIcon: Image(
                                          image: AssetImage(
                                              "assets/icons/user.png"),
                                          height: 17,
                                          width: 17,
                                          color:
                                              const Color.fromARGB(70, 0, 0, 0),
                                        ),
                                      ),
                                      ctrl.emailCheck == true
                                          ? Column(
                                              children: [
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Container(
                                                    padding: EdgeInsets.only(
                                                        left: 15),
                                                    child: Row(
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Icon(
                                                              Icons.warning,
                                                              size: 13,
                                                            ),
                                                            SizedBox(
                                                              width: 5,
                                                            ),
                                                            Text(
                                                                "Userid is required"
                                                                    .tr,
                                                                style: TextStyle(
                                                                    color: Colors
                                                                        .red)),
                                                          ],
                                                        ),
                                                      ],
                                                    )),
                                                SizedBox(height: 10),
                                              ],
                                            )
                                          : Container(
                                              height: 0,
                                            ),
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      FormFields(
                                        hint: "Enter your password".tr,
                                        textEditingController:
                                            ctrl.passwordCtrl.value,
                                        obsecureText: ctrl.passView.value,
                                        fieldIcon: Image(
                                          image: AssetImage(
                                              "assets/icons/padlock.png"),
                                          height: 17,
                                          width: 17,
                                          color:
                                              const Color.fromARGB(70, 0, 0, 0),
                                        ),
                                        obsecureToNoSecure:
                                            ctrl.changeTONoneSecureText,
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      ctrl.passCheck == true
                                          ? Column(
                                              children: [
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Container(
                                                    padding: EdgeInsets.only(
                                                        left: 15),
                                                    child: Row(
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Icon(
                                                              Icons.warning,
                                                              size: 13,
                                                            ),
                                                            SizedBox(
                                                              width: 5,
                                                            ),
                                                            Text(
                                                              "User password is required"
                                                                  .tr,
                                                              style: TextStyle(
                                                                  color: Colors
                                                                      .red),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    )),
                                                SizedBox(height: 10),
                                              ],
                                            )
                                          : Container(
                                              height: 0,
                                            ),
                                    ],
                                  );
                                },
                              ),
                              Container(
                                margin: const EdgeInsets.fromLTRB(0, 15, 0, 0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    GetX(
                                      init: LogingCtrl(),
                                      builder: (ctrl) {
                                        if (ctrl.appLoadingState ==
                                            AppLoadingState.Loading) {
                                          return LoadD();
                                        } else {
                                          return Column(
                                            children: [
                                              Row(
                                                children: [
                                                  Expanded(
                                                    flex: 2,
                                                    child: InputField(
                                                      textEditingController:
                                                          ctrl.captcha.value,
                                                      hint: 'Enter Captcha',
                                                      // fullLabel: false,
                                                      // fullLabelText: "Ca",
                                                      borderRadius: 300,
                                                      lightTextBox: true,
                                                      validatorText:
                                                          "Captcha is required",
                                                      fieldIcon: Image(
                                                          image: MemoryImage(
                                                              base64Decode(ctrl
                                                                  .captchaImage
                                                                  .value))),
                                                      bigFieldImage: true,
                                                      trailingBtn:
                                                          Icon(Icons.refresh),
                                                      onTapTrailing: () {
                                                        ctrl.refreshCaptcha();
                                                      },
                                                      showLoading:
                                                          ctrl.loadingCtrl ==
                                                                  RefreshState
                                                                      .Loading
                                                              ? true
                                                              : false,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(
                                                height: 10,
                                              ),
                                              Material(
                                                child: InkWell(
                                                  onTap: () {
                                                    var ctrlF =
                                                        Get.find<LogingCtrl>();
                                                    ctrlF.validate();
                                                  },
                                                  child: Container(
                                                    padding: EdgeInsets.all(12),
                                                    decoration: BoxDecoration(
                                                        color: Theme.of(context)
                                                            .colorScheme
                                                            .primary,
                                                        borderRadius:
                                                            const BorderRadius
                                                                .all(
                                                                Radius.circular(
                                                                    300))),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          "Login".tr,
                                                          style: TextStyle(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color:
                                                                  Colors.white),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          );
                                        }
                                      },
                                    )
                                  ],
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    Container(
                        margin: EdgeInsets.only(top: 40),
                        child: RichText(
                          text: TextSpan(
                              text: "Forgot password?".tr,
                              style: TextStyle(color: Colors.black),
                              children: [
                                TextSpan(
                                    text: " Reset".tr,
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        Get.to(() => ForgetPpaswordView());
                                      },
                                    style: TextStyle(
                                        decorationThickness: 5,
                                        decorationStyle:
                                            TextDecorationStyle.solid,
                                        decorationColor: Colors.black,
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary))
                              ]),
                        ))
                  ],
                ),
                SizedBox(
                  height: 50,
                ),
                Material(
                  child: Hero(
                    tag: "logoooo",
                    child: Image.asset(
                      "assets/images/sidbi_logo.gif",
                      width: 20.w,
                    )),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
