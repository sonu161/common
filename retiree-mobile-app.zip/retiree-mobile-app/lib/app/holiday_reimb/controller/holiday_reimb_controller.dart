import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sidbi_app/app/holiday_reimb/model/reimburse_data.dart';
import 'package:sidbi_app/app/holiday_reimb/repo/holiday_reim_repo.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/helper.dart';

class HolidayReimbController extends GetxController {
  var loading = AppLoadingState.Initial.obs;
  var nofNight = TextEditingController().obs;
  var noOfRooms = TextEditingController().obs;
  var noOfDays = TextEditingController().obs;
  var totalAmt = TextEditingController().obs;
  var totalElbAmt = TextEditingController().obs;
  var totalGstAmt = TextEditingController().obs;
  var totalPayble = TextEditingController().obs;

  var sterLingNight = 0.obs;
  var availedReimbNight = 0.obs;
  var availableReimbNight = 0.obs;
  var elegibleAmt = 0.obs;
  var fileSize = "".obs;
  var fileSize2 = "".obs;

  HolidayReimRepo repo = new HolidayReimRepo();

  RxList<HolidayData> addedHomeReim = <HolidayData>[].obs;

  var fileId = "File Id (.pdf) file (1mb)".obs;
  var file = new File("").obs;
  var fileBill = "File Bill (.pdf) file (1mb)".obs;
  var file2 = new File("").obs;

  var dropData = <Map<String, String>>[].obs;
  var dropName = "Select holiday home".obs;
  var dropVal = "".obs;

  // addToListHomeReim({required HolidayData data}) async{
  //   try{
  //     addedHomeReim.add(data);
  //     addedHomeReim.refresh();
  //   }catch(e){
  //
  //   }
  // }

  deleteRow(index) async {
    if (addedHomeReim.length == 1) {
      addedHomeReim.removeAt(index);
      totalPayble.value.clear();
      totalGstAmt.value.clear();
      nofNight.value.clear();
      noOfRooms.value.clear();
      noOfDays.value.clear();
      totalAmt.value.clear();
      totalElbAmt.value.clear();
    } else {
      addedHomeReim.removeAt(index);
      addToForm();
    }

    addedHomeReim.refresh();
  }

  editRow(index, {required HolidayData data}) async {
    for (var i = 0; i <= addedHomeReim.length; i++) {
      if (i == index) {
        addedHomeReim[index].roomTarrif = data.roomTarrif;
        addedHomeReim[index].foodBill = data.foodBill;
        addedHomeReim[index].eligibleAmt = data.eligibleAmt;
        addedHomeReim[index].hotelGstRate = data.hotelGstRate;
        addedHomeReim[index].foodGstRate = data.foodGstRate;
        addedHomeReim[index].hotelGstAmt = data.hotelGstAmt;
        addedHomeReim[index].foodGstAmt = data.foodGstAmt;
        addedHomeReim[index].totalGstAmt = data.totalGstAmt;
        addedHomeReim[index].hotelName = data.hotelName;
        addedHomeReim[index].startDate = data.startDate;
        addedHomeReim[index].endDate = data.endDate;
        addedHomeReim[index].noOfDays = data.noOfDays;
        addedHomeReim[index].totalEligibleAmt = data.totalEligibleAmt;
        addedHomeReim[index].totalPayAmy = data.totalPayAmy;
        addedHomeReim[index].totalHotelFoodAmt = data.totalHotelFoodAmt;
      }
    }
    addedHomeReim.refresh();
  }

  addToForm() async {
    int totalPayAmt = 0;
    int roomTarf = 0;
    int noOfNights = 0;
    int totalAmount = 0;
    int elgAmt = 0;
    int totalDate = await dateDiffe();
    for (var i = 0; i < addedHomeReim.length; i++) {
      print(int.parse(addedHomeReim[i].totalPayAmy!));
      totalPayAmt += int.parse(addedHomeReim[i].totalPayAmy!);
      roomTarf += int.parse(addedHomeReim[i].totalGstAmt!);
      noOfNights += int.parse(addedHomeReim[i].noOfDays.toString());
      totalAmount += int.parse(addedHomeReim[i].totalHotelFoodAmt!);
      elgAmt += int.parse(addedHomeReim[i].totalEligibleAmt!);
      totalPayble.value.text = totalPayAmt.toString();
      totalGstAmt.value.text = roomTarf.toString();
      nofNight.value.text = noOfNights.toString();
      noOfRooms.value.text = (noOfNights / totalDate).toString();
      noOfDays.value.text = noOfNights.toString();
      totalAmt.value.text = totalAmount.toString();
      totalElbAmt.value.text = elgAmt.toString();
    }
    refresh();
  }

  dateDiffe() async {
    DateTime fromDate = new DateFormat("dd-MM-yyyy")
        .parse(addedHomeReim.first.startDate.toString());
    DateTime toDate = new DateFormat("dd-MM-yyyy")
        .parse(addedHomeReim.last.endDate.toString());
    var startDate = DateTime.parse(fromDate.toString());
    var endDate = DateTime.parse(toDate.toString());
    var noOfDays = endDate.difference(startDate).inDays;
    return int.parse(noOfDays.toString());
  }

  submitData() async {
    // HolidayData data = addedHomeReim.toJson();
    try {
      print(file2.value.path);
      if (file.value.path != "" && file2.value.path != "") {
        if (int.parse(nofNight.value.text) > availableReimbNight.value) {
          Helper().messageAlert(
              title: "Information",
              message: "You don't have this much of available nights",
              type: AlertBoxType.Error);
        } else {
          // Helper().fullAppLoading();
          var itemData = [];
          var empName = await Helper().getSharedPrefString(keyName: "fullName");
          var empgrade =
              await Helper().getSharedPrefString(keyName: "empGrade");
          var salCode =
              await Helper().getSharedPrefString(keyName: "userid");
          for (var i = 0; i < addedHomeReim.length; i++) {
            var fromDate = todate(dateString: addedHomeReim[i].startDate);
            var toDate = todate(dateString: addedHomeReim[i].endDate);
            var item = {
              "eligibleAmount": "${addedHomeReim[i].eligibleAmt}",
              "foodBill": "${addedHomeReim[i].foodBill}",
              "foodGstAmount": "${addedHomeReim[i].foodGstAmt}",
              "foodGstRate": "${addedHomeReim[i].foodGstRate}",
              "fromDate": "${fromDate.toString().replaceAll(".000", "")}",
              "hotelName": "${addedHomeReim[i].hotelName}",
              "hotelGstAmount": "${addedHomeReim[i].hotelGstAmt}",
              "hotelGstRate": "${addedHomeReim[i].hotelGstRate}",
              "roomTally": "${addedHomeReim[i].roomTarrif}",
              "toDate": "${toDate.toString().replaceAll(".000", "")}",
              "totalDays": "${addedHomeReim[i].noOfDays}",
              "totalEligibleAmount": "${addedHomeReim[i].totalEligibleAmt}",
              "totalEligibleGst": "${addedHomeReim[i].totalGstAmt}",
              "totalFoodAndHotelAmount":
                  "${addedHomeReim[i].totalHotelFoodAmt}",
              "totalGstAmount": "${addedHomeReim[i].totalGstAmt}",
              "totalPayableAmount": "${addedHomeReim[i].totalPayAmy}"
            };

            itemData.add(item);
          }
          var jData = {
            "eligbleAmount": "${totalElbAmt.value.text}",
            "salCodes": "$salCode",
            "empName": "$empName",
            "empGrade": "$empgrade",
            "grandTotalAmount": "${totalPayble.value.text}",
            "grandTotalDays": "${noOfDays.value.text}",
            "hhRowCount": "${addedHomeReim.length}",
            "grandTotalEligibleAmount": "${totalAmt.value.text}",
            "grandTotalPayable": "${totalPayble.value.text}",
            "holidayHome": "${dropVal.split("-")[1]}-${dropVal.split("-")[0]}",
            "nights": "${noOfDays.value.text}",
            "NoOfNight": 0,
            "rooms": "${noOfRooms.value.text.replaceAll(".0", "")}",
            "taxOnRoom": "${totalGstAmt.value.text}",
            "itemsList": itemData,
            "appUsed":"W"
          };
          print("${totalPayble.value.text}");
          
          var res = await repo.submitData(
              data: jData, fileBill: file2.value.path, fileId: file.value.path);
          print(jsonDecode(res));
          Get.back();
          Helper().appDialogBox(
            title: 'Information',
            message: "${jsonDecode(res)['message']}",
            show_confirm: false,
            onTap: () {
              if (jsonDecode(res)['status'] == "error") {
                Get.back();
              } else {
                Get.back();
                Get.back();
              }
            },
          );
        
        }
      } 
      else if(await file.value.length() > 1000000 || await file2.value.length() > 1000000){
        Helper().messageAlert(
            title: "Information",
            message: "One of the file is exceeding 1mb, please check",
            type: AlertBoxType.Error);
      }
      else {
        Helper().messageAlert(
            title: "Information",
            message: "Please select pdf files required",
            type: AlertBoxType.Error);
      }
    } catch (e) {
      print(e);
    }
  }

  todate({dateString}) {
    DateTime date = new DateFormat("dd-MM-yyyy").parse(dateString);
    var newDate = DateTime.parse(date.toString());
    return newDate.toString().replaceAll(" ", "T");
  }

  selectFile({selector}) async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['jpg', 'pdf', 'doc'],
        allowMultiple: true);
    result?.files.first.bytes;
    List<File> files = result!.paths.map((path) => File(path!)).toList();
    if (selector == "fileid") {
      fileId.value = result.files.first.name.toString();
      file.value = files.first;
      fileSize.value = ((await file.value.length())/1000000).toString();
    } else {
      fileBill.value = result.files.first.name.toString();
      file2.value = files.first;
      fileSize2.value = ((await file2.value.length())/1000000).toString();
    }
  }

  getHolidayHomes() async {
    try {
      // var res = await repo.getBookingList();
      // var data = jsonDecode(await res.stream.bytesToString());
      // for(var i =0; i <data.length; i++){
      //   dropData.add({
      //           "name":"${data[i]['holidayHome']}",
      //           "val":"${data[i]['appNo']}-${data[i]['holidayHome']}"
      //         });
      // }
      var res = await repo.getBookingList();
      var data = jsonDecode(res.body);
      for (var i = 0; i < data.length; i++) {
        dropData.add({
          "name": "${data[i]['name']}",
          "val": "${data[i]['code']}-${data[i]['name']}"
        });
      }
    } catch (e) {}
  }

  getReimbList() async {
    try {
      var res = await repo.getReimbElg();
      if (res.statusCode == 200) {
        var data = jsonDecode(await res.stream.bytesToString());
        print("Available Sterling : ${data['eligibleAmount']}");
        sterLingNight.value = data['availedSterlingNight'];
        availedReimbNight.value = data['availedReimbursedNight'];
        availableReimbNight.value = data['availableMaxNight'];
        elegibleAmt.value = int.parse(data['eligibleAmount'].toString());
      } else {
        print("Error r");
      }
    } catch (e) {
      print(e);
    }
  }

  getReloadData() async {
    loading.value = AppLoadingState.Loading;
    List<Future<void>> futures = [getHolidayHomes(), getReimbList()];
    await futures.wait;
    loading.value = AppLoadingState.Loaded;
  }

  removeFile({required File file}) async {
    file.delete();
    refresh();
  }

  @override
  void onInit() {
    getReloadData();
    super.onInit();
  }
}
