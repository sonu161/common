import 'package:get/get.dart';
import 'package:sidbi_app/components/helper.dart';

import '../../entities/claims/claims_entity.dart';

class ClaimsRepo extends ClaimsEntity{
  Helper helper = new Helper();
  @override
  getClaimList() async{
    try{
      // helper.fullAppLoading();
      var userid = await helper.getSharedPrefString(keyName: "userid");
      var url = "OpdChcList/$userid";
      var res = await helper.getStreamedService(url: "$url");
      // print(await res.stream.bytesToString());
      // Get.back;
      return res;
    }catch(e){

    }
  }

  @override
  submitData({datas,String? files}) async{
    var res = await helper.postNew(url: "opdAmount",data: datas,path: files, multifile: []);
    // print("Status Code : ${res.statusCode}");
    return res;
  }

}