import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_getx_widget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sidbi_app/app/claims/controller/claim_ctrl.dart';
import 'package:sidbi_app/app/claims/views/claim_form.dart';
import 'dart:math' as math;

import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/loading.dart';

class ClaimsView extends StatefulWidget {
  const ClaimsView({super.key});

  @override
  State<ClaimsView> createState() => _ClaimsViewState();
}

class _ClaimsViewState extends State<ClaimsView> {
  final listViewController = ScrollController();
  final listViewLey = Key;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Theme.of(context).colorScheme.background,
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text("Claim Details"),
      ),
      body: Container(
        child: SingleChildScrollView(
            padding: EdgeInsets.only(top: 15),
            child: GetX(
              init: ClaimController(),
              builder: (ctrl) {
                if(ctrl.loading.value == AppLoadingState.Loading){
                  return LoadingApp();
                }else{
                  return ListView.builder(
                    padding: EdgeInsets.only(
                        bottom: 100
                    ),
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: ctrl.claimData.first.length,
                    itemBuilder: (context, index) {
                      // return expansionTileView(data: ctrl.claimList[index]);
                      return dataCard(data: ctrl.claimData.first[index],openView: ctrl.openView, index:index);
                    },
                  );
                }

              },
            )),
      ),
      floatingActionButton: FloatingActionButton(
        shape: const CircleBorder(),
        onPressed: () {
          Get.to(ClaimForm());
        },
        child: Icon(Icons.add),
      ),
    );
  }

  Widget dataCard({data, openView, index}) {
    return Container(
      margin: EdgeInsets.only(left: 15, right: 15, bottom: 10),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)],
          border: Border(
              left: BorderSide(
                  color: Color((math.Random().nextDouble() * 0xFFFFFF).toInt())
                      .withOpacity(0.4),
                  width: 5))),
      child: ExpansionTile(
        // backgroundColor:
        //     Theme.of(context).colorScheme.primary.withOpacity(0.07),
        onExpansionChanged: (val){
          print(val);
          var ctrl = Get.find<ClaimController>();
          if(val == true){
            ctrl.openView.value = index;
          }else{
            ctrl.openView.value = -1;
          }
          print(ctrl.openView.value);
        },
        initiallyExpanded: openView == index?true:false,
        tilePadding: EdgeInsets.only(top: 10, bottom: 10, left: 15, right: 15),
        title: Container(
          child: Column(
            children: [
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Application No",
                      style: TextStyle(fontSize: 15, color: Colors.black54),
                    ),
                    Text("Status",
                        style: TextStyle(fontSize: 15, color: Colors.black54))
                  ],
                ),
              ),
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "${data['aaplNo']}",
                      style: TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w600,
                          color: Theme.of(context).colorScheme.onSecondary),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.calendar_month,
                          color: Theme.of(context).colorScheme.secondary,
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text("${data['requestDate']}",
                            style:
                            TextStyle(fontSize: 15, color: Theme.of(context).colorScheme.secondary)),
                      ],
                    ),
                    Container(
                      padding: EdgeInsets.only(
                          left: 5, right: 10, top: 3, bottom: 3),
                      decoration: BoxDecoration(
                          // border: Border.all(
                          //   color: Theme.of(context).colorScheme.primary,
                          // ),
                          borderRadius: BorderRadius.circular(300)),
                      child: Row(
                        children: [
                          Text("\u{20B9}",
                              style: GoogleFonts.rubik(
                                  color: Theme.of(context).colorScheme.secondary.withOpacity(0.9),
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15
                              )),
                          SizedBox(
                            width: 2,
                          ),
                          Text(
                            "${data['amountClaimed']}",
                            style: GoogleFonts.rubik(
                                color: Theme.of(context).colorScheme.secondary.withOpacity(0.9),
                                fontWeight: FontWeight.w600,
                              fontSize: 20
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
        children: [
          Container(
            margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
            child: Row(
              children: [
                Expanded(child: Text("Reimbursement Type")),
                SizedBox(
                  width: 10,
                ),
                Expanded(
                    child: Text(
                  "${data['reimbursement']}",
                  textAlign: TextAlign.end,
                      style: GoogleFonts.rubik(
                        color: Colors.green,
                        fontWeight: FontWeight.bold
                      ),
                ))
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
            child: Row(
              children: [
                Expanded(child: Text("Request Date")),
                SizedBox(
                  width: 10,
                ),
                Expanded(child: Text("${data['requestDate']}",
                  textAlign: TextAlign.end,
                  style: GoogleFonts.rubik(
                      color: Colors.green,
                      fontWeight: FontWeight.bold
                  ),))
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
            child: Row(
              children: [
                Expanded(child: Text("Amount Claim")),
                SizedBox(
                  width: 10,
                ),
                Expanded(child: Text("\u{20B9} ${data['amountClaimed']}",
                    textAlign: TextAlign.end,
                    style: GoogleFonts.rubik(
                        color: Colors.green,
                        fontWeight: FontWeight.bold
                    )))
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
            child: Row(
              children: [
                Expanded(child: Text("Amount to paid")),
                SizedBox(
                  width: 10,
                ),
                Expanded(child: Text("\u{20B9} ${data['amountToBePaid']}",
                    textAlign: TextAlign.end,
                    style: GoogleFonts.rubik(
                        color: Colors.green,
                        fontWeight: FontWeight.bold
                    )))
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.fromLTRB(20, 10, 20, 20),
            child: Row(
              children: [
                Expanded(child: Text("Self / Dependent")),
                SizedBox(
                  width: 10,
                ),
                Expanded(child: Text("${data['selfDependent'] == "S"?"Self":"Dependent"}",
                    textAlign: TextAlign.end,
                    style: GoogleFonts.rubik(
                        color: Colors.green,
                        fontWeight: FontWeight.bold
                    )))
              ],
            ),
          ),
        ],
      ),
    );
  }
  //
  // Widget tileExp({data, openView, index}){
  //   return ExpansionPanelList(
  //     children: [
  //       ExpansionPanel(
  //           headerBuilder: (BuildContext context, bool isExpanded) {
  //             return Container(
  //               child: Column(
  //                 children: [
  //                   Container(
  //                     child: Row(
  //                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                       children: [
  //                         Text(
  //                           "Application No",
  //                           style: TextStyle(fontSize: 15, color: Colors.black54),
  //                         ),
  //                         Text("Status",
  //                             style: TextStyle(fontSize: 15, color: Colors.black54))
  //                       ],
  //                     ),
  //                   ),
  //                   Container(
  //                     child: Row(
  //                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                       children: [
  //                         Text(
  //                           "${data['applicationNo']}",
  //                           style: TextStyle(
  //                               fontSize: 19,
  //                               fontWeight: FontWeight.w600,
  //                               color: Theme.of(context).colorScheme.onSecondary),
  //                         ),
  //                       ],
  //                     ),
  //                   ),
  //                   SizedBox(
  //                     height: 10,
  //                   ),
  //                   Container(
  //                     child: Row(
  //                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                       children: [
  //                         Row(
  //                           children: [
  //                             Icon(
  //                               Icons.calendar_month,
  //                               color: Theme.of(context).colorScheme.secondary,
  //                             ),
  //                             SizedBox(
  //                               width: 5,
  //                             ),
  //                             Text("${data['requestDate']}",
  //                                 style:
  //                                 TextStyle(fontSize: 15, color: Theme.of(context).colorScheme.secondary)),
  //                           ],
  //                         ),
  //                         Container(
  //                           padding: EdgeInsets.only(
  //                               left: 5, right: 10, top: 3, bottom: 3),
  //                           decoration: BoxDecoration(
  //                             // border: Border.all(
  //                             //   color: Theme.of(context).colorScheme.primary,
  //                             // ),
  //                               borderRadius: BorderRadius.circular(300)),
  //                           child: Row(
  //                             children: [
  //                               Text("\u{20B9}",
  //                                   style: GoogleFonts.rubik(
  //                                       color: Theme.of(context).colorScheme.secondary.withOpacity(0.9),
  //                                       fontWeight: FontWeight.w700,
  //                                       fontSize: 15
  //                                   )),
  //                               SizedBox(
  //                                 width: 2,
  //                               ),
  //                               Text(
  //                                 "${data['amountClaim']}",
  //                                 style: GoogleFonts.rubik(
  //                                     color: Theme.of(context).colorScheme.secondary.withOpacity(0.9),
  //                                     fontWeight: FontWeight.w600,
  //                                     fontSize: 20
  //                                 ),
  //                               )
  //                             ],
  //                           ),
  //                         ),
  //                       ],
  //                     ),
  //                   )
  //                 ],
  //               ),
  //             );
  //           },
  //           body: Column(
  //             children: [
  //               Container(
  //                 margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
  //                 child: Row(
  //                   children: [
  //                     Expanded(child: Text("Reimbursement Type")),
  //                     SizedBox(
  //                       width: 10,
  //                     ),
  //                     Expanded(
  //                         child: Text(
  //                           "${data['reimbursementType']}",
  //                           // "${data['reimbursementType']}",
  //                           textAlign: TextAlign.end,
  //                           style: GoogleFonts.rubik(
  //                               color: Colors.green,
  //                               fontWeight: FontWeight.bold
  //                           ),
  //                         ))
  //                   ],
  //                 ),
  //               ),
  //               Container(
  //                 margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
  //                 child: Row(
  //                   children: [
  //                     Expanded(child: Text("Request Date")),
  //                     SizedBox(
  //                       width: 10,
  //                     ),
  //                     Expanded(child: Text("${data['requestDate']}",
  //                       textAlign: TextAlign.end,
  //                       style: GoogleFonts.rubik(
  //                           color: Colors.green,
  //                           fontWeight: FontWeight.bold
  //                       ),))
  //                   ],
  //                 ),
  //               ),
  //               Container(
  //                 margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
  //                 child: Row(
  //                   children: [
  //                     Expanded(child: Text("Amount Claim")),
  //                     SizedBox(
  //                       width: 10,
  //                     ),
  //                     Expanded(child: Text("\u{20B9} ${data['amountClaim']}",
  //                         textAlign: TextAlign.end,
  //                         style: GoogleFonts.rubik(
  //                             color: Colors.green,
  //                             fontWeight: FontWeight.bold
  //                         )))
  //                   ],
  //                 ),
  //               ),
  //               Container(
  //                 margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
  //                 child: Row(
  //                   children: [
  //                     Expanded(child: Text("Amount to paid")),
  //                     SizedBox(
  //                       width: 10,
  //                     ),
  //                     Expanded(child: Text("\u{20B9} ${data['amountToBePaid']}",
  //                         textAlign: TextAlign.end,
  //                         style: GoogleFonts.rubik(
  //                             color: Colors.green,
  //                             fontWeight: FontWeight.bold
  //                         )))
  //                   ],
  //                 ),
  //               ),
  //               Container(
  //                 margin: EdgeInsets.fromLTRB(20, 10, 20, 20),
  //                 child: Row(
  //                   children: [
  //                     Expanded(child: Text("Self / Dependent")),
  //                     SizedBox(
  //                       width: 10,
  //                     ),
  //                     Expanded(child: Text("${data['selfDependent'] == "S"?"Self":"Dependent"}",
  //                         textAlign: TextAlign.end,
  //                         style: GoogleFonts.rubik(
  //                             color: Colors.green,
  //                             fontWeight: FontWeight.bold
  //                         )))
  //                   ],
  //                 ),
  //               ),
  //             ],
  //           )
  //       )
  //     ],
  //   );
  // }

}
