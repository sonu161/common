class ClaimsDataModel {
  ClaimsDataModel({
      this.id, 
      this.name, 
      this.age, 
      this.salary, 
      this.address, 
      this.reimbursement, 
      this.retiredEmployeeName, 
      this.selfDependent, 
      this.dependentName, 
      this.requestDate, 
      this.amountClaimed, 
      this.amountToBePaid, 
      this.tdsAmt, 
      this.finalAmountToBePaid, 
      this.grade, 
      this.aaplNo, 
      this.username, 
      this.password, 
      this.empName, 
      this.relation, 
      this.patientName, 
      this.cityName, 
      this.hospitalName, 
      this.requestType, 
      this.hospiatlizeDate, 
      this.hospitalLocation, 
      this.hospitalType, 
      this.comment, 
      this.hospitalBillNo, 
      this.billDate, 
      this.billAmt, 
      this.amtpaidByEmp, 
      this.file, 
      this.empRating, 
      this.empFeedback, 
      this.empCode, 
      this.empDob, 
      this.empAddress, 
      this.investCode, 
      this.investDesc, 
      this.investAmount, 
      this.errMsg, 
      this.eligbleAmount, 
      this.roomTally, 
      this.startdate, 
      this.enddate, 
      this.noOfRooms, 
      this.totalClaimAmount, 
      this.totalEligbleAmount, 
      this.foodBill, 
      this.hotelGstRate, 
      this.foodGstRate, 
      this.foodGstAmount, 
      this.hotelGstAmount, 
      this.totalGstAmount, 
      this.totalDays, 
      this.applicationUsed, 
      this.flag, 
      this.status, 
      this.token, 
      this.csrfCode, 
      this.csrfCode2, 
      this.loginError,});

  ClaimsDataModel.fromJson(dynamic json) {
    id = json['id'];
    name = json['name'];
    age = json['age'];
    salary = json['salary'];
    address = json['address'];
    reimbursement = json['reimbursement'];
    retiredEmployeeName = json['retiredEmployeeName'];
    selfDependent = json['selfDependent'];
    dependentName = json['dependentName'];
    requestDate = json['requestDate'];
    amountClaimed = json['amountClaimed'];
    amountToBePaid = json['amountToBePaid'];
    tdsAmt = json['tdsAmt'];
    finalAmountToBePaid = json['finalAmountToBePaid'];
    grade = json['grade'];
    aaplNo = json['aaplNo'];
    username = json['username'];
    password = json['password'];
    empName = json['empName'];
    relation = json['relation'];
    patientName = json['patientName'];
    cityName = json['cityName'];
    hospitalName = json['hospitalName'];
    requestType = json['requestType'];
    hospiatlizeDate = json['hospiatlizeDate'];
    hospitalLocation = json['hospitalLocation'];
    hospitalType = json['hospitalType'];
    comment = json['comment'];
    hospitalBillNo = json['hospitalBillNo'];
    billDate = json['billDate'];
    billAmt = json['billAmt'];
    amtpaidByEmp = json['amtpaidByEmp'];
    file = json['file'];
    empRating = json['empRating'];
    empFeedback = json['empFeedback'];
    empCode = json['empCode'];
    empDob = json['empDob'];
    empAddress = json['empAddress'];
    investCode = json['investCode'];
    investDesc = json['investDesc'];
    investAmount = json['investAmount'];
    errMsg = json['errMsg'];
    eligbleAmount = json['eligbleAmount'];
    roomTally = json['roomTally'];
    startdate = json['startdate'];
    enddate = json['enddate'];
    noOfRooms = json['noOfRooms'];
    totalClaimAmount = json['totalClaimAmount'];
    totalEligbleAmount = json['totalEligbleAmount'];
    foodBill = json['foodBill'];
    hotelGstRate = json['hotelGstRate'];
    foodGstRate = json['foodGstRate'];
    foodGstAmount = json['foodGstAmount'];
    hotelGstAmount = json['hotelGstAmount'];
    totalGstAmount = json['totalGstAmount'];
    totalDays = json['totalDays'];
    applicationUsed = json['applicationUsed'];
    flag = json['flag'];
    status = json['status'];
    token = json['token'];
    csrfCode = json['csrfCode'];
    csrfCode2 = json['csrfCode2'];
    loginError = json['loginError'];
  }
  dynamic id;
  dynamic name;
  dynamic age;
  dynamic salary;
  dynamic address;
  String? reimbursement;
  dynamic retiredEmployeeName;
  String? selfDependent;
  dynamic dependentName;
  String? requestDate;
  num? amountClaimed;
  num? amountToBePaid;
  dynamic tdsAmt;
  dynamic finalAmountToBePaid;
  dynamic grade;
  String? aaplNo;
  dynamic username;
  dynamic password;
  dynamic empName;
  dynamic relation;
  dynamic patientName;
  dynamic cityName;
  dynamic hospitalName;
  dynamic requestType;
  dynamic hospiatlizeDate;
  dynamic hospitalLocation;
  dynamic hospitalType;
  dynamic comment;
  dynamic hospitalBillNo;
  dynamic billDate;
  dynamic billAmt;
  dynamic amtpaidByEmp;
  dynamic file;
  dynamic empRating;
  dynamic empFeedback;
  dynamic empCode;
  dynamic empDob;
  dynamic empAddress;
  dynamic investCode;
  dynamic investDesc;
  dynamic investAmount;
  dynamic errMsg;
  dynamic eligbleAmount;
  dynamic roomTally;
  dynamic startdate;
  dynamic enddate;
  dynamic noOfRooms;
  dynamic totalClaimAmount;
  dynamic totalEligbleAmount;
  dynamic foodBill;
  dynamic hotelGstRate;
  dynamic foodGstRate;
  dynamic foodGstAmount;
  dynamic hotelGstAmount;
  dynamic totalGstAmount;
  dynamic totalDays;
  dynamic applicationUsed;
  bool? flag;
  dynamic status;
  dynamic token;
  dynamic csrfCode;
  dynamic csrfCode2;
  dynamic loginError;
ClaimsDataModel copyWith({  dynamic id,
  dynamic name,
  dynamic age,
  dynamic salary,
  dynamic address,
  String? reimbursement,
  dynamic retiredEmployeeName,
  String? selfDependent,
  dynamic dependentName,
  String? requestDate,
  num? amountClaimed,
  num? amountToBePaid,
  dynamic tdsAmt,
  dynamic finalAmountToBePaid,
  dynamic grade,
  String? aaplNo,
  dynamic username,
  dynamic password,
  dynamic empName,
  dynamic relation,
  dynamic patientName,
  dynamic cityName,
  dynamic hospitalName,
  dynamic requestType,
  dynamic hospiatlizeDate,
  dynamic hospitalLocation,
  dynamic hospitalType,
  dynamic comment,
  dynamic hospitalBillNo,
  dynamic billDate,
  dynamic billAmt,
  dynamic amtpaidByEmp,
  dynamic file,
  dynamic empRating,
  dynamic empFeedback,
  dynamic empCode,
  dynamic empDob,
  dynamic empAddress,
  dynamic investCode,
  dynamic investDesc,
  dynamic investAmount,
  dynamic errMsg,
  dynamic eligbleAmount,
  dynamic roomTally,
  dynamic startdate,
  dynamic enddate,
  dynamic noOfRooms,
  dynamic totalClaimAmount,
  dynamic totalEligbleAmount,
  dynamic foodBill,
  dynamic hotelGstRate,
  dynamic foodGstRate,
  dynamic foodGstAmount,
  dynamic hotelGstAmount,
  dynamic totalGstAmount,
  dynamic totalDays,
  dynamic applicationUsed,
  bool? flag,
  dynamic status,
  dynamic token,
  dynamic csrfCode,
  dynamic csrfCode2,
  dynamic loginError,
}) => ClaimsDataModel(  id: id ?? this.id,
  name: name ?? this.name,
  age: age ?? this.age,
  salary: salary ?? this.salary,
  address: address ?? this.address,
  reimbursement: reimbursement ?? this.reimbursement,
  retiredEmployeeName: retiredEmployeeName ?? this.retiredEmployeeName,
  selfDependent: selfDependent ?? this.selfDependent,
  dependentName: dependentName ?? this.dependentName,
  requestDate: requestDate ?? this.requestDate,
  amountClaimed: amountClaimed ?? this.amountClaimed,
  amountToBePaid: amountToBePaid ?? this.amountToBePaid,
  tdsAmt: tdsAmt ?? this.tdsAmt,
  finalAmountToBePaid: finalAmountToBePaid ?? this.finalAmountToBePaid,
  grade: grade ?? this.grade,
  aaplNo: aaplNo ?? this.aaplNo,
  username: username ?? this.username,
  password: password ?? this.password,
  empName: empName ?? this.empName,
  relation: relation ?? this.relation,
  patientName: patientName ?? this.patientName,
  cityName: cityName ?? this.cityName,
  hospitalName: hospitalName ?? this.hospitalName,
  requestType: requestType ?? this.requestType,
  hospiatlizeDate: hospiatlizeDate ?? this.hospiatlizeDate,
  hospitalLocation: hospitalLocation ?? this.hospitalLocation,
  hospitalType: hospitalType ?? this.hospitalType,
  comment: comment ?? this.comment,
  hospitalBillNo: hospitalBillNo ?? this.hospitalBillNo,
  billDate: billDate ?? this.billDate,
  billAmt: billAmt ?? this.billAmt,
  amtpaidByEmp: amtpaidByEmp ?? this.amtpaidByEmp,
  file: file ?? this.file,
  empRating: empRating ?? this.empRating,
  empFeedback: empFeedback ?? this.empFeedback,
  empCode: empCode ?? this.empCode,
  empDob: empDob ?? this.empDob,
  empAddress: empAddress ?? this.empAddress,
  investCode: investCode ?? this.investCode,
  investDesc: investDesc ?? this.investDesc,
  investAmount: investAmount ?? this.investAmount,
  errMsg: errMsg ?? this.errMsg,
  eligbleAmount: eligbleAmount ?? this.eligbleAmount,
  roomTally: roomTally ?? this.roomTally,
  startdate: startdate ?? this.startdate,
  enddate: enddate ?? this.enddate,
  noOfRooms: noOfRooms ?? this.noOfRooms,
  totalClaimAmount: totalClaimAmount ?? this.totalClaimAmount,
  totalEligbleAmount: totalEligbleAmount ?? this.totalEligbleAmount,
  foodBill: foodBill ?? this.foodBill,
  hotelGstRate: hotelGstRate ?? this.hotelGstRate,
  foodGstRate: foodGstRate ?? this.foodGstRate,
  foodGstAmount: foodGstAmount ?? this.foodGstAmount,
  hotelGstAmount: hotelGstAmount ?? this.hotelGstAmount,
  totalGstAmount: totalGstAmount ?? this.totalGstAmount,
  totalDays: totalDays ?? this.totalDays,
  applicationUsed: applicationUsed ?? this.applicationUsed,
  flag: flag ?? this.flag,
  status: status ?? this.status,
  token: token ?? this.token,
  csrfCode: csrfCode ?? this.csrfCode,
  csrfCode2: csrfCode2 ?? this.csrfCode2,
  loginError: loginError ?? this.loginError,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    map['age'] = age;
    map['salary'] = salary;
    map['address'] = address;
    map['reimbursement'] = reimbursement;
    map['retiredEmployeeName'] = retiredEmployeeName;
    map['selfDependent'] = selfDependent;
    map['dependentName'] = dependentName;
    map['requestDate'] = requestDate;
    map['amountClaimed'] = amountClaimed;
    map['amountToBePaid'] = amountToBePaid;
    map['tdsAmt'] = tdsAmt;
    map['finalAmountToBePaid'] = finalAmountToBePaid;
    map['grade'] = grade;
    map['aaplNo'] = aaplNo;
    map['username'] = username;
    map['password'] = password;
    map['empName'] = empName;
    map['relation'] = relation;
    map['patientName'] = patientName;
    map['cityName'] = cityName;
    map['hospitalName'] = hospitalName;
    map['requestType'] = requestType;
    map['hospiatlizeDate'] = hospiatlizeDate;
    map['hospitalLocation'] = hospitalLocation;
    map['hospitalType'] = hospitalType;
    map['comment'] = comment;
    map['hospitalBillNo'] = hospitalBillNo;
    map['billDate'] = billDate;
    map['billAmt'] = billAmt;
    map['amtpaidByEmp'] = amtpaidByEmp;
    map['file'] = file;
    map['empRating'] = empRating;
    map['empFeedback'] = empFeedback;
    map['empCode'] = empCode;
    map['empDob'] = empDob;
    map['empAddress'] = empAddress;
    map['investCode'] = investCode;
    map['investDesc'] = investDesc;
    map['investAmount'] = investAmount;
    map['errMsg'] = errMsg;
    map['eligbleAmount'] = eligbleAmount;
    map['roomTally'] = roomTally;
    map['startdate'] = startdate;
    map['enddate'] = enddate;
    map['noOfRooms'] = noOfRooms;
    map['totalClaimAmount'] = totalClaimAmount;
    map['totalEligbleAmount'] = totalEligbleAmount;
    map['foodBill'] = foodBill;
    map['hotelGstRate'] = hotelGstRate;
    map['foodGstRate'] = foodGstRate;
    map['foodGstAmount'] = foodGstAmount;
    map['hotelGstAmount'] = hotelGstAmount;
    map['totalGstAmount'] = totalGstAmount;
    map['totalDays'] = totalDays;
    map['applicationUsed'] = applicationUsed;
    map['flag'] = flag;
    map['status'] = status;
    map['token'] = token;
    map['csrfCode'] = csrfCode;
    map['csrfCode2'] = csrfCode2;
    map['loginError'] = loginError;
    return map;
  }

}