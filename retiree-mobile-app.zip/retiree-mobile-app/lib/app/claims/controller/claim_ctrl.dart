import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/claims/model/ClaimsDataModel.dart';
import 'package:sidbi_app/app/claims/repo.dart';
import 'package:sidbi_app/components/helper.dart';

import '../../login/controller/loging_ctrl.dart';

class ClaimController extends GetxController{
  var claimList = [
    {
      "applicationNo":"2410001345",
      "reimbursementType":"CHC",
      "requestDate":"26/02/2024",
      "amountClaim":"1000",
      "amountToBePaid":"1000",
      "selfDependent":"Self"
    },
    {
      "applicationNo":"534545345",
      "reimbursementType":"CHC",
      "requestDate":"26/02/2024",
      "amountClaim":"1000",
      "amountToBePaid":"1000",
      "selfDependent":"Self"
    },
    {
      "applicationNo":"655443432",
      "reimbursementType":"CHC",
      "requestDate":"26/02/2024",
      "amountClaim":"1000",
      "amountToBePaid":"1000",
      "selfDependent":"Self"
    },
    {
      "applicationNo":"456547564",
      "reimbursementType":"CHC",
      "requestDate":"26/02/2024",
      "amountClaim":"1000",
      "amountToBePaid":"1000",
      "selfDependent":"Self"
    },
    {
      "applicationNo":"353465444",
      "reimbursementType":"CHC",
      "requestDate":"26/02/2024",
      "amountClaim":"1000",
      "amountToBePaid":"1000",
      "selfDependent":"Self"
    },
  ].obs;
  var formKey = GlobalKey<FormState>().obs;
  var openView = 0.obs;
  var fileName = "Please choose (.pdf) file (1mb)".obs;
  var file = new File("").obs;

  var repo = new ClaimsRepo();
  var claimData =  [].obs;
  var loading = AppLoadingState.Initial.obs;
  Helper helper = new Helper();

  var selcClimType = "Select Claim Type".obs;
  var selcClimTypeValue = "".obs;
  var selfDependent = "Select self or dependent".obs;
  var selfDependentValue = "".obs;

  var retireeEmpName = TextEditingController().obs;
  var depSpName = TextEditingController().obs;
  var chcDate = TextEditingController().obs;
  var amtPaid = TextEditingController().obs;
  var fileSize = "".obs;

  selectFile() async{
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      allowMultiple: true
    );
    result?.files.first.bytes;
    fileName.value = result!.files.first.name.toString();
    List<File> files = result.paths.map((path)=>File(path!)).toList();
    file.value = files.first;
    fileSize.value = ((await file.value.length())/1000000).toString();
    print(file.value.lengthSync());
  }

  getClaimsList() async{
    try{
      loading.value = AppLoadingState.Loading;
      var res = await repo.getClaimList();
      var data = jsonDecode(await res.stream.bytesToString());
      // ClaimsDataModel dataGet = ClaimsDataModel.fromJson(json);
      claimData.add(data);
      loading.value = AppLoadingState.Loaded;
      print(claimData.first.length);
    }
    catch(e){

    }
  }

  void validateForm() {
    final isValid = formKey.value.currentState?.validate();
    if (!isValid!) {
      // submitForm();
      return;
    }else{
      submitData();
    }
    formKey.value.currentState?.save();
  }

  submitData() async{
    var grade = await helper.getSharedPrefString(keyName: "empGrade");
    var userid = await helper.getSharedPrefString(keyName: "userid");
    var data = {
      "reimbursement":"${selcClimTypeValue.value}",
      "selfDependent":"${selfDependentValue.value}",
      "dependentName":"${retireeEmpName.value.text}",
      "amountToBePaid":"${amtPaid.value.text}",
      "requestDate":"${chcDate.value.text.removeAllWhitespace}",
      "grade":"${grade}",
      "username":"$userid",
      "applicationUsed":"M"
    };
    print(file.value.path);
    if(file.value.path == null){
      helper.messageAlert(title: "Error", message: "Please select file", type: AlertBoxType.Error);
    }
    if(await file.value.length() > 1000000){
      helper.messageAlert(title: "File size error", message: "Please select file less then or equal to 1MB", type: AlertBoxType.Error);
    }
    else{
      helper.fullAppLoading();
      var res = await repo.submitData(datas: data,files: file.value.path);
      var jsonD =  jsonDecode(res.toString());
      // if(jsonD['responseCode'] == "F" && jsonD['responseCode'] != null){
      //   Get.back();
      //   helper.messageAlert(title: "Message", message: "${jsonD['message']}", type: AlertBoxType.Error);
      // }
      // else if(jsonD['responseCode'] == null){
      //   Get.back();
      //   helper.messageAlert(title: "Message", message: "${jsonD['detail']}", type: AlertBoxType.Error);
      // }
      print(jsonD);
      if(jsonD['status'] == "error"){
        Get.back();
        helper.messageAlert(title: "Message", message: "${jsonD['msg']}", type: AlertBoxType.Error);
      }
      else if(jsonD['status'] == "TE"){
        helper.messageAlert(title: "Message", message: "Token Expired", type: AlertBoxType.Error);
      }
      else{
        getClaimsList();
        Get.back();
        var msg = jsonD['msg']??jsonD['detail'];
        helper.doneDialog(msg: "$msg",onClose: (){
          Get.back();
          Get.back();
        });
      }
    }
    dispose();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getClaimsList();
  }

}