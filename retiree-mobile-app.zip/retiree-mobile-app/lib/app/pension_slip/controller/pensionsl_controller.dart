import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/pension_slip/model/pension_data.dart';
import 'package:sidbi_app/app/pension_slip/repo/pension_repo.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/components/pdf_view.dart';
// import 'package:syncfusion_flutter_datepicker/datepicker.dart';

class PayController extends GetxController {
  // var datePicController = DateRangePickerController().obs;
  var dobCtrl = TextEditingController().obs;
  var yearController = TextEditingController().obs;

  var empname = TextEditingController().obs;
  var address = TextEditingController().obs;

  var name = "".obs;
  var dobDet = "".obs;
  var addr = "".obs;

  var pensionViewString = "Pension slip / Form 16 / Estimate".obs;
  var pensionDropSelected = "Select the Estimate".obs;

  var monthViewString = "Month".obs;
  var monthDropSelected = "Select the month".obs;

  var yearViewString = "Select year".obs;
  var yearDropSelected = "Select the year for document".obs;
  var adminuserid = "".obs;
  Helper helper = new Helper();
  PensionRepo penRepo = new PensionRepo();
  var userids = "".obs;

  getDetail() async {
    helper.fullAppLoading();
    var userid = await helper.getSharedPrefString(keyName: 'userid');
    
    var userFor = await helper.getSharedPrefString(keyName: 'userFor');
    
    PensionSlipData penData = PensionSlipData(
        userId: userFor??userid,
        listOption: pensionDropSelected.value,
        month: monthDropSelected.value,
        year: "${yearController.value.text}");
    print(penData.userId);
    var res = await penRepo.getPensionDetails(penData);

    try{
      Get.back();
      helper.messageAlert(
              title: "Information",
              message: "File have been downloaded to your 'Download' floder",
              type: AlertBoxType.Error);
      Get.to(() => PdfViewPage(), arguments: res.uri.path);
    }catch(e){
      // print("sdjkfh");
      Get.back();
      // print(jsonDecode(res.body));
      helper.messageAlert(title: "Error", message: "Some error occurred", type: AlertBoxType.Error);
    }
  }

  //itsec team


  setDropValue(data) {
    List<String> str = data.replaceAll("{", "").replaceAll("}", "").split(",");
    Map<String, dynamic> result = {};
    for (int i = 0; i < str.length; i++) {
      List<String> s = str[i].split(":");
      result.putIfAbsent(s[0].trim(), () => s[1].trim());
    }
    return result;
  }

  showYearPicker() {
    return Get.bottomSheet(
      backgroundColor: Colors.transparent,
      Container(
        decoration: BoxDecoration(color: Colors.white),
        child: YearPicker(
          firstDate: DateTime(DateTime.now().year - 70, 1),
          lastDate: DateTime.now(),
          selectedDate: DateTime.now(),
          onChanged: (DateTime value) {
            print(value.year);
            yearController.value.text = "${value.year}";
            yearDropSelected.value = "${value.year}";
            Get.back();
          },
        ),
      ),
    );
  }

  setFields() async{
    userids.value = await helper.getSharedPrefString(keyName: 'userid');
    var empName = await helper.getSharedPrefString(keyName: "fullName");
    var addressVal = await helper.getSharedPrefString(keyName: "empAddress");
    var dobs = await helper.getSharedPrefString(keyName: "empDOB");
    name.value = empName??"";
    addr.value = addressVal??"";
    dobDet.value = dobs??"";
    empname.value.text = empName??"";
    address.value.text = addressVal??"";
    dobCtrl.value.text = dobs??"";
  }

  @override
  void onInit() async{
    // TODO: implement onInit
    super.onInit();
    print("Hello2");
    userids.value = await helper.getSharedPrefString(keyName: 'userid');
    if(userids.value == "EEFC99"){
      adminuserid.value = await helper.getSharedPrefString(keyName: "userFor");
      empname.value.text = adminuserid.value;
    }
    setFields();
  }
}
