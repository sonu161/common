import "package:flutter/material.dart";
import "package:get/get.dart";
import "package:sidbi_app/app/pension_slip/controller/pensionsl_controller.dart";
import "package:sidbi_app/components/input_field.dart";

import "../../../components/date_input.dart";
import "../../../components/text_area.dart";
import "../../login/repos/static_datas.dart";

class PensionSlip extends StatefulWidget {
  const PensionSlip({super.key});

  @override
  State<PensionSlip> createState() => _PensionSlipState();
}

class _PensionSlipState extends State<PensionSlip> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.onBackground,
      appBar: AppBar(
        title: Text(
          "PENSION SLIP/FORM 16".tr,
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.only(top: 20),
        child: Container(
          margin: EdgeInsets.only(left: 15, right: 15),
          padding: EdgeInsets.only(top: 20, bottom: 20, left: 20, right: 20),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)]),
          child: GetX(
            init: PayController(),
            builder: (ctrl) {
              return Column(
                children: [
                  SizedBox(
                    height: 40,
                  ),
                  Text("Pension Slip / Form 16 / Estimate".tr,
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: Colors.black54)),
                  SizedBox(
                    height: 40,
                  ),
                  Column(
                    children: [
                      // Container(
                      //   decoration: BoxDecoration(
                      //       border: Border(
                      //         top: BorderSide(color: Colors.black12),
                      //         left: BorderSide(color: Colors.black12),
                      //         right: BorderSide(color: Colors.black12),
                      //       ),
                      //       borderRadius: BorderRadius.only(
                      //           topLeft: Radius.circular(5),
                      //           topRight: Radius.circular(5))),
                      //   child: TextField(
                      //     decoration: InputDecoration(
                      //         contentPadding: EdgeInsets.only(
                      //             left: 15, right: 15, top: 10, bottom: 10),
                      //         border: UnderlineInputBorder(
                      //             borderSide: BorderSide(
                      //                 color:
                      //                     Theme.of(context).colorScheme.primary)),
                      //         hintText: "Enter your name here",
                      //         label: Text("Employee Name")),
                      //   ),
                      // ),
                      InputField(
                        hint: "Enter Name".tr,
                        borderRadius: 6,
                        fullLabel: true,
                        fullLabelText: "Employee Name".tr,
                        textEditingController: ctrl.empname.value,
                        readOnly: true,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      DateInput(
                        hint: "DD/MM/YYYY",
                        textEditingController: ctrl.dobCtrl.value,
                        readOnly: true,
                        fullLabelText: "Date of birth".tr,
                        fullLabel: true,
                        borderRadius: 6,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      TextArea(
                        fullLabel: true,
                        fullLabelText: "Address".tr,
                        hint: "Enter address".tr,
                        borderRadius: 6,
                        textEditingController: ctrl.address.value,
                        readOnly: true,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Container(
                        padding: EdgeInsets.only(
                            top: 6, bottom: 6, left: 15, right: 15),
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black12),
                            borderRadius: BorderRadius.circular(7)),
                        child: DropdownButton<String>(
                          // pensionViewString,

                          // hint: Text("Pension slip / Form 16 / Estimate"),
                          hint: Text(
                            "${ctrl.pensionViewString.value}".tr,
                            style: TextStyle(
                                color: ctrl.pensionDropSelected.value == ""
                                    ? Colors.black54
                                    : Colors.black),
                          ),
                          underline: Container(
                            height: 0,
                            width: 0,
                          ),
                          isExpanded: true,
                          items: StaticDatas()
                              .pension_sslips
                              .map((Map<String, String> value) {
                            return DropdownMenuItem(
                              value: value.toString(),
                              child: Text(value['name']!.tr), //dynamic
                            );
                          }).toList(),
                          onChanged: (val) {
                            var result = ctrl.setDropValue(val);
                            ctrl.pensionViewString.value = result['name'];
                            ctrl.pensionDropSelected.value = result['val'];
                            // ctrl.pensionViewString.value = val.toString();
                          },
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Container(
                        padding: EdgeInsets.only(
                            top: 6, bottom: 6, left: 15, right: 15),
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.black12),
                            borderRadius: BorderRadius.circular(7)),
                        child: DropdownButton<String>(
                          hint: Text(
                            "${ctrl.monthViewString.value}".tr,
                            style: TextStyle(
                                color: ctrl.monthDropSelected.value == ""
                                    ? Colors.black54
                                    : Colors.black),
                          ),
                          underline: Container(
                            height: 0,
                            width: 0,
                          ),
                          isExpanded: true,
                          items: StaticDatas()
                              .month
                              .map((Map<String, String> value) {
                            return DropdownMenuItem(
                              value: value.toString(),
                              child: Text(value['name']!), //dynamic
                            );
                          }).toList(),
                          onChanged: (val) {
                            // print(val);
                            var result = ctrl.setDropValue(val);
                            ctrl.monthViewString.value = result['name'];
                            ctrl.monthDropSelected.value = result['val'];
                            // ctrl.pensionViewString.value = val.toString();
                          },
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      // Container(
                      //   padding: EdgeInsets.only(
                      //       top: 6, bottom: 6, left: 15, right: 15),
                      //   decoration: BoxDecoration(
                      //       border: Border.all(color: Colors.black12),
                      //       borderRadius: BorderRadius.circular(7)),
                      //   child: DropdownButton<String>(
                      //     hint: Text("Year"),
                      //     underline: Container(
                      //       height: 0,
                      //       width: 0,
                      //     ),
                      //     isExpanded: true,
                      //     items:
                      //         <String>['A', 'B', 'C', 'D'].map((String value) {
                      //       return DropdownMenuItem<String>(
                      //         value: value,
                      //         child: Text(value),
                      //       );
                      //     }).toList(),
                      //     onChanged: (_) {},
                      //   ),
                      // )
                      InputField(
                        hint: "Pick year".tr,
                        readOnly: true,
                        borderRadius: 6,
                        textEditingController: ctrl.yearController.value,
                        onTap: () {
                          ctrl.showYearPicker();
                        },
                      )
                    ],
                  )
                ],
              );
            },
          ),
        ),
      ),
      bottomNavigationBar: Container(
        height: 80,
        decoration: BoxDecoration(color: Colors.white),
        child: Container(
          padding: EdgeInsets.fromLTRB(10, 15, 15, 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width / 2.5,
                child: Material(
                  color: Theme.of(context).colorScheme.primary,
                  borderRadius: BorderRadius.circular(300),
                  child: InkWell(
                    onTap: () {
                      var ctrl = Get.find<PayController>();
                      ctrl.getDetail();
                    },
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 10,
                          ),
                          Expanded(
                            child: Text(
                              textAlign: TextAlign.center,
                              "Get Detail",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15),
                            ),
                          ),
                          CircleAvatar(
                            backgroundColor: Colors.white.withOpacity(0.5),
                            child: Icon(
                              Icons.chevron_right,
                              color: Colors.black,
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
