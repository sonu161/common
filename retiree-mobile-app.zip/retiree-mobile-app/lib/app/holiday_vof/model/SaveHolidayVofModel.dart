class SaveHolidayVofModel {
  SaveHolidayVofModel({
      this.empName, 
      this.userId, 
      this.userEmail, 
      this.holidayhome, 
      this.hhListVal, 
      this.vofListVal, 
      this.startDate, 
      this.endDate, 
      this.startTime, 
      this.endTime, 
      this.noOfRooms, 
      this.noOfPeople, 
      this.contactNumber, 
      this.description, 
      this.purpose, 
      this.message, 
      this.applicationUsed,});

  SaveHolidayVofModel.fromJson(dynamic json) {
    empName = json['empName'];
    userId = json['userId'];
    userEmail = json['userEmail'];
    holidayhome = json['holidayhome'];
    hhListVal = json['hhListVal'];
    vofListVal = json['vofListVal'];
    startDate = json['startDate'];
    endDate = json['endDate'];
    startTime = json['startTime'];
    endTime = json['endTime'];
    noOfRooms = json['noOfRooms'];
    noOfPeople = json['noOfPeople'];
    contactNumber = json['contactNumber'];
    description = json['description'];
    purpose = json['purpose'];
    message = json['message'];
    applicationUsed = json['applicationUsed'];
  }
  String? empName;
  String? userId;
  String? userEmail;
  String? holidayhome;
  String? hhListVal;
  String? vofListVal;
  String? startDate;
  String? endDate;
  String? startTime;
  String? endTime;
  String? noOfRooms;
  String? noOfPeople;
  String? contactNumber;
  String? description;
  String? purpose;
  String? message;
  String? applicationUsed;
SaveHolidayVofModel copyWith({  String? empName,
  String? userId,
  String? userEmail,
  String? holidayhome,
  String? hhListVal,
  String? vofListVal,
  String? startDate,
  String? endDate,
  String? startTime,
  String? endTime,
  String? noOfRooms,
  String? noOfPeople,
  String? contactNumber,
  String? description,
  String? purpose,
  String? message,
  String? applicationUsed,
}) => SaveHolidayVofModel(  empName: empName ?? this.empName,
  userId: userId ?? this.userId,
  userEmail: userEmail ?? this.userEmail,
  holidayhome: holidayhome ?? this.holidayhome,
  hhListVal: hhListVal ?? this.hhListVal,
  vofListVal: vofListVal ?? this.vofListVal,
  startDate: startDate ?? this.startDate,
  endDate: endDate ?? this.endDate,
  startTime: startTime ?? this.startTime,
  endTime: endTime ?? this.endTime,
  noOfRooms: noOfRooms ?? this.noOfRooms,
  noOfPeople: noOfPeople ?? this.noOfPeople,
  contactNumber: contactNumber ?? this.contactNumber,
  description: description ?? this.description,
  purpose: purpose ?? this.purpose,
  message: message ?? this.message,
  applicationUsed: applicationUsed ?? this.applicationUsed,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['empName'] = empName;
    map['userId'] = userId;
    map['userEmail'] = userEmail;
    map['holidayhome'] = holidayhome;
    map['hhListVal'] = hhListVal;
    map['vofListVal'] = vofListVal;
    map['startDate'] = startDate;
    map['endDate'] = endDate;
    map['startTime'] = startTime;
    map['endTime'] = endTime;
    map['noOfRooms'] = noOfRooms;
    map['noOfPeople'] = noOfPeople;
    map['contactNumber'] = contactNumber;
    map['description'] = description;
    map['purpose'] = purpose;
    map['message'] = message;
    map['applicationUsed'] = applicationUsed;
    return map;
  }

}