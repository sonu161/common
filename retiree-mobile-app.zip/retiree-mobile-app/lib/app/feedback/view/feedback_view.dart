import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/feedback/controller/feedback_controller.dart';
import 'package:sidbi_app/components/main_button.dart';
import 'package:sidbi_app/components/text_area.dart';

class FeedbackView extends StatelessWidget {
  const FeedbackView({super.key});

  @override
  Widget build(BuildContext context) {
    return FeedbackLoaderState();
  }
}

class FeedbackLoaderState extends StatefulWidget {
  const FeedbackLoaderState({super.key});

  @override
  State<FeedbackLoaderState> createState() => _FeedbackLoaderStateState();
}

class _FeedbackLoaderStateState extends State<FeedbackLoaderState> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        child: Center(
          child: SingleChildScrollView(
            child: GetX(
              init: FeedbackController(),
              builder: (ctrl) {
                print(ctrl.selectedFeeling.value);
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Image.asset(
                      "assets/images/sidbi_logo.gif",
                      width: 150,
                    ),
                    SizedBox(
                      height: 100,
                    ),
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(color: Colors.black45, blurRadius: 10)
                          ]),
                      margin: EdgeInsets.fromLTRB(20, 0, 20, 0),
                      child: Column(
                        children: [
                          Container(
                            padding: EdgeInsets.fromLTRB(15, 10, 15, 0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.feedback, color: Theme.of(context).colorScheme.primary,),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "Feedback",
                                      style: TextStyle(
                                          fontWeight: FontWeight.w700,
                                          color: Theme.of(context).colorScheme.primary
                                      ),
                                    ),
                                  ],
                                ),
                                IconButton(
                                    onPressed: () {
                                      Get.back();
                                    },
                                    icon: Icon(Icons.close))
                              ],
                            ),
                          ),
                          Divider(
                            color: Colors.black12,
                          ),
                          Container(
                            padding: EdgeInsets.only(top: 10),
                            child: Center(
                              child: Text(
                                "How are you feeling".tr,
                                style: TextStyle(
                                    fontSize: 25, fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.only(top: 10, bottom: 10),
                            child: Center(
                              child: Text(
                                "Your input is valuable in helping us better understand \n your needs and tailor our service accordingly"
                                    .tr,
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    color: Colors.black45),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                          // Divider(
                          //   color: Colors.black12,
                          // ),
                          Container(
                            padding: EdgeInsets.only(top: 10, bottom: 10),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                ratingContainer(
                                    onTap: () {
                                      ctrl.selectedFeeling.value = "1";
                                    },
                                    ratingIcon: "😢",
                                    selected: ctrl.selectedFeeling.value == "1"
                                        ? true
                                        : false),
                                SizedBox(
                                  width: 10,
                                ),
                                ratingContainer(
                                    onTap: () {
                                      ctrl.selectedFeeling.value = "2";
                                    },
                                    ratingIcon: "😞",
                                    selected: ctrl.selectedFeeling.value == "2"
                                        ? true
                                        : false),
                                SizedBox(
                                  width: 10,
                                ),
                                ratingContainer(
                                    onTap: () {
                                      ctrl.selectedFeeling.value = "3";
                                    },
                                    ratingIcon: "😌",
                                    selected: ctrl.selectedFeeling.value == "3"
                                        ? true
                                        : false),
                                SizedBox(
                                  width: 10,
                                ),
                                ratingContainer(
                                    onTap: () {
                                      ctrl.selectedFeeling.value = "4";
                                    },
                                    ratingIcon: "😄",
                                    selected: ctrl.selectedFeeling.value == "4"
                                        ? true
                                        : false),
                                SizedBox(
                                  width: 10,
                                ),
                                ratingContainer(
                                    onTap: () {
                                      ctrl.selectedFeeling.value = "5";
                                    },
                                    ratingIcon: "🤩",
                                    selected: ctrl.selectedFeeling.value == "5"
                                        ? true
                                        : false),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Container(
                              padding: EdgeInsets.only(
                                  left: 15, right: 15, bottom: 10),
                              child: TextArea(
                                hint: "Add a comment",
                                borderRadius: 10,
                              )),
                          SizedBox(
                            height: 20,
                          ),
                          Container(
                              padding: EdgeInsets.only(
                                  left: 15, right: 15, bottom: 10),
                              child: MainButton(
                                buttonLable: "Submit",
                                borderRadius: 10,
                              )),
                          SizedBox(
                            height: 20,
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  Widget ratingContainer({ratingIcon, required bool selected, onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: CircleAvatar(
        backgroundColor: selected
            ? Color.fromARGB(255, 114, 167, 29)
            : Color.fromARGB(255, 218, 218, 218),
        minRadius: 30,
        maxRadius:30,
        child: Text(
          "$ratingIcon",
          style: TextStyle(fontSize: 30),
        ),
      ),
    );
  }
}
