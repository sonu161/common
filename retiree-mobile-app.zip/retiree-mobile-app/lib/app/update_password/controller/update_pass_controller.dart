import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/forget_password/controller/forgot_pass_controller.dart';
import 'package:sidbi_app/app/login/views/login_page.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/app/login/repos/login_repo.dart';

import '../../../components/comp_controllers/loading_controller.dart';
import '../../login/controller/loging_ctrl.dart';
import '../../login/views/captcha_view.dart';

class UpdatePassController extends GetxController {
  var obsecurePass = true.obs;
  var obsecureConPass = true.obs;
  var appLoadingState = AppLoadingState.Initial.obs;
  var formKey = GlobalKey<FormState>(debugLabel: "updateForm").obs;
  var newPassCtrl = TextEditingController().obs;
  var conPassCtrl = TextEditingController().obs;
  var otpPassCtrl = TextEditingController().obs;
  var captchaCtrl = TextEditingController().obs;
  var captcha = TextEditingController().obs;
  LoginRepo repo = new LoginRepo();
  var newPassCheck = false.obs;
  var conPassCheck = false.obs;
  var otpCheck = false.obs;
  var loadingCtrl = Get.find<LoadingController>();
  Helper helper = new Helper();
  LoginRepo loginrepo = new LoginRepo();
  var captchaImage = "".obs;
  var captchValue = "".obs;

  var userid;
  var passwordSubmited = true.obs;

  Timer? timer;
  var timeShow = 20.obs;

  UpdatePassController({this.userid});

  get id => userid;

  set ids(val) {
    userid = val;
  }

  changeObsecurePass({required RxBool varibleName}) {
    if (varibleName.value == false) {
      varibleName.value = true;
    } else {
      varibleName.value = false;
    }
  }

  checkFields() async {
    // if (newPassCtrl.value.text == "" &&
    //     conPassCtrl.value.text == "" &&
    //     otpPassCtrl.value.text == "") {
    //   newPassCheck.value = true;
    //   conPassCheck.value = true;
    //   otpCheck.value = true;
    // } else if (newPassCtrl.value.text != "" &&
    //     conPassCtrl.value.text == "" &&
    //     otpPassCtrl.value.text == "") {
    //   newPassCheck.value = false;
    //   conPassCheck.value = true;
    //   otpCheck.value = true;
    // } else if (newPassCtrl.value.text == "" &&
    //     conPassCtrl.value.text != "" &&
    //     otpPassCtrl.value.text == "") {
    //   newPassCheck.value = true;
    //   conPassCheck.value = false;
    //   otpCheck.value = true;
    // } else if (newPassCtrl.value.text == "" &&
    //     conPassCtrl.value.text == "" &&
    //     otpPassCtrl.value.text != "") {
    //   newPassCheck.value = true;
    //   conPassCheck.value = true;
    //   otpCheck.value = false;
    // } else {
    //   if (otpPassCtrl.value.text == "") {
    //     otpCheck.value = true;
    //   } else {
    //     print(otpPassCtrl.value.text);
    //     newPassCheck.value = false;
    //     conPassCheck.value = false;
    //     otpCheck.value = false;
    //     getCaptcha();
    //   }
    // }
    final isValid = formKey.value.currentState?.validate();
    if (!isValid!) {
      return;
    } else {
      sendForUpdatePassword();
    }
  }

  getCaptcha() async {
    try {
      appLoadingState.value = AppLoadingState.Loading;
      var resData = await loginrepo.getCaptcha();
      if (resData.statusCode == 200) {
        var jsonData = jsonDecode(resData.body);
        captchaImage.value = jsonData['captcha'];
        captchValue.value = jsonData['text'];
        print(captchValue.value);
        // captchaSheet();
        appLoadingState.value = AppLoadingState.Loaded;
      } else if (resData.statusCode == 404) {
        Get.snackbar("Network Error",
            "System is under maintenance, Please tyr after some time",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.FLOATING,
            backgroundColor: Colors.white,
            duration: Duration(seconds: 20));
        appLoadingState.value = AppLoadingState.Error;
        // captchaSheet();
      } else {
        Get.snackbar("Network Error", "${resData.body}",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.FLOATING,
            backgroundColor: Colors.white);
        appLoadingState.value = AppLoadingState.Error;
        // captchaSheet();
      }
    } catch (e) {
      Get.snackbar("Login Error",
          "Network is not reachable, please try after some time.".tr,
          colorText: Colors.red,
          snackPosition: SnackPosition.BOTTOM,
          snackStyle: SnackStyle.FLOATING,
          backgroundColor: Colors.white,
          margin: EdgeInsets.only(bottom: 10, left: 10, right: 10),
          duration: Duration(seconds: 40));
      // captchaSheet();
    }
  }

  // getCaptcha() async {
  //   try {
  //     loadingCtrl.appLoadingState.value = AppLoadingState.Loading;
  //     var resData = await loginrepo.getCaptcha();
  //     if (resData.statusCode == 200) {
  //       var jsonData = jsonDecode(resData.body);
  //       captchaImage.value = jsonData['captcha'];
  //       captchValue.value = jsonData['text'];
  //       captchaSheet();
  //       loadingCtrl.appLoadingState.value = AppLoadingState.Loaded;
  //     } else if (resData.statusCode == 404) {
  //       Get.snackbar("Network Error",
  //           "System is under maintenance, Please tyr after some time",
  //           snackPosition: SnackPosition.BOTTOM,
  //           snackStyle: SnackStyle.FLOATING,
  //           backgroundColor: Colors.white,
  //           duration: Duration(seconds: 20));
  //       loadingCtrl.appLoadingState.value = AppLoadingState.Error;
  //       // captchaSheet();
  //     } else {
  //       Get.snackbar("Network Error", "${resData.body}",
  //           snackPosition: SnackPosition.BOTTOM,
  //           snackStyle: SnackStyle.FLOATING,
  //           backgroundColor: Colors.white);
  //       loadingCtrl.appLoadingState.value = AppLoadingState.Error;
  //       ;
  //       // captchaSheet();
  //     }
  //   } catch (e) {
  //     Get.snackbar("Login Error",
  //         "Network is not reachable, please try after some time.".tr,
  //         colorText: Colors.red,
  //         snackPosition: SnackPosition.BOTTOM,
  //         snackStyle: SnackStyle.FLOATING,
  //         backgroundColor: Colors.white,
  //         margin: EdgeInsets.only(bottom: 10, left: 10, right: 10),
  //         duration: Duration(seconds: 40));
  //     captchaSheet();
  //   }
  // }

  //
  captchaSheet() {
    Get.bottomSheet(
      backgroundColor: Colors.white,
      enableDrag: true,
      isScrollControlled: false,
      SizedBox(
        height: 300,
        child: CaptchaView(
          ontap: () {
            sendForUpdatePassword();
          },
          capTchaText: captchaCtrl.value,
          imageBase64: captchaImage.value,
        ),
      ),
    );
  }

  sendForUpdatePassword() async {
    try {
      if (!otpPassCtrl.value.text.isBlank!) {
        helper.fullAppLoading();
        loadingCtrl.refreshingState.value = RefreshState.Loading;
        var newPass = helper.shaConverter(newString: newPassCtrl.value.text);
        var conFirmPass =
            helper.shaConverter(newString: conPassCtrl.value.text);
        var res = await loginrepo.updatePassword(
          newPassword: "12345${newPass}12345",
          confirmPassword: "12345${conFirmPass}12345",
          captcha: captchaCtrl.value.text,
          orgCaptcha: captchaCtrl.value.text,
          userid: id,
          otp: otpPassCtrl.value.text,
        );
        loadingCtrl.refreshingState.value = RefreshState.Loaded;
        print(res.body);
        if (res.statusCode == 200) {
          print(jsonDecode(res.body)['errorMsg']);
          if (jsonDecode(res.body)['errorMsg'] == "success") {
            Get.back();
            helper
              ..messageAlert(
                  title: "Update Successfully",
                  message: "Your password got updated successfully".tr,
                  type: AlertBoxType.Error);

            Get.off(() => LoginPage());
          }
        } else {
          helper.messageAlert(
              title: "Error",
              message: "Something went wrong, please try again".tr,
              type: AlertBoxType.Error);
        }
      }else{
        helper.messageAlert(
              title: "OTP Error",
              message: "Please enter correct otp",
              type: AlertBoxType.Error);
      }
    } catch (e) {}
  }

  checkConfirmPass({val, whichField}) {
    if (val == newPassCtrl.value.text) {}
  }

  refreshCaptcha() async {
    try {
      loadingCtrl.refreshingState.value = RefreshState.Loading;
      var resData = await loginrepo.getCaptcha();
      if (resData.statusCode == 200) {
        var jsonData = jsonDecode(resData.body);
        captchaImage.value = jsonData['captcha'];
        captchValue.value = jsonData['text'];
        loadingCtrl.refreshingState.value = RefreshState.Loaded;
      } else {
        Get.snackbar("Network Error", "${resData.body}",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.GROUNDED);
        loadingCtrl.refreshingState.value = RefreshState.Error;
        ;
      }
      print(loadingCtrl.refreshingState.value);
    } catch (e) {
      print(e);
    }
  }

  startTimer() async{
    timeShow.value = 20;
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      timeShow.value = timeShow.value-1;
      print(timeShow.value);
      if(timeShow.value == 0){
        timer.cancel();
      }
    });
  }

  resendOtp({useridParse}) async{
    try{
      // var ctrl = Get.find<LogingCtrl>();
      // var userid = useridParse == null?ctrl.emailCtrl.value.text:useridParse;
      var res = await repo.reSendOtp(useridParse);
      print("${res.body}");
      if(res.statusCode == 200){
        startTimer();
        Get.snackbar("Message", "${jsonDecode(res.body)['successMsg']}",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.FLOATING,
            backgroundColor: Colors.white,
        duration: Duration(seconds: 20));
      }

    }catch(e){
      Get.snackbar("Otp Error", "Network not found",
          snackPosition: SnackPosition.BOTTOM,
          snackStyle: SnackStyle.FLOATING,
          backgroundColor: Colors.white);
    }
  }


  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getCaptcha();
        timer = Timer.periodic(Duration(seconds: 1), (timer) {
      timeShow.value = timeShow.value-1;
      print(timeShow.value);
      if(timeShow.value == 0){
        timer.cancel();
      }
    });
  }
}
