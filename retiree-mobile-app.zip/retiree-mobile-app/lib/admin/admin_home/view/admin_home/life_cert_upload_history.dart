import 'package:flutter/Material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/controller/life_cert_upload_hst_controller.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/no_data.dart';

class LifeCertUploadHistory extends StatelessWidget {
  const LifeCertUploadHistory({super.key});

  @override
  Widget build(BuildContext context) {
    return LifeCertUploadLoader();
  }
}
class LifeCertUploadLoader extends StatefulWidget {
  const LifeCertUploadLoader({super.key});

  @override
  State<LifeCertUploadLoader> createState() => _LifeCertUploadLoaderState();
}

class _LifeCertUploadLoaderState extends State<LifeCertUploadLoader> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Life Certificate Upload History"),
            GetX(
              init: LifeCertUploadHstController(),
              builder: (ctrl){
                return Text("Files: ${ctrl.dataList.length}");
              }
            )
          ],
        ),
      ),
      body: GetX(
        init: LifeCertUploadHstController(),
        builder: (ctrl){
          if(ctrl.loading.value == AppLoadingState.Loading){
            return Center(
              child: CircularProgressIndicator(),
            );
          }else{
            if(ctrl.dataList.length > 0){
              return ListView.builder(
                itemCount: ctrl.dataList.length,
                itemBuilder: (context, index) {
                  return Container(
                      decoration: BoxDecoration(
                          color: Colors.white
                      ),
                      child: ListTile(
                        onTap: (){
                          ctrl.downloadFile(year: "${ctrl.dataList[index]['year']}");
                        },
                        title: Text("${ctrl.dataList[index]['uploadedDate']}"),
                        subtitle: Text("${ctrl.dataList[index]['year']}"),
                        trailing: Icon(
                          Icons.download,
                          color: Theme.of(context).colorScheme.error,
                        ),
                      )
                  );
                },
              );
            }else{
              return NoData(
                refresh: (){
                  ctrl.getLifeCertHistory();
                },
              );
            }
          }
        },
      ),
    );
  }
}
