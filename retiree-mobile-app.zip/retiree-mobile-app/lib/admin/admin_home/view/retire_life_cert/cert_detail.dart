import 'dart:convert';

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/Material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/controller/retiree_life_cert_controller.dart';
import 'package:sidbi_app/components/main_button.dart';

class CertDetail extends StatelessWidget {
  const CertDetail(
      {super.key, this.fName, this.fileNmae, this.uploadedDate, this.status,this.userid});
  final String? fName;
  final String? fileNmae;
  final String? uploadedDate;
  final String? status;
  final String? userid;

  @override
  Widget build(BuildContext context) {
    return _CertDetailLoaderState(
      fName: this.fName,
      fileNmae: this.fileNmae,
      status: this.status,
      uploadedDate: this.uploadedDate,
      userid: this.userid,
    );
  }
}

class _CertDetailLoaderState extends StatefulWidget {
  const _CertDetailLoaderState(
      {super.key, this.fName, this.fileNmae, this.uploadedDate, this.status, this.userid});

  final String? fName;
  final String? fileNmae;
  final String? uploadedDate;
  final String? status;
  final String? userid;

  @override
  State<_CertDetailLoaderState> createState() => __CertDetailLoaderStateState();
}

class __CertDetailLoaderStateState extends State<_CertDetailLoaderState> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("${widget.fName}"),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white
              ),
              padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("${widget.status}",style: TextStyle(fontSize: 15,color: Theme.of(context).colorScheme.secondary,fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            Center(
              child: Container(
                margin: EdgeInsets.only(top: 20),
                child: DottedBorder(
                  child: Container(
                    height: MediaQuery.of(context).size.width / 1.1,
                    width: MediaQuery.of(context).size.width / 1.1,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12)),
                    child: Center(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          widget.fileNmae == null || widget.fileNmae == ""
                              ? Container()
                              : Image.asset(
                                  "assets/icons/pdf-icon.png",
                                  width: 100,
                                  height: 100,
                                ),
                          SizedBox(
                            height: 20,
                          ),
                          Text(widget.fileNmae == null || widget.fileNmae == ""
                              ? "No file found"
                              : "${widget.fileNmae}")
                        ],
                      ),
                    ),
                  ),
                  borderType: BorderType.RRect,
                  radius: Radius.circular(12),
                  strokeWidth: 2,
                  dashPattern: [10],
                  color: Colors.black26,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(20, 20, 20, 10),
              child: Column(
                children: [
                  MainButton(
                    buttonLable: "Download",
                    disabled: widget.fileNmae == null || widget.fileNmae == ""
                        ? true
                        : false,
                    onTap: () {
                      var ctrl = Get.find<RetireeLifeCertController>();
                      ctrl.downloadCertificate(fileName: widget.fileNmae, userid: widget.userid);
                    },
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
