import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/entities/admin_home_entiry/retiree_life_cert_entity.dart';

class RetireeLifeCertRepo extends RetireeLifeCertEntity{

  Helper helper = new Helper();

  @override
  getLifeCertsList({year}) async{
    try{
      var logUserid = await helper.getSharedPrefString(keyName: "userid");
      var res = await helper.getService("getRetireeLifeCerificates/$year/$logUserid");
      return res;
    }catch(e){

    }
  }

  @override
  getFinancialYears() async{
    try{
      var logUserid = await helper.getSharedPrefString(keyName: "userid");
      var res = await helper.getService("getFinancialYearList/$logUserid");
      return res;
    }catch(e){

    }
  }

  downloadCertificate({fileName,userid}) async{
    var adminId = await helper.getSharedPrefString(keyName: "userid");
    // var userid = await helper.getSharedPrefString(keyName: "userFor");
    var file = await helper.downloadPdfFile(
      setFileName: "${fileName.toString().replaceAll(" ", "_")}.pdf",
      url: "downloadLifeCertiPDFAppByFileName/$adminId/$userid/$fileName",
      type: "GET",
    );
    return file;
  }

}