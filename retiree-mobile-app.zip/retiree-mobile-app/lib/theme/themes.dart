import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:google_fonts/google_fonts.dart';

class CustomTheme {
  final Color primaryColor = Color.fromARGB(255, 0, 93, 168);
  var lightTheme = ThemeData(
    useMaterial3: true,
    colorScheme: const ColorScheme.light(
      primary: Color.fromARGB(255, 0, 93, 168),
      onPrimary: Colors.white,
      onBackground: Color(0xffF5F5F5),
      onPrimaryContainer: Color(0xffF5F5F5),
      onSecondary: Color(0xff013e59),
      background: Color.fromARGB(255, 231, 231, 231),
      secondary: Color.fromARGB(255, 228, 238, 248),
      error: Color(0xffFA8284),
      outline: Color.fromARGB(44, 41, 41, 41),
      inversePrimary: Color.fromARGB(255, 0, 93, 168)
    ),
    textTheme: TextTheme(
      bodyLarge: fontFamily,
      bodyMedium: fontFamily,
      bodySmall: fontFamily,
      displayLarge: fontFamily,
      displayMedium: fontFamily,
      displaySmall: fontFamily,
      headlineLarge: fontFamily,
      headlineMedium: fontFamily,
      headlineSmall: fontFamily,
      labelLarge: fontFamily,
      labelMedium: fontFamily,
      labelSmall: fontFamily,
      titleLarge: titleLarge,
      titleMedium: fontFamily,
      titleSmall : titleSmall
    ),
    appBarTheme: AppBarTheme(
      // elevation: 5,
      toolbarHeight: 70,
      titleSpacing: 0,
      backgroundColor: Color.fromARGB(255, 0, 93, 168),
      // backgroundColor: Color.fromARGB(255, 255, 255, 255),
      titleTextStyle: GoogleFonts.cabin(
        color: Color.fromARGB(255, 255, 255, 255),
        fontSize: 20,
        fontWeight: FontWeight.bold
      ),
      iconTheme: IconThemeData(
        color: Color.fromARGB(255, 255, 255, 255),
      ),
    ),
  );
  var darkTheme = ThemeData(
    colorScheme: const ColorScheme.light(
      primary: Color(0xff3D5AFE),
      // 
      onPrimary: Color.fromARGB(255, 10, 43, 72),
      onBackground: Color(0xffF5F5F5),
      onPrimaryContainer: Color(0xffF5F5F5),
      onSecondary: Color.fromARGB(255, 255, 255, 255),
      background: Color(0xff021526),
      secondary: Color.fromARGB(255, 2, 14, 39),
      error: Color(0xffFA8284),
      outline: Color.fromARGB(144, 158, 158, 158),
      inversePrimary: Color(0xff021526)
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: Color(0xff021526),
      titleTextStyle: GoogleFonts.cabin(
        color: Color.fromARGB(255, 255, 255, 255),
        fontSize: 20,
        fontWeight: FontWeight.bold
      ),
      iconTheme: IconThemeData(
        color: Colors.white
      )
    ),
    textTheme: TextTheme(
      bodyLarge: body,
      bodyMedium: body,
      bodySmall: body,
      titleSmall: titleSmall,
      displayLarge: fontFamily,
      displayMedium: fontFamily,
      displaySmall: fontFamily,
      headlineLarge: fontFamily,
      headlineMedium: fontFamily,
      headlineSmall: fontFamily,
      labelLarge: fontFamily,
      labelMedium: body,
      labelSmall: body,
      titleLarge: titleLarge,
      titleMedium: fontFamily,
    ),
  );
  static TextStyle fontFamily = GoogleFonts.notoSans(
    fontWeight: FontWeight.w500,
  );
  static TextStyle titleLarge = GoogleFonts.notoSans(
    fontWeight: FontWeight.w900,
    fontSize: 28,
    color: Colors.white
  );
  static TextStyle titleSmall = GoogleFonts.notoSans(
    fontWeight: FontWeight.w500,
    fontSize: 15,
    color: Colors.white
  );
  static TextStyle body = GoogleFonts.notoSans(
    // fontWeight: FontWeight.w500,
    // fontSize: 17,
    color: Colors.white
  );
  // static TextStyle labelSmall = GoogleFonts.notoSans(
  //   fontWeight: FontWeight.w500,
  //   fontSize: 15,
  //   color: Colors.white
  // );
}