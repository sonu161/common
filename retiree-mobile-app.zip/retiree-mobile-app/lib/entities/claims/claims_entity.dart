abstract class ClaimsEntity{
  getClaimList();
  submitData();
}