import 'package:flutter/material.dart';
class TextArea extends StatefulWidget {
  const TextArea({super.key,
  this.borderRadius,
    this.fullLabel,
    this.fullLabelText,
    this.lightTextBox,
    this.readOnly,
    required this.hint,
    this.textEditingController,
    this.obsecureText,
    this.fieldIcon,
    this.obsecureToNoSecure,
    this.textAlign,
    this.fieldError,
    this.validator,this.validatorText});


  final String hint;
  final TextEditingController? textEditingController;
  final bool? obsecureText;
  final Image? fieldIcon;
  final Function()? obsecureToNoSecure;
  final TextAlign? textAlign;
  final bool? fieldError;
  final double? borderRadius;
  final bool? fullLabel;
  final String? fullLabelText;
  final bool? lightTextBox;
  final bool? readOnly;
  final bool? validator;
  final String? validatorText;

  @override
  State<TextArea> createState() => _TextAreaState();
}

class _TextAreaState extends State<TextArea> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        widget.fullLabel == null
            ? Container()
            : Container(
          margin: EdgeInsets.only(left: 5, bottom: 5),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text("${widget.fullLabelText}"),
          ),
        ),
        Container(
          padding: EdgeInsets.only(left: 15, right: 15),

            decoration: BoxDecoration(
                border: Border.all(color: Color(0xffF3F3F3), width: 1),
                color: Color(0xffFAFAFA),
                borderRadius: BorderRadius.all(
                    Radius.circular(widget.borderRadius ?? 300))),
          child: TextField(
            readOnly: widget.readOnly??false,
            controller: widget.textEditingController,
            decoration: InputDecoration(
                border: InputBorder.none, hintText: "${widget.hint}"),
            minLines: 3,
            maxLines: 10,
            textInputAction: TextInputAction.done,
          ),
        ),
      ],
    );
  }
}
