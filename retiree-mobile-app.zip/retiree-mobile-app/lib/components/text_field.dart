import 'package:flutter/material.dart';

class MyTextField extends StatefulWidget {
  const MyTextField({super.key, this.hintText, this.lable, this.controller});
  final String? hintText;
  final String? lable;
  final TextEditingController? controller;

  @override
  State<MyTextField> createState() => _MyTextFieldState();
}

class _MyTextFieldState extends State<MyTextField> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          border: Border(
            top: BorderSide(color: Colors.black12),
            left: BorderSide(color: Colors.black12),
            right: BorderSide(color: Colors.black12),
          ),
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(5),
              topRight: Radius.circular(5))),
      child: TextField(
        controller: widget.controller,
        decoration: InputDecoration(
            contentPadding: EdgeInsets.only(
                left: 15, right: 15, top: 10, bottom: 10),
            border: UnderlineInputBorder(
                borderSide: BorderSide(
                    color: Theme.of(context).colorScheme.primary)),
            hintText: "${widget.hintText}",
            label: Text("${widget.lable}")),
      ),
    );
  }
}
