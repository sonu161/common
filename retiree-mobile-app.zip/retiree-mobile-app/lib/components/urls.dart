class Urls{
  static String captcha = "";
  static String authLogin = "";
  static String varifyOtp = "";
  static String resendOtp = "";
  static String downloadPdf = "";
  static String getTaxDeclaration  = "";
  static String saveTaxDeclaration  = "";
  static String saveTaxRegime  = "";
  static String saveindoorHospForm  = "indoorHospFormSave";
  static String getIndoorHospList  = "indoorHospForm";
  static String getProfileDetail  = "editProfile";

}