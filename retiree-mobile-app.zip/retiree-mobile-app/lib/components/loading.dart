import 'package:flutter/Material.dart';
import 'package:sidbi_app/components/main_button.dart';

class LoadingApp extends StatelessWidget {
  const LoadingApp({super.key, this.refresh});
  final Function()? refresh;

  @override
  Widget build(BuildContext context) {
    return Container(
      // color: Colors.white,
      height: MediaQuery.of(context).size.height / 1.2,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              child: Transform.scale(
                scale: 0.2,
                child: Image.asset("assets/icons/loading4.gif"),
              ),
            )
          ],
        ),
      ),
    );
  }
}
