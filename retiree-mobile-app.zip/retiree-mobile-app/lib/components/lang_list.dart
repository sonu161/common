class LanguageList{
  List<Map<String, String>> langList = [
    {
      "langName":"हिंदी",
      "langCode":"Hi_IN"
    },
    {
      "langName":"English",
      "langCode":"en_US"
    },
    // {
    //   "langName":"ଓଡିଆ",
    //   "langCode":"or_IN"
    // }
  ];
}