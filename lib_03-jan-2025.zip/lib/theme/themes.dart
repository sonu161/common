import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CustomTheme {
  final Color primaryColor = Color.fromARGB(255, 0, 93, 168);
  var lightTheme = ThemeData(
    useMaterial3: true,
    colorScheme: const ColorScheme.light(
      primary: Color.fromARGB(255, 0, 93, 168),
      onPrimary: Colors.white,
      onBackground: Color(0xffF5F5F5),
      onPrimaryContainer: Color(0xffF5F5F5),
      onSecondary: Color(0xff013e59),
      background: Color.fromARGB(255, 231, 231, 231),
      secondary: Color.fromARGB(255, 228, 238, 248),
      error: Color(0xffFA8284),
      outline: Color.fromARGB(44, 41, 41, 41)
    ),
    textTheme: TextTheme(
      bodyLarge: fontFamily,
      bodyMedium: fontFamily,
      bodySmall: fontFamily,
      titleSmall: fontFamily,
      displayLarge: fontFamily,
      displayMedium: fontFamily,
      displaySmall: fontFamily,
      headlineLarge: fontFamily,
      headlineMedium: fontFamily,
      headlineSmall: fontFamily,
      labelLarge: fontFamily,
      labelMedium: fontFamily,
      labelSmall: fontFamily,
      titleLarge: fontFamily,
      titleMedium: fontFamily,
    ),
    appBarTheme: AppBarTheme(
      // elevation: 5,
      toolbarHeight: 70,
      titleSpacing: 0,
      backgroundColor: Color.fromARGB(255, 0, 93, 168),
      // backgroundColor: Color.fromARGB(255, 255, 255, 255),
      titleTextStyle: GoogleFonts.cabin(
        color: Color.fromARGB(255, 255, 255, 255),
        fontSize: 20,
        fontWeight: FontWeight.bold
      ),
      iconTheme: IconThemeData(
        color: Color.fromARGB(255, 255, 255, 255),
      ),
    ),
  );
  var darkTheme = ThemeData(
    colorScheme: const ColorScheme.light(
      primary: Color(0xff3D5AFE),
      // 
      onPrimary: Color(0xff021526),
      onBackground: Color(0xffF5F5F5),
      onPrimaryContainer: Color(0xffF5F5F5),
      onSecondary: Color.fromARGB(255, 255, 255, 255),
      background: Color(0xff021526),
      secondary: Color.fromARGB(255, 2, 14, 39),
      error: Color(0xffFA8284),
      outline: Color.fromARGB(144, 158, 158, 158)
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: Color(0xff021526),
      titleTextStyle: GoogleFonts.cabin(
        color: Color.fromARGB(255, 255, 255, 255),
        fontSize: 20,
        fontWeight: FontWeight.bold
      ),
      iconTheme: IconThemeData(
        color: Colors.white
      )
    ),
    textTheme: TextTheme(
      bodyLarge: fontFamily,
      bodyMedium: fontFamily,
      bodySmall: fontFamily,
      titleSmall: fontFamily,
      displayLarge: fontFamily,
      displayMedium: fontFamily,
      displaySmall: fontFamily,
      headlineLarge: fontFamily,
      headlineMedium: fontFamily,
      headlineSmall: fontFamily,
      labelLarge: fontFamily,
      labelMedium: fontFamily,
      labelSmall: fontFamily,
      titleLarge: fontFamily,
      titleMedium: fontFamily,
    ),
  );
  static TextStyle fontFamily = GoogleFonts.notoSans(
    fontWeight: FontWeight.w500
  );
}