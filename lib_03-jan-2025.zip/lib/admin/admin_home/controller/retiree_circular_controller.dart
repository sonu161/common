import 'dart:convert';

import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/model/CircularData.dart';
import 'package:sidbi_app/admin/admin_home/repo/retiree_circular_repo.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/helper.dart';

import '../../../components/pdf_view.dart';

class RetireeCircularController extends GetxController{

  var data = CircularData().obs;
  RetireeCircularRepo repo = new RetireeCircularRepo();
  var filterHint = "Choose year to filter".obs;
  var filteYear = "".obs;
  var loading = AppLoadingState.Initial.obs;
  Helper helper = new Helper();

  getCircularData() async{
    try{
      loading.value = AppLoadingState.Loading;
      var res = await repo.getCircularList();
      if(res.statusCode == 200){
        data.value = CircularData.fromJson(jsonDecode(res.body)['circularDetails']);
        // data.value = CircularData.fromJson(jsonDecode(res.stream.bytesToString()));
        print(data.value.data!.first.year);
        // print(jsonDecode(res.body));
        data.refresh();
        loading.value = AppLoadingState.Loaded;
      }else{
        loading.value = AppLoadingState.Error;
      }
    }catch(e){
      loading.value = AppLoadingState.Error;
    }
  }

  filterByYear({year}){
    filteYear.value = year;
    refresh();
  }

  downloadFile({fileName}) async{
    try{
      helper.fullAppLoading();
      var res = await repo.downloadFile(fileName: fileName);
      try{
        Get.back();
        Get.to(() => PdfViewPage(), arguments: res.uri.path);
      }catch(e){
        Get.back();
        helper.messageAlert(title: "Error", message: "Some error occurred", type: AlertBoxType.Error);
      }
    }catch(e){

    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getCircularData();
  }
}