import 'package:flutter/Material.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import 'package:sidbi_app/admin/admin_home/controller/admin_contrller.dart';
import 'package:sidbi_app/admin/admin_home/view/admin_home/life_cert_upload_history.dart';
import 'package:sidbi_app/admin/admin_home/view/admin_home/login_history.dart';
import 'package:sidbi_app/app/holiday_vof/view/holiday_vof_view.dart';
import 'package:sidbi_app/app/hospitalization_request/views/hospitalization_view.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/app/pension_slip/view/pension_slip.dart';

import '../../../components/drop_converter.dart';
import '../../../components/drop_down_btn.dart';
import '../../../components/main_button.dart';
import '../../../components/shaps/triangle.dart';
import 'dart:math' as math;

class RetireeAdmin extends StatelessWidget {
  const RetireeAdmin({super.key});

  @override
  Widget build(BuildContext context) {
    return RetireeAdminLoader();
  }
}

class RetireeAdminLoader extends StatefulWidget {
  const RetireeAdminLoader({super.key});

  @override
  State<RetireeAdminLoader> createState() => _RetireeAdminLoaderState();
}

class _RetireeAdminLoaderState extends State<RetireeAdminLoader> {
  showAction() {
    showModalBottomSheet(
        isScrollControlled: false,
        context: context,
        backgroundColor: Color(0xffF4F4F4),
        showDragHandle: true,
        builder: (context) {
          return Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                color: Color(0xffF4F4F4),
                borderRadius: BorderRadius.horizontal(
                    left: Radius.circular(10), right: Radius.circular(10))),
            child: Container(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
              child: Column(
                children: [
                  tabOptions(optionName: "Login History Detail", postion: 1,onTap: (){
                    Get.to(()=>LoginHistory());
                  }),
                  tabOptions(
                      optionName: "VOF / Holiday Home",
                      postion: 2,
                      onTap: () {
                        Get.to(() => HolidayVofView());
                      }),
                  tabOptions(
                      optionName: "Indoor Hospitalization Claim Detail",
                      postion: 3,
                      onTap: () {
                        Get.to(() => HospitalizationView());

                      }),
                  // tabOptions(optionName: "Claim Details", postion: 4),
                  tabOptions(
                      optionName: "Life Certificate Upload History",
                      postion: 5,
                  onTap: (){
                   Get.to(()=>LifeCertUploadHistory());
                  }
                  ),
                  tabOptions(
                      optionName: "Pension / Form16 Detail",
                      postion: 6,
                      last: true,
                      onTap: () {
                        Get.to(() => PensionSlip());

                      }),
                ],
              ),
            ),
          );
        });
  }

  Widget tabOptions(
      {String? optionName,
      required int postion,
      onTap,
      bool? last,
      bool? close}) {
    return Container(
      width: MediaQuery.of(context).size.width,
      margin: EdgeInsets.only(bottom: 2),
      decoration: BoxDecoration(
        // color: Colors.white,
        // ,
        gradient: LinearGradient(colors: [
          Color.fromARGB(255, 38, 14, 255),
          Color.fromARGB(255, 171, 197, 255),
        ]),
        borderRadius: postion == 1 && last == null || last == false
            ? BorderRadius.only(
                topRight: Radius.circular(15),
                topLeft: Radius.circular(15),
              )
            : last == true
                ? BorderRadius.only(
                    bottomRight: Radius.circular(15),
                    bottomLeft: Radius.circular(15),
                  )
                : BorderRadius.zero,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: postion == 1 && last == null || last == false
            ? BorderRadius.only(
                topRight: Radius.circular(15),
                topLeft: Radius.circular(15),
              )
            : last == true
                ? BorderRadius.only(
                    bottomRight: Radius.circular(15),
                    bottomLeft: Radius.circular(15),
                  )
                : BorderRadius.zero,
        child: InkWell(
          onTap: onTap ?? () {},
          borderRadius: postion == 1 && last == null || last == false
              ? BorderRadius.only(
                  topRight: Radius.circular(15),
                  topLeft: Radius.circular(15),
                )
              : last == true
                  ? BorderRadius.only(
                      bottomRight: Radius.circular(15),
                      bottomLeft: Radius.circular(15),
                    )
                  : BorderRadius.zero,
          child: Padding(
            padding: EdgeInsets.fromLTRB(15, 17, 15, 17),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "$optionName",
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      color: Colors.white),
                ),
                Icon(Icons.chevron_right)
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () {
          var ctr = Get.find<AdminContrller>();
          return ctr.getAllRetirees();
        },
        child: Container(
          child: GetX(
            init: AdminContrller(),
            builder: (ctrl) {
              if (ctrl.loading.value == AppLoadingState.Loading) {
                return Center(
                    child: SizedBox(
                        width: 50,
                        height: 50,
                        child: CircularProgressIndicator()));
              } else {
                print("hello ${ctrl.lists.length}");
                return Stack(
                  children: [
                    SingleChildScrollView(
                      padding: EdgeInsets.only(bottom: 100),
                      child: Column(
                        children: [
                          Container(
                            padding: EdgeInsets.fromLTRB(15, 20, 15, 20),
                            child: DropDownBtn(
                              setTheme: true,
                              data: ctrl.lists.toJson(),
                              dropItemChild: "name",
                              hint: ctrl.dropHint.value,
                              onChange: (val) {
                                var result = DropConverter().setDropValue(val);
                                ctrl.dropHint.value = result['name'];
                                ctrl.setuserId(userid: result['val']);
                              },
                            ),
                          ),
                          ctrl.dropHint.value=="Select retiree"
                              ?Container(
                            padding: EdgeInsets.fromLTRB(0, 40, 0, 40),
                            decoration: BoxDecoration(
                                color: Colors.white
                            ),
                            child: Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Image.asset("assets/images/good_img.jpg"),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Text(
                                    "Please select the retiree employee \n to see details",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color:Theme.of(context).colorScheme.secondary,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              ),
                            ),
                          )
                              :Container(
                            decoration: BoxDecoration(color: Colors.white),
                            // margin: EdgeInsets.only(top: 20, left: 20),
                            padding: EdgeInsets.only(
                                left: 20, right: 20, top: 10, bottom: 10),
                            child: Column(
                              children: [
                                Container(
                                  margin: EdgeInsets.only(top: 10, bottom: 15),
                                  child: Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    children: [
                                      Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.start,
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "${ctrl.userDetail.value.empName}",
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 16),
                                          ),
                                          Text("Active",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 14,
                                                  color: Colors.green)),
                                        ],
                                      ),
                                      MainButton(
                                        buttonLable: "Deactive",
                                        onTap: () {},
                                        warnState: true,
                                      )
                                    ],
                                  ),
                                ),
                                Divider(
                                  color: Theme.of(context).dividerColor,
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "Employee Address",
                                    detail:
                                    "${ctrl.userDetail.value.empAddress}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "Employee Email",
                                    detail: "${ctrl.userDetail.value.empEmail}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "Mobile Number",
                                    detail:
                                    "${ctrl.userDetail.value.empMobileNo}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "Retiree Code",
                                    detail:
                                    "${ctrl.userDetail.value.empSalCode}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "Salary Code",
                                    detail:
                                    "${ctrl.userDetail.value.empSalCode}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "Retiree Grade",
                                    detail: "${ctrl.userDetail.value.empGrade}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "PF / Pension optee",
                                    detail:
                                    "${ctrl.userDetail.value.pensionOptee}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "Family Pension (Y/N)",
                                    detail:
                                    "${ctrl.userDetail.value.familyPension}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "Mass Optee",
                                    detail: "${ctrl.userDetail.value.massOptee}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "Retiree PF/Pension Processing Status",
                                    detail:
                                    "${ctrl.userDetail.value.pensionProcessingStatus == "A" ? 'Active' : "Not Active"}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "Last Login Time",
                                    detail:
                                    "${ctrl.userDetail.value.lastLoginTime}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title:
                                    "Last Life Certificate File Upload Time",
                                    detail:
                                    "${ctrl.userDetail.value.lastCertificateFileUpload ?? ""}"),
                                heightSizedBox(),
                                dataRowView(
                                    color: Colors.primaries[math.Random()
                                        .nextInt(Colors.primaries.length)],
                                    title: "Tax Regime (Old/New)",
                                    detail:
                                    "${ctrl.userDetail.value.selectedTaxRegime}"),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    ctrl.dropHint.value=="Select retiree"?Container(): Positioned(
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                            decoration: BoxDecoration(
                              // color: Colors.red,
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                      color: Color(0xffa4a4a4),
                                      blurRadius: 2,
                                      offset: Offset(0, 1))
                                ],
                                gradient: LinearGradient(colors: [
                                  Color.fromARGB(255, 240, 227, 255),
                                  Color.fromARGB(255, 223, 255, 251),
                                ])),
                            child: Material(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.transparent,
                              elevation: 0,
                              child: InkWell(
                                borderRadius: BorderRadius.circular(10),
                                splashColor: Theme.of(context).cardColor,
                                onTap: () {
                                  showAction();
                                },
                                child: Container(
                                  height: 60,
                                  padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
                                  child: Row(
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "View Action",
                                        style: TextStyle(
                                            fontWeight: FontWeight.w700),
                                      ),
                                      RotationTransition(
                                        turns:
                                        new AlwaysStoppedAnimation(-90 / 360),
                                        child: Icon(Icons.chevron_right),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ))
                  ],
                );
              }
            },
          ),
        ),
      ),
    );
  }

  Widget heightSizedBox() {
    return SizedBox(height: 20);
  }

  Widget dataRowView({
    String? title,
    String? detail,
    Color? color,
  }) {
    final hsl = HSLColor.fromColor(color!);
    final hslDark = hsl.withLightness((hsl.lightness - .3).clamp(0.0, 1.0));
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Flexible(
          child: Row(
            children: [
              Flexible(
                flex: 4,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1) ??
                        Color.fromARGB(255, 169, 255, 213),
                  ),
                  child: Center(
                      child: Text(
                    "$title".tr,
                    style: TextStyle(
                        color: hslDark.toColor(), fontWeight: FontWeight.w900),
                    textAlign: TextAlign.center,
                  )),
                ),
              ),
              Container(
                child: RotationTransition(
                    turns: new AlwaysStoppedAnimation(90 / 360),
                    child: CustomPaint(
                      painter: TrianglePainter(
                        strokeColor: color!.withOpacity(0.1) ??
                            Color.fromARGB(255, 169, 255, 213),
                        strokeWidth: 0,
                        paintingStyle: PaintingStyle.fill,
                      ),
                      child: const SizedBox(
                        height: 38,
                        width: 39,
                      ),
                    )),
              ),
            ],
          ),
        ),
        Flexible(
          child: Container(
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(5),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black87.withOpacity(0.2), blurRadius: 2)
                ]),
            child: Text(
              "$detail",
              style: TextStyle(fontSize: 17),
            ),
          ),
        )
      ],
    );
  }
}
