import 'package:flutter/Material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/controller/retiree_life_cert_controller.dart';
import 'package:sidbi_app/admin/admin_home/view/retire_life_cert/cert_detail.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/main_button.dart';
import 'package:sidbi_app/components/optional_blank_page.dart';
import 'dart:math' as math;

class RetireeLifeCert extends StatelessWidget {
  const RetireeLifeCert({super.key});

  @override
  Widget build(BuildContext context) {
    return RetireeLifeCertLoader();
  }
}

class RetireeLifeCertLoader extends StatefulWidget {
  const RetireeLifeCertLoader({super.key});

  @override
  State<RetireeLifeCertLoader> createState() => _RetireeLifeCertLoaderState();
}

class _RetireeLifeCertLoaderState extends State<RetireeLifeCertLoader> {
  showAction({datas}) {
    showModalBottomSheet(
        isScrollControlled: false,
        context: context,
        backgroundColor: Color(0xffF4F4F4),
        showDragHandle: true,
        builder: (context) {
          return Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                color: Color(0xffF4F4F4),
                borderRadius: BorderRadius.horizontal(
                    left: Radius.circular(10), right: Radius.circular(10))),
            child: Container(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
              child: Column(
                children: [
                  SizedBox(
                    height: 15,
                  ),
                  Container(
                    child: Text(
                      "Select the financial year",
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Container(
                    height: MediaQuery.of(context).size.height / 4,
                    child: GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        childAspectRatio: MediaQuery.of(context).size.width /
                            (MediaQuery.of(context).size.height / 4),
                      ),
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: () {
                            var ctrl = Get.find<RetireeLifeCertController>();
                            ctrl.getFinancialYearData(
                                year: "${datas.first[index]}");
                            Get.back();
                          },
                          child: Chip(
                            label: Text("${datas.first[index]}"),
                          ),
                        );
                      },
                      itemCount: datas.first.length,
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  TextButton(
                      onPressed: () {
                        // var ctrl = Get.find<RetireeCircularController>();
                        // ctrl.filteYear.value = "";
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [Icon(Icons.clear), Text("Clear")],
                      ))
                ],
              ),
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return GetX(
      init: RetireeLifeCertController(),
      builder: (ctrl) {
        if (ctrl.loading == AppLoadingState.Loading) {
          return Center(
            child: SizedBox(
              height: 50,
              width: 50,
              child: CircularProgressIndicator(),
            ),
          );
        } else {
          if (ctrl.yearSelected.value == true) {
            return Scaffold(
              appBar: AppBar(
                backgroundColor: Colors.transparent,
                title: GetX(
                  init: RetireeLifeCertController(),
                  builder: (ctrl) {
                    return Container(
                      margin: EdgeInsets.only(bottom: 10),
                      child: Material(
                        color: Colors.white,
                        elevation: 1,
                        child: InkWell(
                          onTap: () {
                            showAction(datas: ctrl.listYear);
                          },
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(15, 10, 15, 10),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "${ctrl.yearGot.value}",
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                                Row(
                                  children: [
                                    Chip(
                                      label: Text(
                                        "Filter",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      avatar: Icon(
                                        Icons.filter_alt_rounded,
                                        color: Colors.white,
                                      ),
                                      backgroundColor:
                                          Theme.of(context).colorScheme.error,
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              body: GetX(
                init: RetireeLifeCertController(),
                builder: (ctrl) {
                  return Container(
                    child: ListView.builder(
                      itemCount:
                          ctrl.empdata.first.lifeCertificatesDtlList!.length,
                      itemBuilder: (context, index) {
                        var data = ctrl.empdata.first.lifeCertificatesDtlList!;
                        return Container(
                            margin: EdgeInsets.only(bottom: 2),
                            decoration: BoxDecoration(
                                color: Color.fromARGB(255, 255, 255, 255)),
                            child: ListElement(
                              data: data,
                              index: index,
                              colors: Colors.primaries[math.Random()
                                  .nextInt(Colors.primaries.length)],
                            ));
                      },
                    ),
                  );
                },
              ),
            );
          } else {
            return OptionalBlankPage(
              onTap: () {
                showAction(datas: ctrl.listYear);
              },
              title: "Select year to see submitted \n life certificate",
              buttonTitle: "Select Year",
            );
          }
        }
      },
    );
  }

  Widget ListElement({data, Color? colors, index}) {
    final hsl = HSLColor.fromColor(colors!);
    final hslDark = hsl.withLightness((hsl.lightness - .3).clamp(0.0, 1.0));
    return ListTile(
      onTap: (){
        Get.to(()=>CertDetail(
          fName: data[index].fullName,
          fileNmae: data[index].fileName,
          status: data[index].status,
          uploadedDate: data[index].uploadedDate,
          userid: data[index].empNo,
        ));
      },
      leading: CircleAvatar(
        backgroundColor: colors.withOpacity(0.2),
        child: Text(
          "${data[index].fullName}"[0],
          style:
              TextStyle(fontWeight: FontWeight.bold, color: hslDark.toColor()),
        ),
      ),
      title: Text(
        "${data[index].fullName}",
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: Text(
        "${data[index].status}",
        style: TextStyle(
            fontWeight: FontWeight.w700,
            color: Theme.of(context).colorScheme.secondary),
      ),
      trailing: Icon(Icons.chevron_right,color: hslDark.toColor(),),
    );
  }
}
