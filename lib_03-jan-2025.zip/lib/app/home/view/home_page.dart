import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/claims/views/claims_view.dart';
import 'package:sidbi_app/app/holiday_reimb/views/holiday_reimb_view.dart';
import 'package:sidbi_app/app/home/controller/home_controller.dart';
import 'package:sidbi_app/app/hospitalization_request/views/hospitalization_view.dart';
import 'package:sidbi_app/app/pension_slip/view/pension_slip.dart';
import 'package:sidbi_app/app/settings/view/settings.dart';
import 'dart:math' as math;

import 'package:sidbi_app/app/tax_declaration/views/tax_declaration.dart';
import 'package:sidbi_app/app/upload_life_cert/view/upload_life_cert_view.dart';
import 'package:sizer/sizer.dart';

import '../../holiday_vof/view/holiday_vof_view.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffffffff),

      // appBar: MyAppBar().appBar(
      //     context: context,
      //   appBarName: Text("Home")
      // ),
      // appBar: AppBar(
      //   title: Hero(
      //     tag: "logo",
      //     child: Container(
      //       // margin: EdgeInsets.only(right: 25),
      //       width: 50,
      //       height: 50,
      //       decoration: BoxDecoration(
      //           borderRadius: BorderRadius.all(Radius.circular(300)),
      //           color: Colors.white,
      //           gradient: RadialGradient(colors: [
      //             Color(0xffffffff),
      //             Color(0xffffffff),
      //             Color(0xffBEE1EE),
      //             Color(0xff24ACE1),
      //           ])),
      //       child: Center(
      //         child: Image(
      //           image: AssetImage("assets/images/sidbi_logo2.png"),
      //           height: 30,
      //           width: 30,
      //         ),
      //       ),
      //     ),
      //   ),
      //   automaticallyImplyLeading: false,
      //   titleSpacing: 20,
      //   centerTitle: true,
      //   flexibleSpace: Container(
      //     decoration: BoxDecoration(
      //       image: DecorationImage(
      //         image: AssetImage("assets/images/bg-img.jpg"),
      //         fit: BoxFit.cover
      //       ),
      //         gradient: LinearGradient(colors: [
      //       Colors.deepPurpleAccent,
      //       Theme.of(context).colorScheme.primary,
      //     ], begin: Alignment.topLeft, end: Alignment.bottomRight)),
      //   ),
      // ),
      body: Container(
          child: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              Container(
                height: 270,
                child: Stack(
                  children: [
                    GetX(
                      init: HomeController(),
                      builder: (ctrl) {
                        return Container(
                          height: 180,
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary,
                            image: DecorationImage(
                              image: AssetImage("assets/images/morning.jpg"),
                              fit: BoxFit.cover,
                            ),
                          ),
                          child: Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(left: 25),
                                child: Text(
                                  ctrl.wish.value.toString().tr,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 30,
                                      shadows: [
                                        BoxShadow(
                                            color: Colors.black,
                                            blurRadius: 10,
                                            blurStyle: BlurStyle.solid)
                                      ]),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                    Positioned(
                      left: 20,
                      right: 20,
                      bottom: 20,
                      child: Hero(
                        tag: "profileCard",
                        child: Material(
                          borderRadius: BorderRadius.circular(20),
                          child: Container(
                            height: 120,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.black12,
                                      blurRadius: 20,
                                      spreadRadius: 10,
                                      offset: Offset(0, 5))
                                ],
                                borderRadius: BorderRadius.circular(20)),
                            child: Stack(
                              children: [
                                Positioned(
                                  top: 25,
                                  left: 20,
                                  child: Container(
                                    decoration: BoxDecoration(
                                        borderRadius:
                                            BorderRadius.circular(300),
                                        boxShadow: [
                                          BoxShadow(
                                              color:
                                                  Color.fromARGB(18, 0, 0, 0),
                                              blurRadius: 5,
                                              offset: Offset(0, 3))
                                        ]),
                                    child: CircleAvatar(
                                      minRadius: 30,
                                      maxRadius: 30,
                                      backgroundColor: Theme.of(context)
                                          .colorScheme
                                          .primary
                                          .withOpacity(0.1),
                                      backgroundImage: AssetImage(
                                          "assets/icons/pensioner.png"),
                                    ),
                                  ),
                                ),
                                Positioned(
                                    top: 10,
                                    right: 10,
                                    child: IconButton(
                                      onPressed: () {
                                        Get.to(SettingsView(),
                                            transition: Transition.fadeIn,
                                            duration:
                                                Duration(milliseconds: 200));
                                      },
                                      icon: Icon(
                                        Icons.settings,
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary,
                                      ),
                                    )),
                                GetX(
                                  init: HomeController(),
                                  builder: (ctrl) {
                                    return Positioned(
                                        left: 100,
                                        top: 40,
                                        right: 100,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                            "${ctrl.name.value}",
                                            style:
                                                TextStyle(fontSize: 20),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,),
                                            Text(
                                              "${ctrl.email.value}",
                                              style: TextStyle(
                                                  fontSize: 15,
                                                  color: Color.fromARGB(
                                                      148, 0, 0, 0)),
                                            ),
                                          ],
                                        ));
                                  },
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 10,
              ),
              SizedBox(
                width: 150,
                child: Divider(
                  color: Color(0xffCBCBCB),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Align(
                child: Text(
                  "Quick Services".tr,
                  style: TextStyle(fontSize: 15),
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                child: GetX(
                  init: HomeController(),
                  builder: (ctrl) {
                    return GridView.builder(
                      padding: EdgeInsets.only(top: 20, bottom: 40),
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: ctrl.listTabs.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          childAspectRatio: 1.1,
                          crossAxisCount: 2,
                          mainAxisSpacing: 20,
                          crossAxisSpacing: 20),
                      itemBuilder: (BuildContext context, int index) {
                        var data = ctrl.listTabs;
                        return tabCards(
                            color: Colors.primaries[
                                math.Random().nextInt(Colors.primaries.length)],
                            data: data,
                            index: index,
                            onTap: () {
                              if (index == 0) {
                                Get.to(() => PensionSlip());
                              }
                              if (index == 1) {
                                Get.to(() => HolidayReimbView());
                              }
                              if (index == 2) {
                                Get.to(() => ClaimsView());
                              }
                              if (index == 3) {
                                Get.to(() => HospitalizationView());
                              }
                              if (index == 4) {
                                Get.to(() => TaxDeclarationView());
                              }
                              if (index == 5) {
                                Get.to(() => HolidayVofView());
                              }
                            });
                        // return GestureDetector(
                        // onTap: () {
                        //   if (index == 0) {
                        //     Get.to(() => PensionSlip());
                        //   }
                        //   if (index == 1) {
                        //     Get.to(() => HolidayReimbView());
                        //   }
                        //   if (index == 2) {
                        //     Get.to(() => ClaimsView());
                        //   }
                        //   if (index == 3) {
                        //     Get.to(() => HospitalizationView());
                        //   }
                        //   if (index == 4) {
                        //     Get.to(() => TaxDeclarationView());
                        //   }
                        //   if (index == 5) {
                        //     Get.to(() => HolidayVofView());
                        //   }
                        // },
                        //   child: Container(
                        //     decoration: BoxDecoration(
                        //       color: Color(
                        //               (math.Random().nextDouble() * 0x7C4DFFFF)
                        //                   .toInt())
                        //           .withOpacity(0.2),
                        //       borderRadius: BorderRadius.circular(10),
                        //     ),
                        //     child: Column(
                        //       children: [
                        //         Expanded(
                        //           child: Center(
                        //             child: Container(
                        //                 child: CircleAvatar(
                        //               child: index == 0
                        //                   ? Image.asset(
                        //                       "assets/icons/payments.png",
                        //                       width: 40,
                        //                       color: Theme.of(context)
                        //                           .colorScheme
                        //                           .primary,
                        //                     )
                        //                   : index == 1
                        //                       ? Image.asset(
                        //                           "assets/icons/cash-back.png",
                        //                           width: 40,
                        //                           color: Theme.of(context)
                        //                               .colorScheme
                        //                               .primary,
                        //                         )
                        //                       : index == 2
                        //                           ? Image.asset(
                        //                               "assets/icons/claim-form.png",
                        //                               width: 40,
                        //                               color: Theme.of(context)
                        //                                   .colorScheme
                        //                                   .primary,
                        //                             )
                        //                           : index == 3
                        //                               ? Image.asset(
                        //                                   "assets/icons/artificial-light.png",
                        //                                   width: 40,
                        //                                   color:
                        //                                       Theme.of(context)
                        //                                           .colorScheme
                        //                                           .primary,
                        //                                 )
                        //                               : index == 4
                        //                                   ? Image.asset(
                        //                                       "assets/icons/tax.png",
                        //                                       width: 40,
                        //                                       color: Theme.of(
                        //                                               context)
                        //                                           .colorScheme
                        //                                           .primary,
                        //                                     )
                        //                                   : Image.asset(
                        //                                       "assets/icons/resort.png",
                        //                                       width: 40,
                        //                                       color: Theme.of(
                        //                                               context)
                        //                                           .colorScheme
                        //                                           .primary,
                        //                                     ),
                        //               backgroundColor: Colors.white,
                        //               minRadius: 36,
                        //               maxRadius: 36,
                        //             )),
                        //           ),
                        //           flex: 2,
                        //         ),
                        //         Expanded(
                        //             child: Container(
                        //           padding: EdgeInsets.fromLTRB(10, 5, 10, 10),
                        //           decoration: BoxDecoration(
                        //             color: Colors.white,
                        //             gradient: LinearGradient(
                        //               colors: [
                        //                 Colors.white,
                        //                 Colors.white,
                        //                 Colors.white24
                        //               ],
                        //               // end: Alignment.topCenter,
                        //               // begin: Alignment.bottomCenter
                        //             ),
                        //             // borderRadius: BorderRadius.circular(10),
                        //           ),
                        //           child: Center(
                        //             child: Text(
                        //               textAlign: TextAlign.center,
                        //               "${data[index]['tabName']}".tr,
                        //               style: TextStyle(
                        //                   fontSize: 16,
                        //                   color: Colors.black,
                        //                   fontWeight: FontWeight.w500),
                        //             ),
                        //           ),
                        //         ))
                        //       ],
                        //     ),
                        //   ),
                        // );
                      },
                    );
                  },
                ),
              )
            ],
          ),
        ),
      )),
    );
  }

  Widget tabCards({index, data, onTap, Color? color}) {
    final hsl = HSLColor.fromColor(color!);
    final hslDark = hsl.withLightness((hsl.lightness - .3).clamp(0.0, 1.0));
    return GestureDetector(
      onTap: () {
        if (index == 0) {
          Get.to(() => PensionSlip());
        }
        if (index == 1) {
          Get.to(() => HolidayReimbView());
        }
        if (index == 2) {
          Get.to(() => ClaimsView());
        }
        if (index == 3) {
          Get.to(() => HospitalizationView());
        }
        if (index == 4) {
          Get.to(() => TaxDeclarationView());
        }
        if (index == 5) {
          Get.to(() => HolidayVofView());
        }
        if (index == 6) {
          Get.to(() => UploadLifeCertView());
        }

      },
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: Container(
                    child: CircleAvatar(
                  child: index == 0
                      ? Image.asset(
                          "assets/icons/payments.png",
                          width: 40,
                          color: hslDark.toColor(),
                        )
                      : index == 1
                          ? Image.asset(
                              "assets/icons/cash-back.png",
                              width: 40,
                              color: hslDark.toColor(),
                            )
                          : index == 2
                              ? Image.asset(
                                  "assets/icons/claim-form.png",
                                  width: 40,
                                  color: hslDark.toColor(),
                                )
                              : index == 3
                                  ? Image.asset(
                                      "assets/icons/artificial-light.png",
                                      width: 40,
                                      color: hslDark.toColor(),
                                    )
                                  : index == 4
                                      ? Image.asset(
                                          "assets/icons/tax.png",
                                          width: 40,
                                          color: hslDark.toColor(),
                                        )
                                      : Image.asset(
                                          "assets/icons/file.png",
                                          width: 40,
                                          color: hslDark.toColor(),
                                        ),
                  backgroundColor: Colors.white,
                  minRadius: 25.sp,
                  maxRadius: 25.sp,
                )),
              ),
              flex: 2,
            ),
            Expanded(
                child: Container(
              padding: EdgeInsets.fromLTRB(10, 5, 10, 10),
              decoration: BoxDecoration(
                color: Colors.white,
                gradient: LinearGradient(
                  colors: [Colors.white, Colors.white, Colors.white24],
                  // end: Alignment.topCenter,
                  // begin: Alignment.bottomCenter
                ),
                // borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: Text(
                  textAlign: TextAlign.center,
                  "${data[index]['tabName']}".tr,
                  style: TextStyle(
                      fontSize: 15.sp,
                      color: hslDark.toColor(),
                      fontWeight: FontWeight.w500),
                ),
              ),
            ))
          ],
        ),
      ),
    );
  }
}
