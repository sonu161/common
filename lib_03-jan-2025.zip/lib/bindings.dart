import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/controller/admin_contrller.dart';
import 'package:sidbi_app/admin/admin_home/controller/retiree_circular_controller.dart';
import 'package:sidbi_app/admin/admin_home/controller/retiree_life_cert_controller.dart';
import 'package:sidbi_app/app/claims/controller/claim_ctrl.dart';
import 'package:sidbi_app/app/holiday_reimb/controller/reimbu_controller.dart';
import 'package:sidbi_app/app/hospitalization_request/contrller/add_claim_controller.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/app/otp/controller/otp_controller.dart';
import 'package:sidbi_app/app/pension_slip/controller/pensionsl_controller.dart';
import 'package:sidbi_app/app/settings/controller/lang_ctrl.dart';
import 'package:sidbi_app/app/tax_declaration/controller/tax_controller.dart';
import 'package:sidbi_app/app/user/controller/user_controller.dart';
import 'package:sidbi_app/components/comp_controllers/input_controller.dart';
import 'package:sidbi_app/components/comp_controllers/loading_controller.dart';
import 'package:sidbi_app/components/helper.dart';

class AllBindings extends Bindings{
  @override
  void dependencies() {
    Get.put(LangController());
    Get.put(Helper(),permanent: false);

    // Get.put(PayController());
    Get.put(LoadingController());
    Get.put(InputController());
    Get.lazyPut(()=>LogingCtrl(),fenix: true);
    Get.lazyPut<TaxController>(() => TaxController(), fenix: true);
    Get.lazyPut<ClaimController>(() => ClaimController(), fenix: true);
    Get.lazyPut<ReimbuController>(() => ReimbuController(), fenix: false);
    Get.lazyPut<OtpController>(() => OtpController(), fenix: true);
    Get.lazyPut<PayController>(() => PayController(), fenix: true);
    Get.lazyPut<PayController>(() => PayController(), fenix: true);
    Get.lazyPut<RetireeCircularController>(() => RetireeCircularController(), fenix: true);
    Get.lazyPut<RetireeLifeCertController>(() => RetireeLifeCertController(), fenix: true);
    Get.lazyPut<UserController>(() => UserController(), fenix: true);
    Get.lazyPut<AdminContrller>(() => AdminContrller(), fenix: true);
    Get.lazyPut<AddClaimController>(() => AddClaimController(), fenix: true);
    // Get.put<HospitalController>(HospitalController(),permanent: true );
  }


}