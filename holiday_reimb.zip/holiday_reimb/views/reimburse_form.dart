import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/holiday_reimb/controller/reimbu_controller.dart';
import 'package:sidbi_app/app/holiday_reimb/model/reimburse_data.dart';
import 'package:sidbi_app/components/date_input.dart';
import 'package:sidbi_app/components/form_field.dart';
import 'package:sidbi_app/components/main_button.dart';

import '../controller/holiday_reimb_controller.dart';

class ReimburseFormView extends StatefulWidget {
  final HolidayData? data;
  final bool? edit;
  final int? index;
  const ReimburseFormView({super.key, this.data, this.index, this.edit});

  @override
  State<ReimburseFormView> createState() => _ReimburseFormViewState();
}

class _ReimburseFormViewState extends State<ReimburseFormView> {
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvoked: (di){
        var ctrl = Get.find<ReimbuController>();
        // ctrl.cancelTime();
      },
      child: Scaffold(
      appBar: AppBar(
        title: Text("Room Tariff Detail"),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.only(top: 10, bottom: 20),
        child: Container(
          margin: EdgeInsets.only(left: 15, right: 15),
          padding: EdgeInsets.only(left: 10, right: 10, bottom: 10),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 1)]),
          child: GetX(
            init: ReimbuController(),
            builder: (ctrl) {
              print(widget.edit);
              if (widget.edit! == true && widget.edit != null) {
                ctrl.setDataOnTextField(
                    data: widget.data!,
                    index: widget.index!,
                    edit: widget.edit!);
              }
              return Form(
                key: ctrl.formKey.value,
                child: Column(
                  children: [
                    SizedBox(
                      height: 10,
                    ),
                    Container(
                      child: FormFields(
                        textInputType: TextInputType.number,
                        lightTextBox: true,
                        borderRadius: 7,
                        hint: 'Enter Amount',
                        fullLabel: true,
                        fullLabelText: "Room Tarrif",
                        decimalReq: false,
                        textEditingController: ctrl.listEditorControllers[0],
                        onchange: (val) {
                          var value = val == "" ? "0" : val;
                          ctrl.simulateEaValues(type: "RT", val: value);
                        },
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        textInputType: TextInputType.number,
                          lightTextBox: true,
                          borderRadius: 7,
                          hint: 'Enter Amount',
                          fullLabel: true,
                          decimalReq: false,
                          fullLabelText: "Food Bill",
                          textEditingController: ctrl.listEditorControllers[1],
                          onchange: (val) {
                            var value = val == "" ? "0" : val;
                            ctrl.simulateEaValues(type: "FB", val: value);
                          }),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        borderRadius: 7,
                        readOnly: true,
                        hint: 'Enter Amount',
                        fullLabel: true,
                        fullLabelText: "Eligible Amount",
                        textEditingController: ctrl.listEditorControllers[2],
                        textInputType: TextInputType.number,
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        lightTextBox: true,
                        borderRadius: 7,
                        hint: 'Enter Rate',
                        fullLabel: true,
                        fullLabelText: "Hotel GST Rate",
                        textEditingController: ctrl.listEditorControllers[3],
                        onchange: (val){
                          ctrl.hotelGSTCount(val: val);
                        },
                        readOnly: false,
                        textInputType: TextInputType.number,
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        lightTextBox: true,
                        borderRadius: 7,
                        hint: 'Enter Rate',
                        fullLabel: true,
                        fullLabelText: "Food GST Rate",
                        textEditingController: ctrl.listEditorControllers[4],
                        // disabled: ctrl.listEditorControllers[1].value.text == ""?true:false,
                        onchange: (val){
                          ctrl.foodGSTCount(val: val);
                        },
                        readOnly: ctrl.statusFoodGst.value,
                        textInputType: TextInputType.number,
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        lightTextBox: true,
                        readOnly: true,
                        borderRadius: 7,
                        hint: '',
                        fullLabel: true,
                        fullLabelText: "Hotel GST Amount",
                        textEditingController: ctrl.listEditorControllers[5],
                        textInputType: TextInputType.number,
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        lightTextBox: true,
                        readOnly: true,
                        borderRadius: 7,
                        hint: '',
                        fullLabel: true,
                        fullLabelText: "Food GST Amount",
                        textEditingController: ctrl.listEditorControllers[6],
                        textInputType: TextInputType.number,
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        lightTextBox: true,
                        readOnly: true,
                        borderRadius: 7,
                        hint: 'Enter Amount',
                        fullLabel: true,
                        fullLabelText: "Total GST Amount",
                        textEditingController: ctrl.listEditorControllers[7],
                        textInputType: TextInputType.number,
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        lightTextBox: true,
                        borderRadius: 7,
                        hint: 'Enter Name',
                        fullLabel: true,
                        fullLabelText: "Hotel Name",
                        textEditingController: ctrl.listEditorControllers[8],
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: DateInput(
                        hint: "dd-MM-yyyy",
                        fullLabel: true,
                        fullLabelText: "Start Date",
                        borderRadius: 6,
                        readOnly: true,
                        lightTextBox: true,
                        dateDivider: "/",
                        endDate: DateTime.now(),
                        textEditingController: ctrl.listEditorControllers[9],
                        // textEditingController:ctrl.startDateCtrl.value,
                        // onChanged: (val){
                        //   print(val);
                        //   ctrl.onChangeStartDate();
                        // },
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: DateInput(
                        hint: "dd-MM-yyyy",
                        fullLabel: true,
                        fullLabelText: "End Date",
                        borderRadius: 6,
                        disabled: ctrl.clickable.value?false:true,
                        readOnly: true,
                        lightTextBox: true,
                        dateDivider: "/",
                        textEditingController: ctrl.listEditorControllers[10],
                        // startDate: ctrl.clickable.value?DateTime.parse(ctrl.listEditorControllers[9].text):null,
                        endDate: DateTime.now(),
                        clickable: ctrl.clickable.value,
                        // onChanged: (val){
                        //   ctrl.onChangeStartDate();
                        // },
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        textInputType: TextInputType.number,
                        lightTextBox: true,
                        readOnly: true,
                        borderRadius: 7,
                        hint: '0',
                        fullLabel: true,
                        fullLabelText: "No.Of Days",
                        textEditingController: ctrl.listEditorControllers[11],
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        lightTextBox: true,
                        readOnly: true,
                        borderRadius: 7,
                        hint: 'Enter Amount',
                        fullLabel: true,
                        fullLabelText: "Total Eligible Amount",
                        textEditingController: ctrl.listEditorControllers[12],
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        lightTextBox: true,
                        readOnly: true,
                        borderRadius: 7,
                        hint: 'Enter Amount',
                        fullLabel: true,
                        fullLabelText: "Total Elg. GST",
                        textEditingController: ctrl.listEditorControllers[7],
                        onchange: (val){
                          ctrl.simulateEaValues(
                            type: "RT",
                            val: ctrl.listEditorControllers[2]
                          );
                        },
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        lightTextBox: true,
                        readOnly: true,
                        borderRadius: 7,
                        hint: 'Enter Amount',
                        fullLabel: true,
                        fullLabelText: "Total Claim Amount",
                        textEditingController: ctrl.listEditorControllers[13],
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Container(
                      child: FormFields(
                        lightTextBox: true,
                        readOnly: true,
                        borderRadius: 7,
                        hint: 'Enter Amount',
                        fullLabel: true,
                        fullLabelText: "Total Hotel and food Amount",
                        textEditingController: ctrl.listEditorControllers[14],
                      ),
                    )
                  ],
                ),
              );
            },
          ),
        ),
      ),
      bottomNavigationBar: Container(
        color: Colors.white,
        padding: EdgeInsets.fromLTRB(20, 10, 20, 20),
        height: 80,
        child: MainButton(
          buttonLable: "Submit",
          onTap: () {
            var ctl = Get.find<ReimbuController>();
            var ctl2 = Get.find<HolidayReimbController>();
            if (ctl.editableView.value) {
              ctl.validateForm(type: "edit");
            } else {
              ctl.validateForm(type: "add");
            }
            
            // ctl.counter();
          },
        ),
      ),
    ),
    );
  }
}
