import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/holiday_reimb/controller/holiday_reimb_controller.dart';
import 'package:sidbi_app/app/holiday_reimb/controller/reimb_view_controller.dart';
// import 'package:sidbi_app/app/holiday_reimb/controller/reimbu_controller.dart';
import 'package:sidbi_app/app/holiday_reimb/views/reimburse_form.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/drop_converter.dart';
import 'package:sidbi_app/components/drop_down_btn.dart';
import 'package:sidbi_app/components/input_field.dart';
import 'package:sidbi_app/components/loading.dart';
import 'package:sidbi_app/components/main_button.dart';
import 'package:sidbi_app/components/pdf_view.dart';

import '../controller/reimbu_controller.dart';

class HolidayReimbForm extends StatefulWidget {
  const HolidayReimbForm({super.key});

  @override
  State<HolidayReimbForm> createState() => _HolidayReimbFormState();
}

class _HolidayReimbFormState extends State<HolidayReimbForm> {
  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvoked: (di) {
        var ctrl = Get.find<ReimbViewController>();
        ctrl.getBookings();
      },
      child: Scaffold(
        backgroundColor: Theme.of(context).colorScheme.surface,
        appBar: AppBar(
          title: Text("Check In form"),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.only(top: 10, bottom: 20),
          child: GetX(
            init: HolidayReimbController(),
            builder: (ctrl) {
              if (ctrl.loading.value == AppLoadingState.Loading) {
                return LoadingApp();
              } else {
                return Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.fromLTRB(15, 10, 15, 10),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(color: Colors.black26, blurRadius: 2)
                            ]),
                        child: Column(
                          children: [
                            Container(
                              decoration: BoxDecoration(color: Colors.white),
                              child: ctrl.dropData.length > 0
                                  ? DropDownBtn(
                                      hint: "${ctrl.dropName.value}",
                                      data: ctrl.dropData.toJson(),
                                      dropItemChild: "name",
                                      onChange: (val) {
                                        var result =
                                            DropConverter().setDropValue(val);
                                        ctrl.dropName.value = result['name'];
                                        ctrl.dropVal.value = result['val'];
                                        // print(ctrl.dropName.value);
                                        print(ctrl.dropVal.value);
                                      },
                                    )
                                  : Container(),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Container(
                              padding: EdgeInsets.only(
                                  left: 20, right: 20, top: 15, bottom: 15),
                              decoration: BoxDecoration(
                                  color: Colors.redAccent.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(10)),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    child: Row(
                                      children: [
                                        Expanded(
                                            child:
                                                Text("Availed sterling night")),
                                        Expanded(
                                            child: Text(
                                          "${ctrl.sterLingNight}",
                                          textAlign: TextAlign.right,
                                        )),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    child: Row(
                                      children: [
                                        Expanded(
                                            child: Text(
                                                "Availed Reimbursed night")),
                                        Expanded(
                                            child: Text(
                                          "${ctrl.availedReimbNight}",
                                          textAlign: TextAlign.right,
                                        )),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    child: Row(
                                      children: [
                                        Expanded(
                                            child: Text(
                                                "Available Reimbursed night")),
                                        Expanded(
                                            child: Text(
                                          "${ctrl.availableReimbNight}",
                                          textAlign: TextAlign.right,
                                        )),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    child: Row(
                                      children: [
                                        Expanded(
                                            child: Text(
                                                "Available Eligible Amount")),
                                        Expanded(
                                            child: Text(
                                          "\u{20B9}${ctrl.elegibleAmt}",
                                          textAlign: TextAlign.right,
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        )),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(color: Colors.black12, blurRadius: 2)
                            ]),
                        child: GetX(
                          init: HolidayReimbController(),
                          builder: (ctrl) {
                            if (ctrl.dropVal.value == "") {
                              return Container();
                            } else {
                              if (ctrl.addedHomeReim.length == 0) {
                                return Container(
                                  child: Column(
                                    children: [
                                      Stack(
                                        children: [
                                          Container(
                                            padding: EdgeInsets.fromLTRB(
                                                20, 10, 20, 10),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Flexible(
                                                  child: Text(
                                                    "Add holiday home reimburse"
                                                        .tr,
                                                    style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.w600,
                                                      color: Colors.black,
                                                    ),
                                                  ),
                                                ),
                                                MainButton(
                                                  buttonLable: "Add Row",
                                                  onTap: () {
                                                    Get.to(
                                                        () => ReimburseFormView(
                                                              edit: false,
                                                            ),
                                                        transition: Transition
                                                            .cupertino);
                                                  },
                                                )
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            left: 10,
                                            top: -10,
                                            child: Icon(
                                              Icons.star,
                                              size: 30,
                                              color: Color(0x98ffc604),
                                            ),
                                          ),
                                          Positioned(
                                            left: 50,
                                            bottom: -10,
                                            child: Icon(
                                              Icons.star,
                                              size: 30,
                                              color: Color(0x98ffc604),
                                            ),
                                          ),
                                          Positioned(
                                            right: 100,
                                            bottom: -6,
                                            child: Icon(
                                              Icons.star,
                                              size: 30,
                                              color: Color(0x98ffc604),
                                            ),
                                          )
                                        ],
                                      ),
                                    ],
                                  ),
                                );
                              } else {
                                return ListView.builder(
                                  physics: NeverScrollableScrollPhysics(),
                                  shrinkWrap: true,
                                  itemCount: ctrl.addedHomeReim.length,
                                  itemBuilder: (context, index) {
                                    var data = ctrl.addedHomeReim[index];
                                    return Column(
                                      children: [
                                        ListTile(
                                          title: Text("Room Tarrif"),
                                          subtitle: Text("${data.roomTarrif}"),
                                          trailing: SizedBox(
                                            width: 100,
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.end,
                                              children: [
                                                IconButton(
                                                    onPressed: () {
                                                      Get.to(() =>
                                                          ReimburseFormView(
                                                            data: data,
                                                            edit: true,
                                                            index: index,
                                                          ));
                                                    },
                                                    icon: Icon(Icons.edit,
                                                        color: Colors.black54)),
                                                IconButton(
                                                    onPressed: () {
                                                      ctrl.deleteRow(index);
                                                    },
                                                    icon: Icon(
                                                      Icons.delete,
                                                      color: Theme.of(context)
                                                          .colorScheme
                                                          .primary
                                                          .withOpacity(0.7),
                                                    )),
                                              ],
                                            ),
                                          ),
                                        ),
                                        index == ctrl.addedHomeReim.length - 1
                                            ? Container()
                                            : Divider()
                                      ],
                                    );
                                  },
                                );
                              }
                            }
                          },
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Container(
                        margin: EdgeInsets.only(left: 20, right: 20),
                        child: GetX(
                          init: HolidayReimbController(),
                          builder: (ctrl) {
                            if (ctrl.addedHomeReim.length == 0) {
                              return Container();
                            } else {
                              return Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      MainButton(
                                        buttonLable: "Add Row",
                                        onTap: () {
                                          Get.to(
                                              () => ReimburseFormView(
                                                    edit: false,
                                                  ),
                                              transition: Transition.cupertino);
                                        },
                                      )
                                    ],
                                  ),
                                  SizedBox(
                                    height: 30,
                                  )
                                ],
                              );
                            }
                          },
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.fromLTRB(20, 15, 20, 15),
                        decoration: BoxDecoration(color: Colors.white),
                        child: Column(
                          children: [
                            InputField(
                              hint: "Enter no of nights".tr,
                              borderRadius: 7,
                              fullLabel: true,
                              fullLabelText: "No. Of Nights".tr,
                              readOnly: true,
                              textEditingController: ctrl.nofNight.value,
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            InputField(
                              hint: "Enter no of rooms".tr,
                              borderRadius: 7,
                              fullLabel: true,
                              fullLabelText: "No. Of Rooms".tr,
                              readOnly: true,
                              textEditingController: ctrl.noOfRooms.value,
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            InputField(
                              hint: "Enter no of days",
                              borderRadius: 7,
                              fullLabel: true,
                              fullLabelText: "No Of Days",
                              readOnly: true,
                              textEditingController: ctrl.noOfDays.value,
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            InputField(
                              hint: "",
                              borderRadius: 7,
                              fullLabel: true,
                              fullLabelText: "Total Amount (Excl GST)",
                              readOnly: true,
                              textEditingController: ctrl.totalAmt.value,
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            InputField(
                              hint: "",
                              borderRadius: 7,
                              fullLabel: true,
                              fullLabelText: "Total Eligible Amount",
                              readOnly: true,
                              textEditingController: ctrl.totalElbAmt.value,
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            InputField(
                              hint: "Entry not found",
                              borderRadius: 7,
                              fullLabel: true,
                              fullLabelText: "Tax on room tariff",
                              readOnly: true,
                              textEditingController: ctrl.totalGstAmt.value,
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            InputField(
                              hint: "Entry not found",
                              borderRadius: 7,
                              fullLabel: true,
                              fullLabelText: "Total Payble",
                              readOnly: true,
                              textEditingController: ctrl.totalPayble.value,
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            filePicker(
                                fileName: "${ctrl.fileId}",
                                onatap: () {
                                  ctrl.selectFile(selector: "fileid");
                                },
                                selected:
                                    ctrl.file.value.path == "" ? false : true,
                                file: ctrl.file.value),
                            ctrl.fileSize.value != ""
                                ? Container(
                                    padding: EdgeInsets.all(5),
                                    // decoration: BoxDecoration(color: Colors.redAccent),
                                    child: Row(
                                      children: [
                                        Text(
                                          "File size : ${double.parse(ctrl.fileSize.value).toStringAsFixed(2)}mb",
                                          style: TextStyle(
                                              color: const Color.fromARGB(
                                                  255, 233, 1, 1),
                                              fontWeight: FontWeight.w600),
                                        ),
                                      ],
                                    ),
                                  )
                                : Container(),
                            SizedBox(
                              height: 20,
                            ),
                            filePicker(
                                fileName: "${ctrl.fileBill}",
                                onatap: () {
                                  ctrl.selectFile();
                                },
                                selected:
                                    ctrl.file2.value.path == "" ? false : true,
                                file: ctrl.file2.value),
                            ctrl.fileSize2.value != ""
                                ? Container(
                                    padding: EdgeInsets.all(5),
                                    // decoration: BoxDecoration(color: Colors.redAccent),
                                    child: Row(
                                      children: [
                                        Text(
                                          "File size : ${double.parse(ctrl.fileSize2.value).toStringAsFixed(2)}mb",
                                          style: TextStyle(
                                              color: const Color.fromARGB(
                                                  255, 233, 1, 1),
                                              fontWeight: FontWeight.w600),
                                        ),
                                      ],
                                    ),
                                  )
                                : Container(),
                            SizedBox(
                              height: 20,
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                );
              }
            },
          ),
        ),
        bottomNavigationBar: GetX(
          init: HolidayReimbController(),
          builder: (ctrl) {
            if (ctrl.loading.value == AppLoadingState.Loading) {
              return Container(
                height: 0,
              );
            } else {
              if (ctrl.availableReimbNight > 0) {
                return Container(
                  color: Colors.white,
                  padding: EdgeInsets.fromLTRB(20, 10, 20, 20),
                  height: 80,
                  child: MainButton(
                    buttonLable: "Submit",
                    onTap: () {
                      ctrl.submitData();
                    },
                  ),
                );
              } else {
                return Container(
                  height: 60,
                  decoration:
                      BoxDecoration(color: Theme.of(context).colorScheme.error),
                  child: Center(
                      child: Text(
                    "You don't have available nights",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                        shadows: [
                          BoxShadow(
                              color: const Color.fromARGB(255, 131, 10, 8),
                              blurRadius: 5)
                        ]),
                  )),
                );
              }
            }
          },
        ),
      ),
    );
  }

  Widget filePicker({onatap, fileName, selected, File? file}) {
    return GestureDetector(
      onTap: () {
        if (file?.path == "") {
        } else {
          Get.to(() => PdfViewPage(), arguments: file!.uri.path);
        }
      },
      child: Container(
        padding: EdgeInsets.only(left: selected == true ? 10 : 20),
        decoration: BoxDecoration(
            border: Border.all(color: Color(0xffF3F3F3)),
            borderRadius: BorderRadius.circular(10),
            color: Color(0xffFAFAFA)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Row(
                children: [
                  selected == true
                      ? GestureDetector(
                          onTap: () {
                            var ctrl = Get.find<HolidayReimbController>();
                            ctrl.removeFile(file: file!);
                          },
                          child: CircleAvatar(
                            maxRadius: 15,
                            minRadius: 15,
                            backgroundColor: Colors.transparent,
                            child: Icon(
                              Icons.picture_as_pdf,
                              color: Colors.green,
                            ),
                          ),
                        )
                      : Container(),
                  SizedBox(
                    width: selected == true ? 10 : 0,
                  ),
                  Flexible(
                    child: Text(
                      textAlign: TextAlign.left,
                      "$fileName",
                      style: TextStyle(fontSize: 16),
                      maxLines: 1,
                    ),
                  ),
                ],
              ),
            ),
            Material(
              borderRadius: BorderRadius.circular(10),
              child: InkWell(
                borderRadius: BorderRadius.circular(10),
                //
                onTap: onatap,
                child: Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.black12),
                      borderRadius: BorderRadius.circular(12)),
                  child: Center(
                    child: Icon(
                      Icons.add,
                      color: Colors.black45,
                      size: 32,
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
