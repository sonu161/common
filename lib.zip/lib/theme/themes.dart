import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CustomTheme {
  final Color primaryColor = Color(0xff24ACE1);
  var lightTheme = ThemeData(
    useMaterial3: true,
    colorScheme: const ColorScheme.light(
      primary: Color(0xff3D5AFE),
      onPrimary: Colors.white,
      onBackground: Color(0xffF5F5F5),
      onPrimaryContainer: Color(0xffF5F5F5),
      onSecondary: Color(0xff013e59),
      background: Color(0xffF5F5F5),
      secondary: Color(0xff53687e),
      error: Color(0xffFA8284),
    ),
    textTheme: TextTheme(
      bodyLarge: fontFamily,
      bodyMedium: fontFamily,
      bodySmall: fontFamily,
      titleSmall: fontFamily,
      displayLarge: fontFamily,
      displayMedium: fontFamily,
      displaySmall: fontFamily,
      headlineLarge: fontFamily,
      headlineMedium: fontFamily,
      headlineSmall: fontFamily,
      labelLarge: fontFamily,
      labelMedium: fontFamily,
      labelSmall: fontFamily,
      titleLarge: fontFamily,
      titleMedium: fontFamily,
    ),
    appBarTheme: AppBarTheme(
      toolbarHeight: 70,
      titleSpacing: 0,
      backgroundColor: Color(0xff3D5AFE),
      // backgroundColor: Color.fromARGB(255, 255, 255, 255),
      titleTextStyle: GoogleFonts.cabin(
        color: Color.fromARGB(255, 255, 255, 255),
        fontSize: 20,
        fontWeight: FontWeight.bold
      ),
      iconTheme: IconThemeData(
        color: Color.fromARGB(255, 255, 255, 255),
      ),
    ),
  );

  static TextStyle fontFamily = GoogleFonts.notoSans(
    fontWeight: FontWeight.w500
  );
}