import 'package:sidbi_app/app/holiday_vof/model/UtilityData.dart';

abstract class HolidayVofEnt{
  getBookings();
  getHolidayHomeData();
  getVofData();
  submitForm();
  cancelHHVfBooking();
  getAge();
  submitUtility({required UtilityData data});
}