abstract class HolidayVofEnt{
  getBookings();
  getHolidayHomeData();
  getVofData();
  submitForm();
  cancelHHVfBooking();
}