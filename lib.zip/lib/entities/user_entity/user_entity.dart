import 'package:sidbi_app/app/login/model/user_data.dart';
import 'package:sidbi_app/app/user/model/ProfileData.dart';

abstract class UserEntity{
  getCaptcha();
  userLogin(UserData data);
  verfiyOtp(String otp, String userid);
  reSendOtp(String userid);
  forgotPassord(
      {String userid, String email, String captcha, String orgCaptcha});
  updatePassword({String userid,String newPassword, String confirmPassword, String otp, String captcha, String orgCaptcha });
  getUserDetail();
  updateUserDetail(ProfileData proPayload);
  logout();
}