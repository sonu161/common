import 'dart:io';

import 'package:sidbi_app/app/pension_slip/model/pension_data.dart';

abstract class PensionEntity{
  getPensionDetail(PensionSlipData data);
}