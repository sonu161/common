abstract class HolidayReimEntity{
  getList();
  submitData();
  getReimbElg();
  getBookingDetail();
}