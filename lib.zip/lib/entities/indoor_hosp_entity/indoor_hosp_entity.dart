// import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

import '../../app/hospitalization_request/model/AccFormData.dart';

abstract class IndoorHospEntity{

  getIndoorHosp();
  viewDetailOfAccomodation(String formId);
  submitAccForm({required AccFormData datas});

}