abstract class LifeCertUploadHistEntity{
  getLifeCertHist();
  downloadFile();
}