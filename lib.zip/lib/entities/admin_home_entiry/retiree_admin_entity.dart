abstract class RetireeAdminEntity{
  getAllRetirees();
  getUserDetail();
}