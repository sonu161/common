abstract class RetireeCircularEntity{
  getCircularList();
  downloadFile();
}