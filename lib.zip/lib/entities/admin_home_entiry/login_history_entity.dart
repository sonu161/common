abstract class LoginHistoryEntity{
  getLoginHistoryList();
}