import '../../app/tax_declaration/model/tax_regime_data.dart';

abstract class TaxDecEntity{
  getDeclarationList();
  submitTaxDeclaration({taxData});
  saveTaxRegime({required TaxRegimeData regmData});
}