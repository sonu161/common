abstract class UploadLifeCertEntity{
  uploadLifeCert({String filepath});
  getLastFile();
  downloadFile();
}