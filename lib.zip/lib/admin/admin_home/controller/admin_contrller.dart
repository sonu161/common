import 'dart:convert';
import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/model/RetireeUserDetailData.dart';
import 'package:sidbi_app/admin/admin_home/model/RetireesDetailData.dart';
import 'package:sidbi_app/admin/admin_home/repo/admin_home_repo.dart';
import 'package:sidbi_app/components/helper.dart';

import '../../../app/login/controller/loging_ctrl.dart';

class AdminContrller extends GetxController{
  AdminHomeRepo repo = new AdminHomeRepo();
  var retireeLists = <Map<String,String>>[].obs;
  var data = new RetireesDetailData().obs;
  var userDetail = new RetireeUserDetailData().obs;
  var lists = <Map<String,String>>[].obs;
  var dropHint = "Select retiree".obs;
  var loading = AppLoadingState.Initial.obs;
  Helper helper = new Helper();

  getAllRetirees() async{
    try{
      loading.value = AppLoadingState.Loading;
      var res = await repo.getAllRetirees();
      if(res.statusCode == 200){
        print(jsonDecode(res.body));
        data.value = RetireesDetailData.fromJson(jsonDecode(res.body));
        for(var i = 0; i < data.value.retireesList!.length;i++){
          lists.add(
            {
              "name":"${data.value.retireesList![i].name}",
              "val":"${data.value.retireesList![i].id}"
            }
          );
        }
        loading.value = AppLoadingState.Loaded;
      }else{
        loading.value = AppLoadingState.Loaded;
      }

    }catch(e){

    }
  }

  setuserId({userid}){
    helper.setSharedPrefString(keyName: "userFor", value: userid);
    getUserDetail();
  }

  getUserDetail() async{
    try{
      helper.fullAppLoading();
      var res = await repo.getUserDetail();
      if(res.statusCode == 200){
        var data = jsonDecode(res.body);
        print(data);
        userDetail.value = RetireeUserDetailData.fromJson(data);
        Get.back();
      }
    }catch(e){

    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getAllRetirees();
  }


  // @override
  // void onReady() {
  //   // TODO: implement onReady
  //   super.onReady();
  //   getAllRetirees();
  // }
}