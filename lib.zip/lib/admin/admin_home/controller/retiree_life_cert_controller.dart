import 'dart:convert';

import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/model/LifeCertEmpsDataModel.dart';
import 'package:sidbi_app/admin/admin_home/repo/retiree_life_cert_repo.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/components/pdf_view.dart';

class RetireeLifeCertController extends GetxController {
  RetireeLifeCertRepo repo = new RetireeLifeCertRepo();

  var loading = AppLoadingState.Initial.obs;
  var listYear = [].obs;
  var yearSelected = false.obs;
  var yearGot = "".obs;
  RxList<LifeCertEmpsDataModel> empdata = <LifeCertEmpsDataModel>[].obs;
  Helper helper = new Helper();

  getFinancialYearsList() async {
    try {
      loading.value = AppLoadingState.Loading;
      var res = await repo.getFinancialYears();
      if(res.statusCode == 200){
        listYear.add(jsonDecode(res.body)['financialYearList']);
        print(listYear);
        loading.value = AppLoadingState.Loaded;
      }
      
    } catch (e) {
      print("Lifecycle data error : ${e}");
    }
  }

  getFinancialYearData({year}) async{
    try{
      loading.value = AppLoadingState.Loading;
      yearSelected.value = true;
      empdata.clear();
      yearGot.value = year;
      var res = await repo.getLifeCertsList(year: year);
      if(res.statusCode == 200){
        print(jsonDecode(res.body));
        var data = LifeCertEmpsDataModel.fromJson(jsonDecode(res.body));
        empdata.add(data);
        loading.value = AppLoadingState.Loaded;
      }else{

      }
    }
    catch(e){

    }
  }

  downloadCertificate({fileName, userid}) async{
    try{
      helper.fullAppLoading();
      var res = await repo.downloadCertificate(fileNames: fileName, userid: userid);
      try{
        Get.back();
        Get.to(() => PdfViewPage(), arguments: res.uri.path);
      }catch(e){
        Get.back();
        helper.messageAlert(title: "Error", message: "Some error occurred", type: AlertBoxType.Error);
      }
    }catch(e){

    }
  }


  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getFinancialYearsList();
  }

}
