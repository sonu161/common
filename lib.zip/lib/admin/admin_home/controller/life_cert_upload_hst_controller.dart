import 'dart:convert';

import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/repo/admin_home/life_cert_upload_hist_repo.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/helper.dart';

import '../../../components/pdf_view.dart';

class LifeCertUploadHstController extends GetxController{
  LifeCertUploadHistRepo repo = new LifeCertUploadHistRepo();
  var loading = AppLoadingState.Initial.obs;
  var dataList = [].obs;
  Helper helper = new Helper();
  getLifeCertHistory() async{
    try{
      loading.value = AppLoadingState.Loading;
      var res = await repo.getLifeCertHist();

      if(res.statusCode == 200){
        var data = jsonDecode(res.body);

        for(var i = 0; i < data['userLifeCertificates'].length;i++){
          dataList.add(data['userLifeCertificates'][i]);
        }
        print(jsonDecode(res.body));
        loading.value = AppLoadingState.Loaded;
      }

    }catch(e){

    }
  }

  downloadFile({year}) async{
    try{
      var res = await repo.downloadFile(year: year);
      try{
        Get.back();
        Get.to(() => PdfViewPage(), arguments: res.uri.path);
      }catch(e){
        Get.back();
        helper.messageAlert(title: "Error", message: "Some error occurred", type: AlertBoxType.Error);
      }
    }catch(e){

    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getLifeCertHistory();
  }
}