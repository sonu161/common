import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/controller/retiree_circular_controller.dart';
import 'package:sidbi_app/admin/admin_home/model/CircularData.dart';
import 'package:sidbi_app/admin/admin_home/repo/retiree_circular_repo.dart';
import 'package:sidbi_app/components/helper.dart';

class UploadCircularController extends GetxController {
  var fileName = "Please choose (.pdf) file".obs;
  var file = new File("").obs;
  var formKey = GlobalKey<FormState>().obs;
  RetireeCircularRepo repo = new RetireeCircularRepo();
  var circularT = TextEditingController().obs;
  Helper helper = new Helper();

  void validateForm() {
    final isValid = formKey.value.currentState?.validate();
    if (!isValid!) {
      // submitForm();
      print("Not valid");
      return;
    } else {
      print("valid");
      uploadCircular();
    }
    formKey.value.currentState?.save();
  }

  selectFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['jpg', 'pdf', 'doc'],
        allowMultiple: true);
    result?.files.first.bytes;
    fileName.value = result!.files.first.name.toString();
    List<File> files = result.paths.map((path) => File(path!)).toList();
    file.value = files.first;
    print(files.first);
  }

  uploadCircular() async {
    try {
      if(file.value.path == ""){
        helper.messageAlert(title: "Error", message: 'Please Select the file', type: AlertBoxType.Error);
      }else{
        helper.fullAppLoading();
        var res = await repo.uploadCircular(
            circularT: circularT.value.text, filePath: file.value.path);
        // if(res.statusCode == 200){
        print(jsonDecode(res));
        Get.back();
        helper.doneDialog(msg: "${jsonDecode(res)['message']}",onClose: (){
          var ctrl2 = Get.find<RetireeCircularController>();
          ctrl2.data.value = CircularData.fromJson(jsonDecode(res)['circularDetails']);
          ctrl2.data.refresh();
          Get.back();
          Get.back();
        });
      }

      // }
    } catch (e) {}
  }
}
