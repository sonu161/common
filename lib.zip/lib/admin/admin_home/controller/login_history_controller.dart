import 'dart:convert';

import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sidbi_app/admin/admin_home/repo/admin_home/login_history_repo.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/helper.dart';

class LoginHistoryController extends GetxController{
  Helper helper = new Helper();
  LoginHistoryRepo repo = new LoginHistoryRepo();
  var loading = AppLoadingState.Initial.obs;
  var datas = [].obs;

  getLoginHistList() async{
    try{
      loading.value = AppLoadingState.Loading;

      var res = await repo.getLoginHistoryList();
      print(jsonDecode(res.body));
      if(res.statusCode == 200){
        var jData = jsonDecode(res.body);
        for(var i = 0; i < jData['loghinHisList'].length; i++){
          datas.add(jData['loghinHisList'][i]);
        }
        loading.value = AppLoadingState.Loaded;
      }
    }catch(e){

    }
  }

  dateFormate({date}) async{
    var dateF = DateFormat("yyyy-MM-dd").parse(date);
    return dateF.day.toString();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getLoginHistList();
  }
}