import 'package:sidbi_app/components/helper.dart';

import '../../../entities/admin_home_entiry/retiree_admin_entity.dart';

class AdminHomeRepo extends RetireeAdminEntity{
  
  Helper helper = new Helper();
  @override
  getAllRetirees() async{
    try{
      var userid = await helper.getSharedPrefString(keyName: "userid");
      var res = await helper.getService("getAllRetirees/$userid");
      return res;
    }catch(e){
      print(e);
    }
  }

  getUserDetail() async{
    try{
      var logUserid = await helper.getSharedPrefString(keyName: "userid");
      var userid = await helper.getSharedPrefString(keyName: "userFor");
      var res = await helper.getService("retireeUserDetails/$logUserid/$userid");
      return res;
    }catch(e){
      
    }
  }

}