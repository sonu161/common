import 'package:sidbi_app/components/helper.dart';

import '../../../../entities/admin_home_entiry/life_cert_upload_hist_entity.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sidbi_app/components/pdf_view.dart';

import 'package:http/http.dart' as http;

class LifeCertUploadHistRepo extends LifeCertUploadHistEntity {
  Helper helper = new Helper();

  @override
  getLifeCertHist() async {
    try {
      var logUserid = await helper.getSharedPrefString(keyName: "userid");
      var userId = await helper.getSharedPrefString(keyName: "userFor");
      var res = await helper.getService("adminLifeCertiUserDtl/$logUserid/$userId");
      return res;
    } catch (e) {}
  }

  @override
  downloadFile({year}) async {
    var userid = await helper.getSharedPrefString(keyName: "userFor");
    var file = await helper.downloadPdfFile(
        tokenRequired: false,
        setFileName: "${userid}_${year}.pdf",
        url: "downloadLifeCertiPDFAdmin/$userid/$year",
        type: "GET");
    return file;
  }
}
