import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/entities/admin_home_entiry/login_history_entity.dart';

class LoginHistoryRepo extends LoginHistoryEntity {
  Helper helper = new Helper();
  @override
  getLoginHistoryList() async {
    try {
      var logUserid = await helper.getSharedPrefString(keyName: "userid");
      var userid = await helper.getSharedPrefString(keyName: "userFor");
      var res = await helper.getService("userLoginHistory/$logUserid/$userid");
      return res;
    } catch (e) {}
  }
}
