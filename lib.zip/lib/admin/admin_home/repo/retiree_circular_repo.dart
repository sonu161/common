import 'dart:convert';

import 'package:get/get.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/entities/admin_home_entiry/retiree_circular_entity.dart';

class RetireeCircularRepo extends RetireeCircularEntity{

  Helper helper = new Helper();

  @override
  getCircularList() async{
    try{
      
      var logUserid = await helper.getSharedPrefString(keyName: "userid");
      var res = await helper.getService("circularDetails/$logUserid");
      // var res = await helper.getStreamedService(url: "circularDetails");
      return res;
    }catch(e){

    }
  }

  downloadFile({fileName}) async{
    var logUserid = await helper.getSharedPrefString(keyName: "userid");
    var userid = await helper.getSharedPrefString(keyName: "userFor");
    var file = await helper.downloadPdfFile(
        setFileName: "${fileName.toString().replaceAll(" ", "_")}.pdf",
        url: "downloadPdfM/$logUserid",
        type: "POST",
        data: {
          "fileName":"$fileName"
        }
    );
    return file;
  }

  uploadCircular({circularT,filePath}) async{
    try{
      var logUserid = await helper.getSharedPrefString(keyName: "userid");
      var dataa = {
        "circularTitle": circularT.toString()
      };
      var res = await helper.postFormField(
        url: "Circularupload/$logUserid",
        data: dataa,
        path: filePath,
        fileKey: "circularFile"
      );
      return res;
    }catch(e){

    }
  }

}