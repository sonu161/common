class RetireesDetailData {
  RetireesDetailData({
      this.status, 
      this.message, 
      this.responseCode, 
      this.httpStatusCode, 
      this.empName, 
      this.empAddress, 
      this.empEmail, 
      this.empMobileNo, 
      this.empRetireeCode, 
      this.empSalCode, 
      this.empGrade, 
      this.pensionOptee, 
      this.familyPension, 
      this.massOptee, 
      this.pensionProcessingStatus, 
      this.empLoginActStatus, 
      this.lastLoginTime, 
      this.lastCertificateFileUpload, 
      this.selectedTaxRegime, 
      this.retireesList,});

  RetireesDetailData.fromJson(dynamic json) {
    status = json['status'];
    message = json['message'];
    responseCode = json['responseCode'];
    httpStatusCode = json['httpStatusCode'];
    empName = json['empName'];
    empAddress = json['empAddress'];
    empEmail = json['empEmail'];
    empMobileNo = json['empMobileNo'];
    empRetireeCode = json['empRetireeCode'];
    empSalCode = json['empSalCode'];
    empGrade = json['empGrade'];
    pensionOptee = json['pensionOptee'];
    familyPension = json['familyPension'];
    massOptee = json['massOptee'];
    pensionProcessingStatus = json['pensionProcessingStatus'];
    empLoginActStatus = json['empLoginActStatus'];
    lastLoginTime = json['lastLoginTime'];
    lastCertificateFileUpload = json['lastCertificateFileUpload'];
    selectedTaxRegime = json['selectedTaxRegime'];
    if (json['retireesList'] != null) {
      retireesList = [];
      json['retireesList'].forEach((v) {
        retireesList?.add(RetireesList.fromJson(v));
      });
    }
  }
  dynamic status;
  dynamic message;
  dynamic responseCode;
  dynamic httpStatusCode;
  dynamic empName;
  dynamic empAddress;
  dynamic empEmail;
  dynamic empMobileNo;
  dynamic empRetireeCode;
  dynamic empSalCode;
  dynamic empGrade;
  dynamic pensionOptee;
  dynamic familyPension;
  dynamic massOptee;
  dynamic pensionProcessingStatus;
  dynamic empLoginActStatus;
  dynamic lastLoginTime;
  dynamic lastCertificateFileUpload;
  dynamic selectedTaxRegime;
  List<RetireesList>? retireesList;
RetireesDetailData copyWith({  dynamic status,
  dynamic message,
  dynamic responseCode,
  dynamic httpStatusCode,
  dynamic empName,
  dynamic empAddress,
  dynamic empEmail,
  dynamic empMobileNo,
  dynamic empRetireeCode,
  dynamic empSalCode,
  dynamic empGrade,
  dynamic pensionOptee,
  dynamic familyPension,
  dynamic massOptee,
  dynamic pensionProcessingStatus,
  dynamic empLoginActStatus,
  dynamic lastLoginTime,
  dynamic lastCertificateFileUpload,
  dynamic selectedTaxRegime,
  List<RetireesList>? retireesList,
}) => RetireesDetailData(  status: status ?? this.status,
  message: message ?? this.message,
  responseCode: responseCode ?? this.responseCode,
  httpStatusCode: httpStatusCode ?? this.httpStatusCode,
  empName: empName ?? this.empName,
  empAddress: empAddress ?? this.empAddress,
  empEmail: empEmail ?? this.empEmail,
  empMobileNo: empMobileNo ?? this.empMobileNo,
  empRetireeCode: empRetireeCode ?? this.empRetireeCode,
  empSalCode: empSalCode ?? this.empSalCode,
  empGrade: empGrade ?? this.empGrade,
  pensionOptee: pensionOptee ?? this.pensionOptee,
  familyPension: familyPension ?? this.familyPension,
  massOptee: massOptee ?? this.massOptee,
  pensionProcessingStatus: pensionProcessingStatus ?? this.pensionProcessingStatus,
  empLoginActStatus: empLoginActStatus ?? this.empLoginActStatus,
  lastLoginTime: lastLoginTime ?? this.lastLoginTime,
  lastCertificateFileUpload: lastCertificateFileUpload ?? this.lastCertificateFileUpload,
  selectedTaxRegime: selectedTaxRegime ?? this.selectedTaxRegime,
  retireesList: retireesList ?? this.retireesList,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['message'] = message;
    map['responseCode'] = responseCode;
    map['httpStatusCode'] = httpStatusCode;
    map['empName'] = empName;
    map['empAddress'] = empAddress;
    map['empEmail'] = empEmail;
    map['empMobileNo'] = empMobileNo;
    map['empRetireeCode'] = empRetireeCode;
    map['empSalCode'] = empSalCode;
    map['empGrade'] = empGrade;
    map['pensionOptee'] = pensionOptee;
    map['familyPension'] = familyPension;
    map['massOptee'] = massOptee;
    map['pensionProcessingStatus'] = pensionProcessingStatus;
    map['empLoginActStatus'] = empLoginActStatus;
    map['lastLoginTime'] = lastLoginTime;
    map['lastCertificateFileUpload'] = lastCertificateFileUpload;
    map['selectedTaxRegime'] = selectedTaxRegime;
    if (retireesList != null) {
      map['retireesList'] = retireesList?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class RetireesList {
  RetireesList({
      this.id, 
      this.name,});

  RetireesList.fromJson(dynamic json) {
    id = json['id'];
    name = json['name'];
  }
  String? id;
  String? name;
RetireesList copyWith({  String? id,
  String? name,
}) => RetireesList(  id: id ?? this.id,
  name: name ?? this.name,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    return map;
  }

}