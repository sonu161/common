class LifeCertEmpsDataModel {
  LifeCertEmpsDataModel({
      this.status, 
      this.message, 
      this.responseCode, 
      this.httpStatusCode, 
      this.empName, 
      this.empAddress, 
      this.empEmail, 
      this.empMobileNo, 
      this.empRetireeCode, 
      this.empSalCode, 
      this.empGrade, 
      this.pensionOptee, 
      this.familyPension, 
      this.massOptee, 
      this.pensionProcessingStatus, 
      this.empLoginActStatus, 
      this.lastLoginTime, 
      this.lastCertificateFileUpload, 
      this.selectedTaxRegime, 
      this.fileObject, 
      this.retireesList, 
      this.userLifeCertificates, 
      this.lifeCertificateDtl, 
      this.accountStatus, 
      this.loghinHisList, 
      this.hhVofHisList, 
      this.indHospHistList, 
      this.financialYearList, 
      this.lifeCertificatesDtlList, 
      this.yearFilesMap, 
      this.circularDetails,});

  LifeCertEmpsDataModel.fromJson(dynamic json) {
    status = json['status'];
    message = json['message'];
    responseCode = json['responseCode'];
    httpStatusCode = json['httpStatusCode'];
    empName = json['empName'];
    empAddress = json['empAddress'];
    empEmail = json['empEmail'];
    empMobileNo = json['empMobileNo'];
    empRetireeCode = json['empRetireeCode'];
    empSalCode = json['empSalCode'];
    empGrade = json['empGrade'];
    pensionOptee = json['pensionOptee'];
    familyPension = json['familyPension'];
    massOptee = json['massOptee'];
    pensionProcessingStatus = json['pensionProcessingStatus'];
    empLoginActStatus = json['empLoginActStatus'];
    lastLoginTime = json['lastLoginTime'];
    lastCertificateFileUpload = json['lastCertificateFileUpload'];
    selectedTaxRegime = json['selectedTaxRegime'];
    fileObject = json['fileObject'];
    retireesList = json['retireesList'];
    userLifeCertificates = json['userLifeCertificates'];
    lifeCertificateDtl = json['lifeCertificateDtl'];
    accountStatus = json['accountStatus'];
    loghinHisList = json['loghinHisList'];
    hhVofHisList = json['hhVofHisList'];
    indHospHistList = json['indHospHistList'];
    financialYearList = json['financialYearList'];
    if (json['lifeCertificatesDtlList'] != null) {
      lifeCertificatesDtlList = [];
      json['lifeCertificatesDtlList'].forEach((v) {
        lifeCertificatesDtlList?.add(LifeCertificatesDtlList.fromJson(v));
      });
    }
    yearFilesMap = json['yearFilesMap'];
    circularDetails = json['circularDetails'];
  }
  dynamic status;
  dynamic message;
  dynamic responseCode;
  dynamic httpStatusCode;
  dynamic empName;
  dynamic empAddress;
  dynamic empEmail;
  dynamic empMobileNo;
  dynamic empRetireeCode;
  dynamic empSalCode;
  dynamic empGrade;
  dynamic pensionOptee;
  dynamic familyPension;
  dynamic massOptee;
  dynamic pensionProcessingStatus;
  dynamic empLoginActStatus;
  dynamic lastLoginTime;
  dynamic lastCertificateFileUpload;
  dynamic selectedTaxRegime;
  dynamic fileObject;
  dynamic retireesList;
  dynamic userLifeCertificates;
  dynamic lifeCertificateDtl;
  dynamic accountStatus;
  dynamic loghinHisList;
  dynamic hhVofHisList;
  dynamic indHospHistList;
  dynamic financialYearList;
  List<LifeCertificatesDtlList>? lifeCertificatesDtlList;
  dynamic yearFilesMap;
  dynamic circularDetails;
LifeCertEmpsDataModel copyWith({  dynamic status,
  dynamic message,
  dynamic responseCode,
  dynamic httpStatusCode,
  dynamic empName,
  dynamic empAddress,
  dynamic empEmail,
  dynamic empMobileNo,
  dynamic empRetireeCode,
  dynamic empSalCode,
  dynamic empGrade,
  dynamic pensionOptee,
  dynamic familyPension,
  dynamic massOptee,
  dynamic pensionProcessingStatus,
  dynamic empLoginActStatus,
  dynamic lastLoginTime,
  dynamic lastCertificateFileUpload,
  dynamic selectedTaxRegime,
  dynamic fileObject,
  dynamic retireesList,
  dynamic userLifeCertificates,
  dynamic lifeCertificateDtl,
  dynamic accountStatus,
  dynamic loghinHisList,
  dynamic hhVofHisList,
  dynamic indHospHistList,
  dynamic financialYearList,
  List<LifeCertificatesDtlList>? lifeCertificatesDtlList,
  dynamic yearFilesMap,
  dynamic circularDetails,
}) => LifeCertEmpsDataModel(  status: status ?? this.status,
  message: message ?? this.message,
  responseCode: responseCode ?? this.responseCode,
  httpStatusCode: httpStatusCode ?? this.httpStatusCode,
  empName: empName ?? this.empName,
  empAddress: empAddress ?? this.empAddress,
  empEmail: empEmail ?? this.empEmail,
  empMobileNo: empMobileNo ?? this.empMobileNo,
  empRetireeCode: empRetireeCode ?? this.empRetireeCode,
  empSalCode: empSalCode ?? this.empSalCode,
  empGrade: empGrade ?? this.empGrade,
  pensionOptee: pensionOptee ?? this.pensionOptee,
  familyPension: familyPension ?? this.familyPension,
  massOptee: massOptee ?? this.massOptee,
  pensionProcessingStatus: pensionProcessingStatus ?? this.pensionProcessingStatus,
  empLoginActStatus: empLoginActStatus ?? this.empLoginActStatus,
  lastLoginTime: lastLoginTime ?? this.lastLoginTime,
  lastCertificateFileUpload: lastCertificateFileUpload ?? this.lastCertificateFileUpload,
  selectedTaxRegime: selectedTaxRegime ?? this.selectedTaxRegime,
  fileObject: fileObject ?? this.fileObject,
  retireesList: retireesList ?? this.retireesList,
  userLifeCertificates: userLifeCertificates ?? this.userLifeCertificates,
  lifeCertificateDtl: lifeCertificateDtl ?? this.lifeCertificateDtl,
  accountStatus: accountStatus ?? this.accountStatus,
  loghinHisList: loghinHisList ?? this.loghinHisList,
  hhVofHisList: hhVofHisList ?? this.hhVofHisList,
  indHospHistList: indHospHistList ?? this.indHospHistList,
  financialYearList: financialYearList ?? this.financialYearList,
  lifeCertificatesDtlList: lifeCertificatesDtlList ?? this.lifeCertificatesDtlList,
  yearFilesMap: yearFilesMap ?? this.yearFilesMap,
  circularDetails: circularDetails ?? this.circularDetails,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['message'] = message;
    map['responseCode'] = responseCode;
    map['httpStatusCode'] = httpStatusCode;
    map['empName'] = empName;
    map['empAddress'] = empAddress;
    map['empEmail'] = empEmail;
    map['empMobileNo'] = empMobileNo;
    map['empRetireeCode'] = empRetireeCode;
    map['empSalCode'] = empSalCode;
    map['empGrade'] = empGrade;
    map['pensionOptee'] = pensionOptee;
    map['familyPension'] = familyPension;
    map['massOptee'] = massOptee;
    map['pensionProcessingStatus'] = pensionProcessingStatus;
    map['empLoginActStatus'] = empLoginActStatus;
    map['lastLoginTime'] = lastLoginTime;
    map['lastCertificateFileUpload'] = lastCertificateFileUpload;
    map['selectedTaxRegime'] = selectedTaxRegime;
    map['fileObject'] = fileObject;
    map['retireesList'] = retireesList;
    map['userLifeCertificates'] = userLifeCertificates;
    map['lifeCertificateDtl'] = lifeCertificateDtl;
    map['accountStatus'] = accountStatus;
    map['loghinHisList'] = loghinHisList;
    map['hhVofHisList'] = hhVofHisList;
    map['indHospHistList'] = indHospHistList;
    map['financialYearList'] = financialYearList;
    if (lifeCertificatesDtlList != null) {
      map['lifeCertificatesDtlList'] = lifeCertificatesDtlList?.map((v) => v.toJson()).toList();
    }
    map['yearFilesMap'] = yearFilesMap;
    map['circularDetails'] = circularDetails;
    return map;
  }

}

class LifeCertificatesDtlList {
  LifeCertificatesDtlList({
      this.srNumber, 
      this.fullName, 
      this.empNo, 
      this.fileName, 
      this.uploadedDate, 
      this.status,});

  LifeCertificatesDtlList.fromJson(dynamic json) {
    srNumber = json['srNumber'];
    fullName = json['fullName'];
    empNo = json['empNo'];
    fileName = json['fileName'];
    uploadedDate = json['uploadedDate'];
    status = json['status'];
  }
  String? srNumber;
  String? fullName;
  String? empNo;
  String? fileName;
  String? uploadedDate;
  String? status;
LifeCertificatesDtlList copyWith({  String? srNumber,
  String? fullName,
  String? empNo,
  String? fileName,
  String? uploadedDate,
  String? status,
}) => LifeCertificatesDtlList(  srNumber: srNumber ?? this.srNumber,
  fullName: fullName ?? this.fullName,
  empNo: empNo ?? this.empNo,
  fileName: fileName ?? this.fileName,
  uploadedDate: uploadedDate ?? this.uploadedDate,
  status: status ?? this.status,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['srNumber'] = srNumber;
    map['fullName'] = fullName;
    map['empNo'] = empNo;
    map['fileName'] = fileName;
    map['uploadedDate'] = uploadedDate;
    map['status'] = status;
    return map;
  }

}