class AdminVofHomListData {
  AdminVofHomListData({
      this.status, 
      this.message, 
      this.responseCode, 
      this.httpStatusCode, 
      this.empName, 
      this.empAddress, 
      this.empEmail, 
      this.empMobileNo, 
      this.empRetireeCode, 
      this.empSalCode, 
      this.empGrade, 
      this.pensionOptee, 
      this.familyPension, 
      this.massOptee, 
      this.pensionProcessingStatus, 
      this.empLoginActStatus, 
      this.lastLoginTime, 
      this.lastCertificateFileUpload, 
      this.selectedTaxRegime, 
      this.fileObject, 
      this.retireesList, 
      this.lifeCertificateDtl, 
      this.accountStatus, 
      this.loghinHisList, 
      this.hhVofHisList, 
      this.indHospHistList, 
      this.financialYearList, 
      this.lifeCertificatesDtlList, 
      this.yearFilesMap, 
      this.circularDetails,});

  AdminVofHomListData.fromJson(dynamic json) {
    status = json['status'];
    message = json['message'];
    responseCode = json['responseCode'];
    httpStatusCode = json['httpStatusCode'];
    empName = json['empName'];
    empAddress = json['empAddress'];
    empEmail = json['empEmail'];
    empMobileNo = json['empMobileNo'];
    empRetireeCode = json['empRetireeCode'];
    empSalCode = json['empSalCode'];
    empGrade = json['empGrade'];
    pensionOptee = json['pensionOptee'];
    familyPension = json['familyPension'];
    massOptee = json['massOptee'];
    pensionProcessingStatus = json['pensionProcessingStatus'];
    empLoginActStatus = json['empLoginActStatus'];
    lastLoginTime = json['lastLoginTime'];
    lastCertificateFileUpload = json['lastCertificateFileUpload'];
    selectedTaxRegime = json['selectedTaxRegime'];
    fileObject = json['fileObject'];
    retireesList = json['retireesList'];
    lifeCertificateDtl = json['lifeCertificateDtl'];
    accountStatus = json['accountStatus'];
    loghinHisList = json['loghinHisList'];
    if (json['hhVofHisList'] != null) {
      hhVofHisList = [];
      json['hhVofHisList'].forEach((v) {
        hhVofHisList?.add(HhVofHisList.fromJson(v));
      });
    }
    indHospHistList = json['indHospHistList'];
    financialYearList = json['financialYearList'];
    lifeCertificatesDtlList = json['lifeCertificatesDtlList'];
    yearFilesMap = json['yearFilesMap'];
    circularDetails = json['circularDetails'];
  }
  dynamic status;
  dynamic message;
  dynamic responseCode;
  dynamic httpStatusCode;
  dynamic empName;
  dynamic empAddress;
  dynamic empEmail;
  dynamic empMobileNo;
  dynamic empRetireeCode;
  dynamic empSalCode;
  dynamic empGrade;
  dynamic pensionOptee;
  dynamic familyPension;
  dynamic massOptee;
  dynamic pensionProcessingStatus;
  dynamic empLoginActStatus;
  dynamic lastLoginTime;
  dynamic lastCertificateFileUpload;
  dynamic selectedTaxRegime;
  dynamic fileObject;
  dynamic retireesList;
  dynamic lifeCertificateDtl;
  dynamic accountStatus;
  dynamic loghinHisList;
  List<HhVofHisList>? hhVofHisList;
  dynamic indHospHistList;
  dynamic financialYearList;
  dynamic lifeCertificatesDtlList;
  dynamic yearFilesMap;
  dynamic circularDetails;
AdminVofHomListData copyWith({  dynamic status,
  dynamic message,
  dynamic responseCode,
  dynamic httpStatusCode,
  dynamic empName,
  dynamic empAddress,
  dynamic empEmail,
  dynamic empMobileNo,
  dynamic empRetireeCode,
  dynamic empSalCode,
  dynamic empGrade,
  dynamic pensionOptee,
  dynamic familyPension,
  dynamic massOptee,
  dynamic pensionProcessingStatus,
  dynamic empLoginActStatus,
  dynamic lastLoginTime,
  dynamic lastCertificateFileUpload,
  dynamic selectedTaxRegime,
  dynamic fileObject,
  dynamic retireesList,
  dynamic lifeCertificateDtl,
  dynamic accountStatus,
  dynamic loghinHisList,
  List<HhVofHisList>? hhVofHisList,
  dynamic indHospHistList,
  dynamic financialYearList,
  dynamic lifeCertificatesDtlList,
  dynamic yearFilesMap,
  dynamic circularDetails,
}) => AdminVofHomListData(  status: status ?? this.status,
  message: message ?? this.message,
  responseCode: responseCode ?? this.responseCode,
  httpStatusCode: httpStatusCode ?? this.httpStatusCode,
  empName: empName ?? this.empName,
  empAddress: empAddress ?? this.empAddress,
  empEmail: empEmail ?? this.empEmail,
  empMobileNo: empMobileNo ?? this.empMobileNo,
  empRetireeCode: empRetireeCode ?? this.empRetireeCode,
  empSalCode: empSalCode ?? this.empSalCode,
  empGrade: empGrade ?? this.empGrade,
  pensionOptee: pensionOptee ?? this.pensionOptee,
  familyPension: familyPension ?? this.familyPension,
  massOptee: massOptee ?? this.massOptee,
  pensionProcessingStatus: pensionProcessingStatus ?? this.pensionProcessingStatus,
  empLoginActStatus: empLoginActStatus ?? this.empLoginActStatus,
  lastLoginTime: lastLoginTime ?? this.lastLoginTime,
  lastCertificateFileUpload: lastCertificateFileUpload ?? this.lastCertificateFileUpload,
  selectedTaxRegime: selectedTaxRegime ?? this.selectedTaxRegime,
  fileObject: fileObject ?? this.fileObject,
  retireesList: retireesList ?? this.retireesList,
  lifeCertificateDtl: lifeCertificateDtl ?? this.lifeCertificateDtl,
  accountStatus: accountStatus ?? this.accountStatus,
  loghinHisList: loghinHisList ?? this.loghinHisList,
  hhVofHisList: hhVofHisList ?? this.hhVofHisList,
  indHospHistList: indHospHistList ?? this.indHospHistList,
  financialYearList: financialYearList ?? this.financialYearList,
  lifeCertificatesDtlList: lifeCertificatesDtlList ?? this.lifeCertificatesDtlList,
  yearFilesMap: yearFilesMap ?? this.yearFilesMap,
  circularDetails: circularDetails ?? this.circularDetails,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['message'] = message;
    map['responseCode'] = responseCode;
    map['httpStatusCode'] = httpStatusCode;
    map['empName'] = empName;
    map['empAddress'] = empAddress;
    map['empEmail'] = empEmail;
    map['empMobileNo'] = empMobileNo;
    map['empRetireeCode'] = empRetireeCode;
    map['empSalCode'] = empSalCode;
    map['empGrade'] = empGrade;
    map['pensionOptee'] = pensionOptee;
    map['familyPension'] = familyPension;
    map['massOptee'] = massOptee;
    map['pensionProcessingStatus'] = pensionProcessingStatus;
    map['empLoginActStatus'] = empLoginActStatus;
    map['lastLoginTime'] = lastLoginTime;
    map['lastCertificateFileUpload'] = lastCertificateFileUpload;
    map['selectedTaxRegime'] = selectedTaxRegime;
    map['fileObject'] = fileObject;
    map['retireesList'] = retireesList;
    map['lifeCertificateDtl'] = lifeCertificateDtl;
    map['accountStatus'] = accountStatus;
    map['loghinHisList'] = loghinHisList;
    if (hhVofHisList != null) {
      map['hhVofHisList'] = hhVofHisList?.map((v) => v.toJson()).toList();
    }
    map['indHospHistList'] = indHospHistList;
    map['financialYearList'] = financialYearList;
    map['lifeCertificatesDtlList'] = lifeCertificatesDtlList;
    map['yearFilesMap'] = yearFilesMap;
    map['circularDetails'] = circularDetails;
    return map;
  }

}

class HhVofHisList {
  HhVofHisList({
      this.srNumber, 
      this.applType, 
      this.bookingPlace, 
      this.startDate, 
      this.startTime, 
      this.endDate, 
      this.endTime, 
      this.remark, 
      this.status, 
      this.applNumber, 
      this.empId, 
      this.bookingStatus, 
      this.mailSentStatus, 
      this.numberOfPeople, 
      this.numberOfRoom,});

  HhVofHisList.fromJson(dynamic json) {
    srNumber = json['srNumber'];
    applType = json['applType'];
    bookingPlace = json['bookingPlace'];
    startDate = json['startDate'];
    startTime = json['startTime'];
    endDate = json['endDate'];
    endTime = json['endTime'];
    remark = json['remark'];
    status = json['status'];
    applNumber = json['applNumber'];
    empId = json['empId'];
    bookingStatus = json['bookingStatus'];
    mailSentStatus = json['mailSentStatus'];
    numberOfPeople = json['numberOfPeople'];
    numberOfRoom = json['numberOfRoom'];
  }
  String? srNumber;
  String? applType;
  String? bookingPlace;
  String? startDate;
  String? startTime;
  String? endDate;
  String? endTime;
  String? remark;
  String? status;
  String? applNumber;
  String? empId;
  String? bookingStatus;
  String? mailSentStatus;
  String? numberOfPeople;
  String? numberOfRoom;
HhVofHisList copyWith({  String? srNumber,
  String? applType,
  String? bookingPlace,
  String? startDate,
  String? startTime,
  String? endDate,
  String? endTime,
  String? remark,
  String? status,
  String? applNumber,
  String? empId,
  String? bookingStatus,
  String? mailSentStatus,
  String? numberOfPeople,
  String? numberOfRoom,
}) => HhVofHisList(  srNumber: srNumber ?? this.srNumber,
  applType: applType ?? this.applType,
  bookingPlace: bookingPlace ?? this.bookingPlace,
  startDate: startDate ?? this.startDate,
  startTime: startTime ?? this.startTime,
  endDate: endDate ?? this.endDate,
  endTime: endTime ?? this.endTime,
  remark: remark ?? this.remark,
  status: status ?? this.status,
  applNumber: applNumber ?? this.applNumber,
  empId: empId ?? this.empId,
  bookingStatus: bookingStatus ?? this.bookingStatus,
  mailSentStatus: mailSentStatus ?? this.mailSentStatus,
  numberOfPeople: numberOfPeople ?? this.numberOfPeople,
  numberOfRoom: numberOfRoom ?? this.numberOfRoom,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['srNumber'] = srNumber;
    map['applType'] = applType;
    map['bookingPlace'] = bookingPlace;
    map['startDate'] = startDate;
    map['startTime'] = startTime;
    map['endDate'] = endDate;
    map['endTime'] = endTime;
    map['remark'] = remark;
    map['status'] = status;
    map['applNumber'] = applNumber;
    map['empId'] = empId;
    map['bookingStatus'] = bookingStatus;
    map['mailSentStatus'] = mailSentStatus;
    map['numberOfPeople'] = numberOfPeople;
    map['numberOfRoom'] = numberOfRoom;
    return map;
  }

}