class LifeSertEmpsDataModel {
  LifeSertEmpsDataModel({
      this.srNumber, 
      this.fullName, 
      this.empNo, 
      this.fileName, 
      this.uploadedDate, 
      this.status,});

  LifeSertEmpsDataModel.fromJson(dynamic json) {
    srNumber = json['srNumber'];
    fullName = json['fullName'];
    empNo = json['empNo'];
    fileName = json['fileName'];
    uploadedDate = json['uploadedDate'];
    status = json['status'];
  }
  String? srNumber;
  String? fullName;
  String? empNo;
  String? fileName;
  String? uploadedDate;
  String? status;
LifeSertEmpsDataModel copyWith({  String? srNumber,
  String? fullName,
  String? empNo,
  String? fileName,
  String? uploadedDate,
  String? status,
}) => LifeSertEmpsDataModel(  srNumber: srNumber ?? this.srNumber,
  fullName: fullName ?? this.fullName,
  empNo: empNo ?? this.empNo,
  fileName: fileName ?? this.fileName,
  uploadedDate: uploadedDate ?? this.uploadedDate,
  status: status ?? this.status,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['srNumber'] = srNumber;
    map['fullName'] = fullName;
    map['empNo'] = empNo;
    map['fileName'] = fileName;
    map['uploadedDate'] = uploadedDate;
    map['status'] = status;
    return map;
  }

}