class RetireeUserDetailData {
  RetireeUserDetailData({
      this.status, 
      this.message, 
      this.responseCode, 
      this.httpStatusCode, 
      this.empName, 
      this.empAddress, 
      this.empEmail, 
      this.empMobileNo, 
      this.empRetireeCode, 
      this.empSalCode, 
      this.empGrade, 
      this.pensionOptee, 
      this.familyPension, 
      this.massOptee, 
      this.pensionProcessingStatus, 
      this.empLoginActStatus, 
      this.lastLoginTime, 
      this.lastCertificateFileUpload, 
      this.selectedTaxRegime, 
      this.fileObject, 
      this.retireesList, 
      this.lifeCertificateDtl, 
      this.accountStatus, 
      this.loghinHisList, 
      this.hhVofHisList, 
      this.indHospHistList, 
      this.financialYearList, 
      this.lifeCertificatesDtlList, 
      this.yearFilesMap, 
      this.circularDetails,});

  RetireeUserDetailData.fromJson(dynamic json) {
    status = json['status'];
    message = json['message'];
    responseCode = json['responseCode'];
    httpStatusCode = json['httpStatusCode'];
    empName = json['empName'];
    empAddress = json['empAddress'];
    empEmail = json['empEmail'];
    empMobileNo = json['empMobileNo'];
    empRetireeCode = json['empRetireeCode'];
    empSalCode = json['empSalCode'];
    empGrade = json['empGrade'];
    pensionOptee = json['pensionOptee'];
    familyPension = json['familyPension'];
    massOptee = json['massOptee'];
    pensionProcessingStatus = json['pensionProcessingStatus'];
    empLoginActStatus = json['empLoginActStatus'];
    lastLoginTime = json['lastLoginTime'];
    lastCertificateFileUpload = json['lastCertificateFileUpload'];
    selectedTaxRegime = json['selectedTaxRegime'];
    fileObject = json['fileObject'];
    retireesList = json['retireesList'];
    lifeCertificateDtl = json['lifeCertificateDtl'];
    accountStatus = json['accountStatus'];
    loghinHisList = json['loghinHisList'];
    hhVofHisList = json['hhVofHisList'];
    indHospHistList = json['indHospHistList'];
    financialYearList = json['financialYearList'];
    lifeCertificatesDtlList = json['lifeCertificatesDtlList'];
    yearFilesMap = json['yearFilesMap'];
    circularDetails = json['circularDetails'];
  }
  dynamic status;
  dynamic message;
  dynamic responseCode;
  dynamic httpStatusCode;
  String? empName;
  String? empAddress;
  String? empEmail;
  String? empMobileNo;
  String? empRetireeCode;
  String? empSalCode;
  String? empGrade;
  String? pensionOptee;
  String? familyPension;
  String? massOptee;
  String? pensionProcessingStatus;
  dynamic empLoginActStatus;
  String? lastLoginTime;
  dynamic lastCertificateFileUpload;
  String? selectedTaxRegime;
  dynamic fileObject;
  dynamic retireesList;
  dynamic lifeCertificateDtl;
  String? accountStatus;
  dynamic loghinHisList;
  dynamic hhVofHisList;
  dynamic indHospHistList;
  dynamic financialYearList;
  dynamic lifeCertificatesDtlList;
  dynamic yearFilesMap;
  dynamic circularDetails;
RetireeUserDetailData copyWith({  dynamic status,
  dynamic message,
  dynamic responseCode,
  dynamic httpStatusCode,
  String? empName,
  String? empAddress,
  String? empEmail,
  String? empMobileNo,
  String? empRetireeCode,
  String? empSalCode,
  String? empGrade,
  String? pensionOptee,
  String? familyPension,
  String? massOptee,
  String? pensionProcessingStatus,
  dynamic empLoginActStatus,
  String? lastLoginTime,
  dynamic lastCertificateFileUpload,
  String? selectedTaxRegime,
  dynamic fileObject,
  dynamic retireesList,
  dynamic lifeCertificateDtl,
  String? accountStatus,
  dynamic loghinHisList,
  dynamic hhVofHisList,
  dynamic indHospHistList,
  dynamic financialYearList,
  dynamic lifeCertificatesDtlList,
  dynamic yearFilesMap,
  dynamic circularDetails,
}) => RetireeUserDetailData(  status: status ?? this.status,
  message: message ?? this.message,
  responseCode: responseCode ?? this.responseCode,
  httpStatusCode: httpStatusCode ?? this.httpStatusCode,
  empName: empName ?? this.empName,
  empAddress: empAddress ?? this.empAddress,
  empEmail: empEmail ?? this.empEmail,
  empMobileNo: empMobileNo ?? this.empMobileNo,
  empRetireeCode: empRetireeCode ?? this.empRetireeCode,
  empSalCode: empSalCode ?? this.empSalCode,
  empGrade: empGrade ?? this.empGrade,
  pensionOptee: pensionOptee ?? this.pensionOptee,
  familyPension: familyPension ?? this.familyPension,
  massOptee: massOptee ?? this.massOptee,
  pensionProcessingStatus: pensionProcessingStatus ?? this.pensionProcessingStatus,
  empLoginActStatus: empLoginActStatus ?? this.empLoginActStatus,
  lastLoginTime: lastLoginTime ?? this.lastLoginTime,
  lastCertificateFileUpload: lastCertificateFileUpload ?? this.lastCertificateFileUpload,
  selectedTaxRegime: selectedTaxRegime ?? this.selectedTaxRegime,
  fileObject: fileObject ?? this.fileObject,
  retireesList: retireesList ?? this.retireesList,
  lifeCertificateDtl: lifeCertificateDtl ?? this.lifeCertificateDtl,
  accountStatus: accountStatus ?? this.accountStatus,
  loghinHisList: loghinHisList ?? this.loghinHisList,
  hhVofHisList: hhVofHisList ?? this.hhVofHisList,
  indHospHistList: indHospHistList ?? this.indHospHistList,
  financialYearList: financialYearList ?? this.financialYearList,
  lifeCertificatesDtlList: lifeCertificatesDtlList ?? this.lifeCertificatesDtlList,
  yearFilesMap: yearFilesMap ?? this.yearFilesMap,
  circularDetails: circularDetails ?? this.circularDetails,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['message'] = message;
    map['responseCode'] = responseCode;
    map['httpStatusCode'] = httpStatusCode;
    map['empName'] = empName;
    map['empAddress'] = empAddress;
    map['empEmail'] = empEmail;
    map['empMobileNo'] = empMobileNo;
    map['empRetireeCode'] = empRetireeCode;
    map['empSalCode'] = empSalCode;
    map['empGrade'] = empGrade;
    map['pensionOptee'] = pensionOptee;
    map['familyPension'] = familyPension;
    map['massOptee'] = massOptee;
    map['pensionProcessingStatus'] = pensionProcessingStatus;
    map['empLoginActStatus'] = empLoginActStatus;
    map['lastLoginTime'] = lastLoginTime;
    map['lastCertificateFileUpload'] = lastCertificateFileUpload;
    map['selectedTaxRegime'] = selectedTaxRegime;
    map['fileObject'] = fileObject;
    map['retireesList'] = retireesList;
    map['lifeCertificateDtl'] = lifeCertificateDtl;
    map['accountStatus'] = accountStatus;
    map['loghinHisList'] = loghinHisList;
    map['hhVofHisList'] = hhVofHisList;
    map['indHospHistList'] = indHospHistList;
    map['financialYearList'] = financialYearList;
    map['lifeCertificatesDtlList'] = lifeCertificatesDtlList;
    map['yearFilesMap'] = yearFilesMap;
    map['circularDetails'] = circularDetails;
    return map;
  }

}