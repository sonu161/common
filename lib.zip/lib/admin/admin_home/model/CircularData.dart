class CircularData {
  CircularData({
      this.data,});

  CircularData.fromJson(dynamic json) {
    if (json['data'] != null) {
      data = [];
      json['data'].forEach((v) {
        data?.add(Data.fromJson(v));
      });
    }
  }
  List<Data>? data;
CircularData copyWith({  List<Data>? data,
}) => CircularData(  data: data ?? this.data,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (data != null) {
      map['data'] = data?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class Data {
  Data({
      this.year, 
      this.documentsName,});

  Data.fromJson(dynamic json) {
    year = json['year'];
    documentsName = json['documents_name'] != null ? json['documents_name'].cast<String>() : [];
  }
  String? year;
  List<String>? documentsName;
Data copyWith({  String? year,
  List<String>? documentsName,
}) => Data(  year: year ?? this.year,
  documentsName: documentsName ?? this.documentsName,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['year'] = year;
    map['documents_name'] = documentsName;
    return map;
  }

}