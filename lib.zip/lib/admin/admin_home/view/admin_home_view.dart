import 'package:flutter/Material.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/controller/admin_contrller.dart';
import 'package:sidbi_app/admin/admin_home/controller/retiree_circular_controller.dart';
import 'package:sidbi_app/admin/admin_home/controller/retiree_life_cert_controller.dart';
import 'package:sidbi_app/admin/admin_home/view/admin_home/login_history.dart';
import 'package:sidbi_app/admin/admin_home/view/retiree_admin.dart';
import 'package:sidbi_app/admin/admin_home/view/circular/retiree_circular.dart';
import 'package:sidbi_app/admin/admin_home/view/retire_life_cert/retiree_life_cert.dart';
import 'package:sidbi_app/app/settings/view/settings.dart';
import 'package:sidbi_app/components/drop_down_btn.dart';
import 'package:sidbi_app/components/main_button.dart';
import 'package:timeline_tile/timeline_tile.dart';

import '../../../components/shaps/triangle.dart';
import 'dart:math' as math;

class AdminHomeView extends StatelessWidget {
  const AdminHomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return AdminHomeViewLoader();
  }
}

class AdminHomeViewLoader extends StatefulWidget {
  const AdminHomeViewLoader({super.key});

  @override
  State<AdminHomeViewLoader> createState() => _AdminHomeViewLoaderState();
}

class _AdminHomeViewLoaderState extends State<AdminHomeViewLoader> {
  @override
  void initState() {
    super.initState();
    Get.find<AdminContrller>();
    Get.find<RetireeCircularController>();
    Get.find<RetireeLifeCertController>();
  }
  showAction() {
    showModalBottomSheet(
        isScrollControlled: false,
        context: context,
        backgroundColor: Color(0xffF4F4F4),
        showDragHandle: true,
        builder: (context) {
          return Container(
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                color: Color(0xffF4F4F4),
                borderRadius: BorderRadius.horizontal(
                    left: Radius.circular(10), right: Radius.circular(10))),
            child: Container(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
              child: Column(
                children: [
                  tabOptions(optionName: "Login History Detail", postion: 1,),
                  tabOptions(optionName: "VOF / Holiday Home", postion: 2),
                  tabOptions(
                      optionName: "Indoor Hospitalization Claim Detail",
                      postion: 3),
                  tabOptions(optionName: "Claim Details", postion: 4),
                  tabOptions(
                      optionName: "Life Certificate Upload History",
                      postion: 5),
                  tabOptions(
                      optionName: "Pension / Form16 Detail",
                      postion: 6,
                      last: true),
                ],
              ),
            ),
          );
        });
  }

  Widget tabOptions(
      {String? optionName,
      required int postion,
      onTap,
      bool? last,
      bool? close}) {
    return Container(
      width: MediaQuery.of(context).size.width,
      margin: EdgeInsets.only(bottom: 2),
      decoration: BoxDecoration(
        // color: Colors.white,
        // ,
        gradient: LinearGradient(colors: [
          Color.fromARGB(255, 38, 14, 255),
          Color.fromARGB(255, 171, 197, 255),
        ]),
        borderRadius: postion == 1 && last == null || last == false
            ? BorderRadius.only(
                topRight: Radius.circular(15),
                topLeft: Radius.circular(15),
              )
            : last == true
                ? BorderRadius.only(
                    bottomRight: Radius.circular(15),
                    bottomLeft: Radius.circular(15),
                  )
                : BorderRadius.zero,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: postion == 1 && last == null || last == false
            ? BorderRadius.only(
                topRight: Radius.circular(15),
                topLeft: Radius.circular(15),
              )
            : last == true
                ? BorderRadius.only(
                    bottomRight: Radius.circular(15),
                    bottomLeft: Radius.circular(15),
                  )
                : BorderRadius.zero,
        child: InkWell(
          onTap: () {},
          borderRadius: postion == 1 && last == null || last == false
              ? BorderRadius.only(
                  topRight: Radius.circular(15),
                  topLeft: Radius.circular(15),
                )
              : last == true
                  ? BorderRadius.only(
                      bottomRight: Radius.circular(15),
                      bottomLeft: Radius.circular(15),
                    )
                  : BorderRadius.zero,
          child: Padding(
            padding: EdgeInsets.fromLTRB(15, 17, 15, 17),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "$optionName",
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                      color: Colors.white),
                ),
                Icon(Icons.chevron_right)
              ],
            ),
          ),
        ),
      ),
    );
  }

  testSheet() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return DraggableScrollableSheet(
          initialChildSize: 0.5,
          maxChildSize: 1,
          minChildSize: 0.25,
          builder: (BuildContext context, ScrollController scrollController) {
            return Container(
              color: Colors.white,
              child: ListView.builder(
                controller: scrollController,
                itemCount: 25,
                itemBuilder: (BuildContext context, int index) {
                  return ListTile(title: Text('Item $index'));
                },
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          titleSpacing: 25,
          title: Text(
            "Admin",
            style: TextStyle(fontSize: 25),
          ),
          actions: [
            IconButton(
                onPressed: (){
                  Get.to(()=>SettingsView());
                },
                icon: Icon(Icons.settings)
            )
          ],
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(70),
            child: Container(
              padding: EdgeInsets.only(bottom: 10),
              child: TabBar(
                unselectedLabelStyle:
                    TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                dividerColor: Colors.transparent,
                labelColor: Theme.of(context).primaryColor,
                labelStyle: TextStyle(fontWeight: FontWeight.bold),
                indicatorSize: TabBarIndicatorSize.tab,
                isScrollable: true,
                automaticIndicatorColorAdjustment: true,
                tabAlignment: TabAlignment.start,
                indicatorColor: Colors.transparent,
                labelPadding: EdgeInsets.fromLTRB(20, 0, 20, 0),
                padding: EdgeInsets.fromLTRB(20, 0, 20, 0),
                indicator: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(300)),
                tabs: [
                  Tab(
                    text: "Retiree Admin",
                  ),
                  Tab(
                    text: "Retiree Circular",
                  ),
                  Tab(
                    text: "Retiree Life Certificate",
                  ),
                ],
              ),
            ),
          ),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Theme.of(context).colorScheme.primary,
                  Colors.purple,
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomRight
              ),
            ),
          ),
        ),
        body: TabBarView(
          physics: NeverScrollableScrollPhysics(),
          children: [
            RetireeAdmin(),
            RetireeCircular(),
            RetireeLifeCert()
          ],
        ),
        // bottomNavigationBar: Container(
        //   child: ,
        // ),
      ),
    );
  }

  Widget heightSizedBox() {
    return SizedBox(height: 20);
  }

  Widget dataRowView({String? title, String? detail, Color? color,}) {
    final hsl = HSLColor.fromColor(color!);
    final hslDark = hsl.withLightness((hsl.lightness - .3).clamp(0.0, 1.0));
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Flexible(
          child: Row(
            children: [
              Flexible(
                flex: 4,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                      color: color.withOpacity(0.1) ??
                          Color.fromARGB(255, 169, 255, 213),
                  ),
                  child: Center(
                      child: Text(
                    "$title".tr,
                    style: TextStyle(
                        color:hslDark.toColor(), fontWeight: FontWeight.w900),
                    textAlign: TextAlign.center,
                  )),
                ),
              ),
              Container(
                child: RotationTransition(
                    turns: new AlwaysStoppedAnimation(90 / 360),
                    child: CustomPaint(
                      painter: TrianglePainter(
                        strokeColor: color!.withOpacity(0.1) ??
                            Color.fromARGB(255, 169, 255, 213),
                        strokeWidth: 0,
                        paintingStyle: PaintingStyle.fill,
                      ),
                      child: const SizedBox(
                        height: 38,
                        width: 39,
                      ),
                    )),
              ),
            ],
          ),
        ),
        Flexible(
          child: Container(
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(5),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black87.withOpacity(0.2), blurRadius: 2)
                ]),
            child: Text(
              "$detail",
              style: TextStyle(fontSize: 17),
            ),
          ),
        )
      ],
    );
  }
}
