import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/Material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/controller/upload_circular_controller.dart';
import 'package:sidbi_app/components/form_field.dart';
import 'package:sidbi_app/components/light_button.dart';
import 'package:sidbi_app/components/pdf_view.dart';

import '../../../../components/main_button.dart';

class UploadCircular extends StatelessWidget {
  const UploadCircular({super.key});

  @override
  Widget build(BuildContext context) {
    return const UploadCircularLoader();
  }
}

class UploadCircularLoader extends StatefulWidget {
  const UploadCircularLoader({super.key});

  @override
  State<UploadCircularLoader> createState() => _UploadCircularLoaderState();
}

class _UploadCircularLoaderState extends State<UploadCircularLoader> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Upload Circular"),
      ),
      body: SingleChildScrollView(
        child: GetX(
          init: UploadCircularController(),
          builder: (ctrl) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  decoration: BoxDecoration(color: Colors.white),
                  padding: EdgeInsets.fromLTRB(20, 20, 20, 20),
                  child: Form(
                    key: ctrl.formKey.value,
                    child: FormFields(
                      hint: "Enter title",
                      fullLabel: true,
                      fullLabelText: "Circular Title",
                      textEditingController: ctrl.circularT.value,
                    ),
                  ),
                ),
                Center(
                  child: Container(
                    margin: EdgeInsets.only(top: 20),
                    child: DottedBorder(
                      child: InkWell(
                        onTap: (){
                          // ctrl.selectFile();
                          // print(ctrl.file.value.path);
                          if(ctrl.file.value.path == ""){
                            ctrl.selectFile();
                          }else{
                            Get.to(()=>PdfViewPage(),arguments: ctrl.file.value.uri.path);
                          }
                        },
                        child: Container(
                          height: MediaQuery.of(context).size.width / 1.1,
                          width: MediaQuery.of(context).size.width / 1.1,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12)),
                          child: Center(
                            child: Stack(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Image.asset(
                                      "assets/icons/pdf-icon.png",
                                      width: 100,
                                      height: 100,
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    Text("${ctrl.fileName}"),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    LightButton(
                                      buttonLable: "Select File",
                                      showIcon: false,
                                      onTap: (){
                                        ctrl.selectFile();
                                      },
                                    )
                                  ],
                                ),
                                ctrl.file.value.path != "" ?Positioned(
                                  top: 10,
                                  right: 15,
                                  child: Text("Tap to view file",style: TextStyle(
                                    color: Theme.of(context).colorScheme.error
                                  ),),
                                ):Container()
                              ],
                            ),
                          ),
                        ),
                      ),
                      borderType: BorderType.RRect,
                      radius: Radius.circular(12),
                      strokeWidth: 2,
                      dashPattern: [10],
                      color: Colors.black26,
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(20, 20, 20, 10),
                  child: Column(
                    children: [
                      MainButton(
                        buttonLable: "Upload",
                        onTap: () {
                          ctrl.validateForm();
                        },
                      ),
                    ],
                  ),
                )
              ],
            );
          },
        ),
      ),
    );
  }
}
