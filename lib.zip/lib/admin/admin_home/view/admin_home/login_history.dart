import 'package:flutter/Material.dart';
import 'package:get/get.dart';
import 'package:hive/hive.dart';
import 'package:intl/intl.dart';
import 'package:sidbi_app/admin/admin_home/controller/login_history_controller.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/loading.dart';
import 'dart:math' as math;

import 'package:sidbi_app/components/no_data.dart';

class LoginHistory extends StatelessWidget {
  const LoginHistory({super.key});

  @override
  Widget build(BuildContext context) {
    return LoginHistoryLoader();
  }
}

class LoginHistoryLoader extends StatefulWidget {
  const LoginHistoryLoader({super.key});

  @override
  State<LoginHistoryLoader> createState() => _LoginHistoryLoaderState();
}

class _LoginHistoryLoaderState extends State<LoginHistoryLoader> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login history"),
      ),
      body: GetX(
        init: LoginHistoryController(),
        builder: (ctrl){
          if(ctrl.loading.value == AppLoadingState.Loading){
            return LoadingApp();
          }else{
            if(ctrl.datas.length > 0){
              return ListView.builder(
                padding: EdgeInsets.only(
                  top: 10
                ),
                itemCount: ctrl.datas.length,
                itemBuilder: (context, index) {
                  return listTileUi(dataGet: ctrl.datas, index: index,colors: Colors.primaries[math.Random()
                      .nextInt(Colors.primaries.length)]);
                },
              );
            }else{
              return NoData(
                refresh:(){
                  ctrl.getLoginHistList();
                },
              );
            }

          }

        },
      ),
    );
  }

  Widget listTileUi({dataGet,index,Color? colors}){
    final hsl = HSLColor.fromColor(colors!);
    final hslDark = hsl.withLightness((hsl.lightness - .3).clamp(0.0, 1.0));
    return Container(
      padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
      margin: EdgeInsets.only(
        bottom: 5,
      ),
      decoration: BoxDecoration(
          color: Colors.white,
        // boxShadow: [
        //   BoxShadow(
        //     color: Color(0xffc2c2c2),
        //     blurRadius: 1,
        //     offset: Offset(0,1)
        //   ),
        // ],
        borderRadius: BorderRadius.all(Radius.circular(10))
      ),
      child: ListTile(
        leading: Container(
          padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
          decoration: BoxDecoration(
              color: colors.withOpacity(0.2),
              borderRadius: BorderRadius.circular(10)
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text("${dataGet[index]['loginTime'].toString().split("-")[2].split(" ")[0]}",style: TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 20,
                color: hslDark.toColor()

              ),),
              Text("${dataGet[index]['loginTime'].toString().split("-")[1]}/${dataGet[index]['loginTime'].toString().split("-")[0]}")
            ],
          ),
        ),
        title: Text("${dataGet[index]['status']}"),
        subtitle: Text("${dataGet[index]['type']}"),
      ),
    );
  }
}

