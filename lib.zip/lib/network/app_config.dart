enum Environment{
  dev,
  stage,
  prod,
  uat
}

// const baseUrl = "http://172.18.7.123:8989/api/";
const baseUrl = "http://172.30.1.235:8989/newretireeportal/cph";

Map<String, dynamic>? config;

void setEnvironment(Environment env){
  switch (env) {
    case Environment.dev:
      config = devConstants;
      break;
    case Environment.stage:
      config = stageConstants;
      break;
    case Environment.uat:
      config = uat;
      break;
    case Environment.prod:
      config = prodConstants;
      break;
  }
}

dynamic get apiBaseUrl {
  return config![baseUrl];
}

Map<String, dynamic> devConstants = {
  baseUrl: "http://172.30.1.235:8080/newretireeportal/",
};


Map<String, dynamic> stageConstants = {
  baseUrl: "http://172.18.7.123:8989/api/",
};

Map<String, dynamic> prodConstants = {
  baseUrl: "https://retireeportal.sidbi.in/newretireeportal/",
};

Map<String, dynamic> uat = {
  baseUrl: "https://retireeportal-uat.sidbi.in/newretireeportal/"
};