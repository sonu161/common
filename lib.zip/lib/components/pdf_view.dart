import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/components/helper.dart';

class PdfViewPage extends StatefulWidget {
  const PdfViewPage({super.key});

  @override
  State<PdfViewPage> createState() => _PdfViewPageState();
}

class _PdfViewPageState extends State<PdfViewPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Text("${Get.arguments.toString().split('/').last}"),
      ),
      body: PDFView(
        nightMode: false,
        filePath: Get.arguments,
        enableSwipe: true,
        swipeHorizontal: true,
        autoSpacing: false,
        pageFling: false,
        onError: (error) {
          // print("Error ${error}");
          Get.back();
          Helper().messageAlert(title: "Error", message: "Data not available", type: AlertBoxType.Error);
        },
        onPageError: (page, error) {
          print('Errorsss : $page: ${error.toString()}');
        },
        onViewCreated: (PDFViewController pdfViewController) {
        },
      ),
    );
  }
}
