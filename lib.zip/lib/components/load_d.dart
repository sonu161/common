import 'package:flutter/material.dart';

class LoadD extends StatelessWidget {
  const LoadD({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 50,
      height: 50,
      child: Image.asset("assets/icons/loading4.gif"),
    );
  }
}
