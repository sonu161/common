import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_rx/src/rx_workers/utils/debouncer.dart';
import 'package:sidbi_app/components/presets.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

import '../app/login/controller/loging_ctrl.dart';
import 'helper.dart';

class DateInput extends StatefulWidget {
  const DateInput(
      {super.key,
      this.borderRadius,
      this.fullLabel,
      this.fullLabelText,
      this.lightTextBox,
      this.readOnly,
      required this.hint,
      this.textEditingController,
      this.obsecureText,
      this.fieldIcon,
      this.obsecureToNoSecure,
      this.textAlign,
      this.fieldError,
      this.validator,
      this.validatorText,
      this.dateRangePickerController,
      this.dateDivider,
      this.validate,
      this.onChanged,
      this.startDate,
      this.endDate,
      this.clickable,
      this.disabled});
  final String hint;
  final DateRangePickerController? dateRangePickerController;
  final TextEditingController? textEditingController;
  final bool? obsecureText;
  final Icon? fieldIcon;
  final Function()? obsecureToNoSecure;
  final TextAlign? textAlign;
  final bool? fieldError;
  final double? borderRadius;
  final bool? fullLabel;
  final String? fullLabelText;
  final bool? lightTextBox;
  final bool? readOnly;
  final bool? validator;
  final String? validatorText;
  final String? dateDivider;
  final String? Function(String?)? validate;
  final void Function(String)? onChanged;
  final DateTime? startDate;
  final DateTime? endDate;
  final bool? clickable;
  final bool? disabled;
  @override
  State<DateInput> createState() => _DateInputState();
}

class _DateInputState extends State<DateInput> {
  final _debouncer = Debouncer(delay: const Duration(seconds: 1));

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        widget.fullLabel == null
            ? Container()
            : Container(
                margin: EdgeInsets.only(left: 5, bottom: 5),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text("${widget.fullLabelText}"),
                ),
              ),
        Container(
          padding: const EdgeInsets.only(right: 10, left: 5),
          decoration: BoxDecoration(
              border: Border.all(color: Color(0xffF3F3F3), width: 1),
              color: widget.disabled == true?
              Color(0xffECEFF1)
              : widget.readOnly == true
                  ? Color(0xffFAFAFA)
                  : widget.lightTextBox == null
                      ? Color(0xffFAFAFA)
                      : widget.lightTextBox == true
                          ? Color(0xffffffff)
                          : Color(0xffFAFAFA),
              borderRadius: BorderRadius.all(
                  Radius.circular(widget.borderRadius ?? 300))),
          child: Row(
            children: [
              widget.fieldIcon == null
                  ? Container()
                  : Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(300)),
                          boxShadow: [
                            BoxShadow(
                                color: const Color.fromARGB(25, 0, 0, 0),
                                blurRadius: 4)
                          ]),
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        child: widget.fieldIcon,
                      ),
                    ),
              SizedBox(
                width: 15,
              ),
              Expanded(
                child: Focus(
                  child: TextFormField(
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    onChanged: (value) async {
                      _debouncer(() {
                        setState(() {
                          print(value);
                        });
                      });
                    },
                    // widget.onChanged,
                    validator: widget.validate ??
                        (value) {
                          if (value!.isEmpty) {
                            return "This field is required";
                          }
                          return null;
                        },
                    onTap: () async {
                      if (widget.clickable == true ||
                          widget.clickable == null) {
                        var helper = Get.find<Helper>();
                        await helper.calenderShow(
                            dataformateSet: widget.hint,
                            dateDivider: widget.dateDivider,
                            context: context,
                            controller: widget.dateRangePickerController,
                            textEditingController: widget.textEditingController,
                            startDate: widget.startDate,
                            endDate: widget.endDate);
                      }
                      // helper.showTimePicker();
                    },
                    readOnly: widget.readOnly ?? false,
                    obscureText: widget.obsecureText ?? false,
                    decoration: InputDecoration(
                        // contentPadding: EdgeInsets.only(
                        //   top: -15,
                        //   bottom: 0
                        // ),
                        // suffix: widget.obsecureText == null ?null:IconButton(
                        //   icon: Icon(Icons.remove_red_eye),
                        //   onPressed: (){},
                        // ),
                        border: InputBorder.none,
                        hintText:
                            widget.hint.toUpperCase().replaceAll("/", " / "),
                        hintStyle: TextStyle(fontSize: 15)),
                    controller: widget.textEditingController,
                    textAlign: widget.textAlign == null
                        ? TextAlign.left
                        : widget.textAlign!,
                  ),
                ),
              ),
              widget.obsecureText == null
                  ? Container(width: 0, height: 0)
                  : IconButton(
                      icon: Icon(
                        widget.obsecureText == true
                            ? Icons.visibility
                            : Icons.visibility_off,
                        color: Presets.lightColorIcon,
                      ),
                      onPressed: widget.obsecureToNoSecure,
                    )
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.only(top: 5),
          child: Align(
              alignment: Alignment.centerLeft,
              child: widget.validator == false || widget.validator == null
                  ? Container()
                  : Container(
                      padding: EdgeInsets.all(10),
                      margin: EdgeInsets.fromLTRB(5, 0, 20, 0),
                      decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(5)),
                      child: Row(
                        children: [
                          Icon(
                            Icons.warning,
                            color: Colors.red,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "${widget.validatorText}",
                            style: TextStyle(color: Colors.red),
                          ),
                        ],
                      ),
                    )),
        )
      ],
    );
  }
}
