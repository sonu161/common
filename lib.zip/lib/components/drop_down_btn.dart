import 'package:flutter/material.dart';

import '../app/login/repos/static_datas.dart';

class DropDownBtn extends StatefulWidget {
  const DropDownBtn({super.key,this.setTheme,this.dynamicData, this.hint, this.data, this.dropItemChild, this.onChange, this.value});
  final String? hint;
  final List<Map<String, String>>? data;
  final List<dynamic>? dynamicData;
  final String? dropItemChild;
  final void Function(String?)? onChange;
  final String? value;
  final bool? setTheme;

  @override
  State<DropDownBtn> createState() => _DropDownBtnState();
}

class _DropDownBtnState extends State<DropDownBtn> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(top: 6, bottom: 6, left: 15, right: 15),
      decoration: BoxDecoration(
          color: widget.setTheme == true?Theme.of(context).primaryColor.withOpacity(0.2):Colors.transparent,
          border: Border.all(color: Colors.black12),
          borderRadius: BorderRadius.circular(7)),
      child: DropdownButtonFormField<String>(
        autovalidateMode: AutovalidateMode.onUserInteraction,
        isDense: false,
        itemHeight: 50,
        decoration: InputDecoration.collapsed(hintText: "Select Value"),
        hint: Text("${widget.hint}",style: TextStyle(
          color: widget.value == "" && widget.setTheme == true
        ? Theme.of(context).primaryColor
            : widget.value == "" && widget.setTheme == false
              || widget.setTheme == null ?Colors.black54:Colors.black
        ),),
        validator: (value) => value == null ? 'field required' : null,
        // underline: Container(
        //   height: 0,
        //   width: 0,
        // ),
        icon: RotationTransition(
      
          turns: new AlwaysStoppedAnimation(90 / 360),
          child: Icon(Icons.chevron_right,color: widget.setTheme == true?Theme.of(context).primaryColor:null,size: 30,),
        ),
      
        isExpanded: true,
        items: widget.data?.map((Map<String, String> value) {
          return DropdownMenuItem(
            value: value.toString(),
            child: Text(value[widget.dropItemChild]!), //dynamic //value[widget.dropItemChild]!
          );
        }).toList(),
        onChanged:widget.onChange??(val){},
      ),
    );
  }
}
