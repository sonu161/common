import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/comp_controllers/loading_controller.dart';

class MainButton extends StatefulWidget {
  final String buttonLable;
  final Function()? onTap;
  final double? borderRadius;
  final bool? disabled;
  final EdgeInsets? padding;
  final bool? warnState;
  const MainButton(
      {super.key,
      required this.buttonLable,
      this.onTap,
      this.borderRadius,
      this.disabled,
      this.padding,
      this.warnState});

  @override
  State<MainButton> createState() => _MainButtonState();
}

class _MainButtonState extends State<MainButton> {
  @override
  Widget build(BuildContext context) {
    return GetX(
        init: LoadingController(),
        builder: (ctrl) {
          if (ctrl.appLoadingState.value == AppLoadingState.Loading) {
            return SizedBox(
              width: 30,
              height: 30,
              child: CircularProgressIndicator(),
            );
          } else {
            return Material(
              borderRadius: widget.borderRadius == null
                  ? BorderRadius.all(Radius.circular(300))
                  : BorderRadius.all(Radius.circular(widget.borderRadius!)),
              color: widget.disabled == null || widget.disabled == false
                  ? widget.warnState == true
                      ? Theme.of(context).colorScheme.error
                      : Theme.of(context).colorScheme.primary
                  : widget.disabled == true
                      ? Theme.of(context).colorScheme.primary.withOpacity(0.2)
                      : Theme.of(context).colorScheme.primary.withOpacity(0.2),
              child: InkWell(
                splashColor: widget.disabled == null || widget.disabled == false
                    ? widget.warnState == true
                    ? Theme.of(context).colorScheme.error
                    : Theme.of(context).colorScheme.onPrimary
                    : widget.disabled == true
                        ? Theme.of(context)
                            .colorScheme
                            .onPrimary
                            .withOpacity(0.2)
                        : Theme.of(context)
                            .colorScheme
                            .onPrimary
                            .withOpacity(0.2),
                borderRadius: widget.borderRadius == null
                    ? BorderRadius.all(Radius.circular(300))
                    : BorderRadius.all(Radius.circular(widget.borderRadius!)),
                onTap: widget.disabled == false || widget.disabled == null
                    ? widget.onTap
                    : widget.disabled == true
                        ? null
                        : null,
                child: Container(
                  padding: widget.padding ?? EdgeInsets.all(12),
                  decoration: BoxDecoration(
                      color: widget.disabled == null || widget.disabled == false
                          ? widget.warnState == true
                          ? Theme.of(context).colorScheme.error
                          : Color.fromARGB(255, 86, 128, 243)
                          : widget.disabled == true
                              ? Theme.of(context)
                                  .colorScheme
                                  .primary
                                  .withOpacity(0.2)
                              : Theme.of(context)
                                  .colorScheme
                                  .primary
                                  .withOpacity(0.2),
                      borderRadius: widget.borderRadius == null
                          ? BorderRadius.all(Radius.circular(300))
                          : BorderRadius.all(
                              Radius.circular(widget.borderRadius!))),
                  child: Center(
                    child: Text(
                      widget.buttonLable,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          // fontWeight: FontWeight.bold,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
            );
          }
        });
    ;
  }
}
