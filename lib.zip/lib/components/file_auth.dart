import 'dart:io';
import 'dart:typed_data';

import 'package:syncfusion_flutter_pdf/pdf.dart';

class FileAuthCheck {
  final Uint8List file;
  FileAuthCheck({required this.file}) {
    Uint8List bytes = this.file;
    final PdfDocument document = PdfDocument(inputBytes: bytes);
    String content = PdfTextExtractor(document).extractText();
    // print("Sonu : " + content);
    document.dispose();
    var htmlRegex = new RegExp("<([A-Za-z][A-Za-z0-9]*)\b[^>]*>(.*?)</\1>");
    print("Sonu : " +htmlRegex.allMatches(content).toString());
  }
}
