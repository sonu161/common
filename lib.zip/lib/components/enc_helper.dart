// import 'package:crypto_dart/crypto_dart.dart';
// import 'dart:convert' show utf8;
// import 'package:sidbi_app/components/algos.dart';
import 'dart:convert';

import 'package:crypto_dart/crypto_dart.dart';
import 'package:encrypt/encrypt.dart';
import 'package:convert/convert.dart';

class EncHelper{
  cryptoEnc({text,key}){
    // final secKey = CryptoDart.enc.Utf8.parse(key);
    // print(secKey);
    // final userId = CryptoDart.enc.Utf8.parse(text);
    // final encryptedUserid = CryptoDart.AES.encrypt(userId, secKey,options: CipherOptions(
    //   mode: Mode.ECB,
    //   padding: Padding.PKCS7
    // ));
    // print(encryptedUserid);
    // return encryptedUserid;
  }


  cryptoDec({text,key}){
    final secKey = CryptoDart.enc.Utf8.parse("1234567890123456");
    final userId = text;
    final encryptedUserid = CryptoDart.AES.decrypt(userId, secKey);
    print("Decrypt : "+utf8.decode(encryptedUserid).toString());
  }



  String encryptOtp({text,keys}) {
    final key = Key.fromUtf8(keys??'1234567890123456');
    final encrypter = Encrypter(AES(key, mode: AESMode.ecb, padding: 'PKCS7'));
    final encrypted = encrypter.encrypt(text);
    print("encrypted.toString() : ${encrypted.base64}");
    return encrypted.base64;
  }

  decryptAes({text, keys}){
    final key = Key.fromUtf8(keys??'1234567890123456');
    final encrypter = Encrypter(AES(key, mode: AESMode.ecb, padding: 'PKCS7'));
    final decrypt = encrypter.decrypt64(text);
    return decrypt;
  }

}