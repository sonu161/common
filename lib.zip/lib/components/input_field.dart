import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/components/presets.dart';

import '../app/login/controller/loging_ctrl.dart';

class InputField extends StatefulWidget {
  const InputField(
      {super.key,
      this.borderRadius,
      this.fullLabel,
      this.fullLabelText,
      this.lightTextBox,
      this.readOnly,
      required this.hint,
      this.textEditingController,
      this.obsecureText,
      this.fieldIcon,
      this.obsecureToNoSecure,
      this.textAlign,
      this.fieldError,
      this.validator,
      this.validatorText,
      this.onTap,
      this.disabled,
      this.onchange,
      this.bigFieldImage,
      this.trailingBtn,
      this.onTapTrailing,
      this.showLoading,this.trailingBtnAnimated});

  final String hint;
  final TextEditingController? textEditingController;
  final bool? obsecureText;
  final Image? fieldIcon;
  final Function()? obsecureToNoSecure;
  final TextAlign? textAlign;
  final bool? fieldError;
  final double? borderRadius;
  final bool? fullLabel;
  final String? fullLabelText;
  final bool? lightTextBox;
  final bool? readOnly;
  final bool? validator;
  final String? validatorText;
  final Function()? onTap;
  final bool? disabled;
  final void Function(String)? onchange;
  final bool? bigFieldImage;
  final Icon? trailingBtn;
  final Function()? onTapTrailing;
  final bool? showLoading;
  final Icon? trailingBtnAnimated;

  @override
  State<InputField> createState() => _InputFieldState();
}

class _InputFieldState extends State<InputField> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        widget.fullLabel == null
            ? Container()
            : Container(
                margin: EdgeInsets.only(left: 5, bottom: 5),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text("${widget.fullLabelText}"),
                ),
              ),
        Container(
          padding: const EdgeInsets.only(right: 10, left: 5),
          decoration: BoxDecoration(
              border: Border.all(color: Color(0xffF3F3F3), width: 1),
              color: widget.disabled == null
                  ? Color(0xffFAFAFA)
                  : widget.disabled == true
                      ? Color(0xffECEFF1)
                      : widget.readOnly == true
                          ? Color(0xffFAFAFA)
                          : widget.lightTextBox == null
                              ? Color(0xffFAFAFA)
                              : widget.lightTextBox == true
                                  ? Color(0xffffffff)
                                  : Color(0xffFAFAFA),
              borderRadius: BorderRadius.all(
                  Radius.circular(widget.borderRadius ?? 300))),
          child: Row(
            children: [
              widget.fieldIcon == null
                  ? Container()
                  : widget.bigFieldImage == null
                      ? Container(
                          decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(300)),
                              boxShadow: [
                                BoxShadow(
                                    color: const Color.fromARGB(25, 0, 0, 0),
                                    blurRadius: 4)
                              ]),
                          child: CircleAvatar(
                            backgroundColor: Colors.white,
                            child: widget.fieldIcon,
                          ),
                        )
                      : Container(
                          child: widget.fieldIcon,
                        ),
              SizedBox(
                width: 15,
              ),
              Expanded(
                child: Focus(
                  child: TextField(
                    onChanged: widget.onchange,
                    onTap: widget.onTap,
                    readOnly: widget.readOnly ?? false,
                    obscureText: widget.obsecureText ?? false,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: widget.hint,
                      hintStyle: TextStyle(fontSize: 15),
                    ),
                    controller: widget.textEditingController,
                    textAlign: widget.textAlign == null
                        ? TextAlign.left
                        : widget.textAlign!,
                  ),
                ),
              ),
              widget.obsecureText == null
                  ? Container(width: 0, height: 0)
                  : IconButton(
                      icon: Icon(
                        widget.obsecureText == true
                            ? Icons.visibility
                            : Icons.visibility_off,
                        color: widget.obsecureText == true
                            ? Presets.lightColorIcon
                            : Theme.of(context).colorScheme.primary,
                      ),
                      onPressed: widget.obsecureToNoSecure,
                    ),
              widget.trailingBtn == null || widget.showLoading == true
                  ? Container()
                  : Container(
                      // child: Icon(Icons.refresh),
                      child: InkWell(
                        onTap: widget.onTapTrailing,
                        child: widget.trailingBtn,
                      ),
                    ),
              widget.showLoading == true
                  ? Container(
                      child: SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(),
                      ),
                    )
                  : Container()
            ],
          ),
        ),
        Container(
          margin: EdgeInsets.only(top: 5),
          child: Align(
              alignment: Alignment.centerLeft,
              child: widget.validator == false || widget.validator == null
                  ? Container()
                  : Container(
                      padding: EdgeInsets.all(10),
                      margin: EdgeInsets.fromLTRB(5, 0, 20, 0),
                      decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(5)),
                      child: Row(
                        children: [
                          Icon(
                            Icons.warning,
                            color: Colors.red,
                            size: 15,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "${widget.validatorText}",
                            style: TextStyle(color: Colors.red),
                          ),
                        ],
                      ),
                    )),
        )
      ],
    );
  }
}
