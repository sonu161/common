import 'package:flutter/material.dart';

class Presets {
  static Color boldSizeColor = Color(0xff647176);
  static Color boldBigSizeColor = Color(0xff647176);
  static Color lightColorIcon = Color(0x4D000000);
}