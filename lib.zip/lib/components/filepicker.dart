import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/holiday_reimb/controller/holiday_reimb_controller.dart';
import 'package:sidbi_app/components/pdf_view.dart';

class Filepicker extends StatefulWidget {
  Filepicker({super.key,this.ontap, this.fileName, this.file});

  void Function()? ontap;
  String? fileName; 
  bool? selected; 
  File? file;

  @override
  State<Filepicker> createState() => _FilepickerState();
}

class _FilepickerState extends State<Filepicker> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (widget.file?.path == "") {
        } else {
          Get.to(() => PdfViewPage(), arguments: widget.file!.uri.path);
        }
      },
      child: Container(
        padding: EdgeInsets.only(left: widget.selected == true ? 10 : 20),
        decoration: BoxDecoration(
            border: Border.all(color: Color(0xffF3F3F3)),
            borderRadius: BorderRadius.circular(10),
            color: Color(0xffFAFAFA)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Row(
                children: [
                  widget.selected == true
                      ? GestureDetector(
                          onTap: () {
                            var ctrl = Get.find<HolidayReimbController>();
                            ctrl.removeFile(file: widget.file!);
                          },
                          child: CircleAvatar(
                            maxRadius: 15,
                            minRadius: 15,
                            backgroundColor: Colors.transparent,
                            child: Icon(
                              Icons.picture_as_pdf,
                              color: Colors.green,
                            ),
                          ),
                        )
                      : Container(),
                  SizedBox(
                    width: widget.selected == true ? 10 : 0,
                  ),
                  Flexible(
                    child: Text(
                      textAlign: TextAlign.left,
                      "${widget.fileName}",
                      style: TextStyle(fontSize: 16),
                      maxLines: 1,
                    ),
                  ),
                ],
              ),
            ),
            Material(
              borderRadius: BorderRadius.circular(10),
              child: InkWell(
                borderRadius: BorderRadius.circular(10),
                //
                onTap: widget.ontap,
                child: Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.black12),
                      borderRadius: BorderRadius.circular(12)),
                  child: Center(
                    child: Icon(
                      Icons.add,
                      color: Colors.black45,
                      size: 32,
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}