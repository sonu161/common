import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';

class PinField extends StatelessWidget {
  const PinField({super.key, this.controller, this.lable, this.pinLength, this.validator, this.validatorText});

  final TextEditingController? controller;
  final String? lable;
  final int? pinLength;
  final bool? validator;
  final String? validatorText;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Container(
          child: Align(
              alignment: Alignment.centerLeft,
              child: Text("${this.lable}".tr)),
        ),
        SizedBox(
          height: 10,
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: Pinput(
            controller: this.controller,
            autofocus: true,
            keyboardType: TextInputType.number,
            obscureText: false,
            pinAnimationType: PinAnimationType.scale,
            focusedPinTheme: PinTheme(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(
                        color: Theme.of(context).colorScheme.primary
                    ),
                    borderRadius: BorderRadius.circular(10)),
                textStyle: TextStyle(fontSize: 17)),
            followingPinTheme: PinTheme(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)),
                textStyle: TextStyle(fontSize: 17)),
            defaultPinTheme: PinTheme(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)),
                textStyle: TextStyle(color: Colors.black, fontSize: 17)),
            length: this.pinLength!,
          ),

        ),
        this.validator == false || this.validator == null ? Container():Container(
          padding: EdgeInsets.all(10),
          margin: EdgeInsets.fromLTRB(5, 10, 20, 0),
          decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.1),
              borderRadius: BorderRadius.circular(5)
          ),
          child: Row(
            children: [
              Icon(
                Icons.warning,
                color: Colors.red,
                size: 15,
              ),
              SizedBox(
                width: 5,
              ),
              Text(
                "${this.validatorText}",
                style: TextStyle(color: Colors.red),
              ),
            ],
          ),
        )
      ],
    );
  }
}
