import 'package:flutter/material.dart';

class MyAppBar {
  appBar({context, appBarName}){
    return PreferredSize(preferredSize: Size.fromHeight(65), child: AppBar(
      backgroundColor: Theme.of(context).colorScheme.primary,
      title: appBarName,
    ));
  }
}
