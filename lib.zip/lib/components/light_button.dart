import 'package:flutter/material.dart';

class LightButton extends StatelessWidget {
  final String buttonLable;
  final Function()? onTap;
  final Icon? buttonIcon;
  final bool? showIcon;
  const LightButton({super.key, required this.buttonLable, this.onTap, this.buttonIcon, this.showIcon});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: Theme.of(context)
                  .colorScheme
                  .onPrimary,
              borderRadius: const BorderRadius.all(
                  Radius.circular(300))),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if(this.showIcon == true)
                  this.buttonIcon!
                else if(this.showIcon == null)
                  Icon(Icons.close)
                else
                  Container(),
                Text(
                  buttonLable,
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
