import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class DateController extends GetxController{
  setDateOnField({TextEditingController? field}){

  }

}