import 'package:flutter/animation.dart';
import 'package:get/get.dart';

class MainButtonCtrl extends GetxController{
  var controller = AnimationController;
  Animation<Offset>? offset;
}