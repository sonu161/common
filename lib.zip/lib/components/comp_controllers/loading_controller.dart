import 'package:get/get.dart';

import '../../app/login/controller/loging_ctrl.dart';

class LoadingController extends GetxController{
  var appLoadingState = AppLoadingState.Initial.obs;
  var refreshingState = RefreshState.Initial.obs;
}