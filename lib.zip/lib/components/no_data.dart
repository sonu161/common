import 'package:flutter/Material.dart';
import 'package:sidbi_app/components/main_button.dart';

class NoData extends StatelessWidget {
  const NoData({super.key, this.refresh});
  final Function()? refresh;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height / 1.5,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image(
              image: AssetImage("assets/images/no_data.png"),
              height: 150,
            ),
            SizedBox(
              height: 30,
            ),
            Text(
              "No Data found",
              style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.w900,
                  fontSize: 19),
            ),
            Text(
              "Try to refresh or try after some time",
              style: TextStyle(color: Colors.black54, fontSize: 17),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                MainButton(
                  buttonLable: "Refresh",
                  padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                  onTap: this.refresh,
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
