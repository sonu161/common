import 'package:get/get.dart';

var timeout_error_heading = "Error";
var timeout_error_msg = "Request time out, please try again";