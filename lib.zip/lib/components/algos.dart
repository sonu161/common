import 'package:pointycastle/api.dart';

class Algos{
  static Padding? padd = Padding("PKCS7");

}