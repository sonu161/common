import 'package:flutter/Material.dart';
import 'package:sidbi_app/components/main_button.dart';

class OptionalBlankPage extends StatefulWidget {
  const OptionalBlankPage({super.key, this.onTap, this.title, this.buttonTitle});

  final dynamic Function()? onTap;
  final String? title;
  final String? buttonTitle;

  @override
  State<OptionalBlankPage> createState() => _OptionalBlankPageState();
}

class _OptionalBlankPageState extends State<OptionalBlankPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black26.withOpacity(0.1),
                            blurRadius: 7,
                            offset: Offset(0,5)
                        )
                      ]
                  ),
                  child: Column(
                    children: [
                      Text(
                        "${widget.title}",
                        // "Select year to see submitted \n life certificate",
                        style: TextStyle(
                            fontSize: 17,
                            color: Theme.of(context).colorScheme.onSecondary,
                            fontWeight: FontWeight.bold
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          MainButton(buttonLable: "${widget.buttonTitle}",onTap: widget.onTap,),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
