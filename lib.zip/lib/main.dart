import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/login/views/login_page.dart';
import 'package:sidbi_app/app/settings/model/languages_string.dart';
import 'package:sidbi_app/bindings.dart';
import 'package:sidbi_app/network/app_config.dart';
import 'package:sidbi_app/network/http_override.dart';
import 'package:sidbi_app/theme/themes.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  HttpOverrides.global = MyHttpOverrides();
  setEnvironment(Environment.dev);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp
    ]);
    return Sizer(
      builder: (contex, Orientation or, screenType) {
        return GetMaterialApp(
          translations: LangsString(),
          initialBinding: AllBindings(),
          locale: Locale('en_IN'),
          fallbackLocale: Locale('en_US'),
          title: 'Retiree portal',
          theme: CustomTheme().lightTheme,
          // darkTheme: CustomTheme().darkTheme,
          // darkTheme: CustomTheme().darkTheme,
          debugShowCheckedModeBanner: false,
          opaqueRoute: true,
          home: const MyHomePage(),
          builder: (context, child) {
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(0.8)), 
              child: child!
            );
          },
        );
      },
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override 
  void initState() { 
    super.initState(); 
    Timer(Duration(seconds: 3), 
          ()=>Get.offAll(LoginPage())
         );
  } 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
        body: Center(child: Container(
          child: Material(
            child: Hero(
            tag: "logoooo",
            child: Image.asset("assets/images/sidbi_logo.gif"),
          ),
          ),
        )));
  }
}
