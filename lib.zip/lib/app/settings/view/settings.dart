import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/feedback/view/feedback_view.dart';
import 'package:sidbi_app/app/home/controller/home_controller.dart';
import 'package:sidbi_app/app/login/repos/login_repo.dart';
import 'package:sidbi_app/app/settings/controller/lang_ctrl.dart';
import 'package:sidbi_app/app/update_password/views/update_password_views.dart';
import 'package:sidbi_app/app/user/view/user_edit_view.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sizer/sizer.dart';

import '../../../components/lang_list.dart';

class SettingsView extends StatefulWidget {
  const SettingsView({super.key});

  @override
  State<SettingsView> createState() => _SettingsViewState();
}

class _SettingsViewState extends State<SettingsView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        title: Text("Profile Settings".tr),
        titleSpacing: 5,
      ),
      body: Container(
        child: SingleChildScrollView(
          padding: EdgeInsets.only(top: 0),
          child: GetX(
            init: LangController(),
            builder: (ctrl) {
              print(ctrl.useid.value);
              return Column(
                children: [
                  Hero(
                    tag: "profileCard",
                    child: Material(
                      child: Container(
                        height: 120,
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.onPrimary,
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black12,
                                blurRadius: 5,
                                offset: Offset(0, 5))
                          ],
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              top: 25,
                              left: 20,
                              child: Container(
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(300),
                                    boxShadow: [
                                      BoxShadow(
                                          color: Color.fromARGB(18, 0, 0, 0),
                                          blurRadius: 5,
                                          offset: Offset(0, 3))
                                    ]),
                                child: CircleAvatar(
                                  minRadius: 30,
                                  maxRadius: 30,
                                  backgroundColor: Theme.of(context)
                                      .colorScheme
                                      .primary
                                      .withOpacity(0.1),
                                  backgroundImage:
                                  AssetImage("assets/icons/pensioner.png"),
                                ),
                              ),
                            ),
                            GetX(
                              init: HomeController(),
                              builder: (ctrl) {
                                return Positioned(
                                    left: 100,
                                    top: 40,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "${ctrl.name.value}",
                                          style: Theme.of(context).textTheme.headlineSmall,
                                        ),
                                        Text(
                                          "${ctrl.email.value}",
                                          style: Theme.of(context).textTheme.labelLarge,
                                        ),
                                      ],
                                    ));
                              },
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 50,
                  ),
                  Container(
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 20),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              "Account".tr,
                              style: TextStyle(
                                  // color: Theme.of(context).colorScheme.primary,
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w700),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Column(
                          children: [
                            Container(
                              decoration: BoxDecoration(color: Theme.of(context).colorScheme.onPrimary),
                              child: ListTile(
                                onTap: () {
                                  Get.to(() => UserEditView());
                                },
                                leading: Icon(
                                  Icons.person,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                                minTileHeight: 60,
                                minVerticalPadding: 0,
                                contentPadding:
                                    EdgeInsets.fromLTRB(20, 0, 20, 0),
                                title: Text(
                                  "Edit Account".tr,
                                  style: TextStyle(
                                    fontSize: 15.sp,
                                      color: Theme.of(context).colorScheme.onSecondary,
                                      fontWeight: FontWeight.w700),
                                ),
                                trailing: Icon(
                                  Icons.arrow_forward_ios,
                                  size: 15.sp,
                                      color: Theme.of(context).colorScheme.onSecondary,
                                ),
                              ),
                            ),
                            // /
                            // Container(
                            //   decoration: BoxDecoration(color: Colors.white),
                            //   child: ListTile(
                            //     onTap: () {
                            //       Get.to(() => UpdatePasswordViews(),
                            //           arguments: ctrl.useid.value);
                            //     },
                            //     leading: Icon(
                            //       Icons.key,
                            //       color: Theme.of(context).colorScheme.primary,
                            //     ),
                            //     minTileHeight: 60,
                            //     minVerticalPadding: 0,
                            //     contentPadding:
                            //         EdgeInsets.fromLTRB(20, 0, 20, 0),
                            //     title: Text("Change Password".tr,
                            //         style: TextStyle(
                            //             color: Colors.black54,
                            //             fontWeight: FontWeight.w700)),
                            //     trailing: Icon(
                            //       Icons.arrow_forward_ios,
                            //       size: 15,
                            //     ),
                            //   ),
                            // ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 20),
                          child: Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              "Settings".tr,
                              style: TextStyle(
                                  // color: Theme.of(context).colorScheme.primary,
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w700),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Column(
                          children: [
                            Container(
                              decoration: BoxDecoration(color: Theme.of(context).colorScheme.onPrimary),
                              child: ListTile(
                                leading: Icon(
                                  Icons.language,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                                minTileHeight: 60,
                                minVerticalPadding: 0,
                                contentPadding:
                                    EdgeInsets.fromLTRB(20, 0, 20, 0),
                                title: Text(
                                  "Language".tr,
                                  style: TextStyle(
                                      fontSize: 15.sp,
                                      color: Theme.of(context).colorScheme.onSecondary,
                                      fontWeight: FontWeight.w700),
                                ),
                                trailing: Icon(
                                  Icons.arrow_forward_ios,
                                  size: 15,
                                  color: Theme.of(context).colorScheme.onSecondary,
                                ),
                                onTap: () {
                                  var lngCtrl = Get.find<LangController>();
                                  lngCtrl.languageList(
                                    data: ListView.builder(
                                      shrinkWrap: true,
                                      itemCount: LanguageList().langList.length,
                                      itemBuilder: (context, index) {
                                        var langlist = LanguageList().langList;
                                        return ListTile(
                                          leading: Icon(
                                            Icons.language,
                                            color: Theme.of(context)
                                                .colorScheme
                                                .primary,
                                          ),
                                          title: Text(
                                              "${langlist[index]['langName']}",
                                              style: TextStyle(
                                                fontSize: 15.sp,
                                              ),
                                              ),
                                          onTap: () {
                                            lngCtrl.changeLanguage(
                                                languageId: langlist[index]
                                                    ['langCode']);
                                            Get.back();
                                          },
                                        );
                                      },
                                    ),
                                  );
                                },
                              ),
                            ),
                            Container(
                              decoration: BoxDecoration(color: Theme.of(context).colorScheme.onPrimary),
                              child: ListTile(
                                onTap: () {
                                  var helper = Get.find<Helper>();
                                  helper.appDialogBox(
                                      message:
                                          "You are going to leave the app".tr,
                                      title: "Confirm logout".tr,
                                    onTap: (){
                                      LoginRepo().logout();
                                    }
                                  );
                                },
                                leading: Icon(
                                  Icons.logout,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                                minTileHeight: 60,
                                minVerticalPadding: 0,
                                contentPadding:
                                    EdgeInsets.fromLTRB(20, 0, 20, 0),
                                title: Text("Logout".tr,
                                    style: TextStyle(
                                        fontSize: 15.sp,
                                          color: Theme.of(context).colorScheme.onSecondary,
                                        fontWeight: FontWeight.w700)),
                                trailing: Icon(
                                  Icons.arrow_forward_ios,
                                  size: 15.sp,
                                  color: Theme.of(context).colorScheme.onSecondary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget iconView({icon}){
    return Icon(icon, color: Theme.of(context).colorScheme.primary,);
  }

  Widget rowTIle({ontap, icon, tabName}){
    return Container(
                              decoration: BoxDecoration(color: Colors.white),
                              child: ListTile(
                                onTap: ontap,
                                leading: icon,
                                minTileHeight: 60,
                                minVerticalPadding: 0,
                                contentPadding:
                                    EdgeInsets.fromLTRB(20, 0, 20, 0),
                                title: Text(
                                  "$tabName".tr,
                                  style: TextStyle(
                                      fontSize: 15.sp,
                                      color: Colors.black54,
                                      fontWeight: FontWeight.w700),
                                ),
                                trailing: Icon(
                                  Icons.arrow_forward_ios,
                                  size: 15.sp,
                                ),
                              ),
                            );
  }
}
