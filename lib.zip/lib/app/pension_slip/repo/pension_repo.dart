import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sidbi_app/components/pdf_view.dart';
import 'package:sidbi_app/network/app_config.dart';

import '../../../components/helper.dart';
import '../../../entities/pension_entity/pension_entity.dart';
import '../model/pension_data.dart';
import 'package:http/http.dart' as http;

class PensionRepo extends PensionEntity {
  @override
  getPensionDetail(PensionSlipData pensData) async {
    var datas = {
      "userId": pensData.userId,
      "year": pensData.year,
      "optionList": pensData.listOption,
      "month": pensData.month.toString().toLowerCase()
    };
    print(datas);
    var res = await Helper().postService(data: datas, url: "downloadPdf");
    try {
      if (res != null && res.statusCode == 200) {
        final Directory? appDir = Platform.isAndroid
            ? await getExternalStorageDirectory()
            : await getApplicationDocumentsDirectory();
        var dir = await getExternalStorageDirectory();
        var direct = dir?.path
            .toString()
            .replaceAll("Android/data/com.example.sidbi_app/files", "Download");
        final String fileName =
            "${pensData.userId}_${pensData.listOption}_${pensData.month}_${pensData.year}.pdf";
        File file = new File('$direct/$fileName');

        if (await file.exists()) {
          await file.create();
        }
        var list = await res.bodyBytes;
        // Uint8List bytes = await Uint8List.fromList(list);
        print(list);
        await file.writeAsBytes(list);
        return file;
      } else {
        return res;
      }
    } catch (e) {
      return res;
    }
  }

  getPensionDetails(PensionSlipData pensData) async {
    try{
      var token = await Helper().getSharedPrefString(keyName: "token");
    var userid = await Helper().getSharedPrefString(keyName: 'userid');
    var url = userid == "EEFC99"?"adminDownloadPensionPdfMobile/${userid}":"downloadPDF";
    var headers = {
      'Authorization':'Bearer $token',
      'Content-Type': 'application/json'
    };
    // Uri.parse(""
    // var request = http.Request('POST',
    //     Uri.parse('http://172.30.1.235:8080/newretireeportal/downloadPDF'));
    print("${config?[baseUrl]}$url");
    var request = http.Request('POST',
        Uri.parse('${config?[baseUrl]}$url'));
    request.body = json.encode({
      "userId": pensData.userId,
      "year": pensData.year,
      "optionList": pensData.listOption,
      "month": pensData.month.toString().toLowerCase()
    });

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
    var res = await http.Response.fromStream(response);

    if (res.statusCode == 200) {
      final Directory? appDir = Platform.isAndroid
            ? await getExternalStorageDirectory()
            : await getApplicationDocumentsDirectory();
        // var dir = await getExternalStorageDirectory();
        // var direct = dir?.path
          // .toString()
          // .replaceAll("Android/data/com.sidbi.retireesidbiportal/files", "Download");
        if(appDir == null){
          print("Directory is not avilable");
          return null;
        }
        final String direct = Platform.isAndroid
            ?appDir.path.toString()
          .replaceAll("Android/data/com.sidbi.retireesidbiportal/files", "Download"):appDir.path;
        final String fileName =
            "${pensData.userId}_${pensData.listOption}_${pensData.month}_${pensData.year}.pdf";
        File file = new File('$direct/$fileName');

        if (await file.exists()) {
          await file.create();
        }
        var list = await res.bodyBytes;
        // Uint8List bytes = await Uint8List.fromList(list);
        print(list);
        await file.writeAsBytes(list);
        return file;
    } else {
      print(res.reasonPhrase);
    }
    }catch(e){
      Get.back();
      Helper().messageAlert(title: "Error", message: "$e", type: AlertBoxType.Error);
    }
  }
}
