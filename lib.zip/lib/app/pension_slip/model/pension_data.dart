class PensionSlipData {
  String? userId;
  String? year;
  String? listOption;
  String? month;

  PensionSlipData({
    this.userId,
    this.year,
    this.listOption,
    this.month,
  });

  PensionSlipData copyWith({
    String? userId,
    String? year,
    String? listOption,
    String? month,
  }) =>
      PensionSlipData(
        userId: userId ?? this.userId,
        year: year ?? this.year,
        listOption: listOption ?? this.listOption,
        month: month ?? this.month,
      );
}
