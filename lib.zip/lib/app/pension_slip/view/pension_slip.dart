import "package:flutter/material.dart";
import "package:get/get.dart";
import "package:sidbi_app/app/pension_slip/controller/pensionsl_controller.dart";
import "package:sidbi_app/components/input_field.dart";

import "../../../components/date_input.dart";
import "../../../components/text_area.dart";
import "../../login/repos/static_datas.dart";

class PensionSlip extends StatefulWidget {
  const PensionSlip({super.key});

  @override
  State<PensionSlip> createState() => _PensionSlipState();
}

class _PensionSlipState extends State<PensionSlip> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        title: Text(
          "PENSION SLIP/FORM 16".tr,
        ),
      ),
      body: SingleChildScrollView(
        // padding: EdgeInsets.only(top: 20),
        child: Column(
          children: [
            GetX(
                init: PayController(),
                builder: (ctrl) {
                  return ctrl.userids =="EEFC99"?Container():Container(
                    width: MediaQuery.of(context).size.width,
                    // height: 200,
                    padding: EdgeInsets.fromLTRB(15, 10, 15, 20),
                    decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.inversePrimary),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Flexible(
                              child: Text(
                                "Hello ${ctrl.name.value}",
                                style: Theme.of(context).textTheme.titleLarge,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          "DOB : ${ctrl.dobDet.value}",
                          style: Theme.of(context).textTheme.titleSmall,
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          "Address : ${ctrl.addr.value}",
                          style: Theme.of(context).textTheme.titleSmall,
                        ),
                      ],
                    ),
                  );
                },
              ),
            Container(
              padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
              decoration:
                  BoxDecoration(color: Theme.of(context).colorScheme.onPrimary),
              child: GetX(
                init: PayController(),
                builder: (ctrl) {
                  return Column(
                    children: [
                      Container(
                        child: ListTile(
                          contentPadding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                          title: Text(
                            "${ctrl.pensionViewString.value}",
                            style: Theme.of(context).textTheme.bodyLarge,
                          ),
                          subtitle: Text(
                            "${ctrl.pensionDropSelected.value}",
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                          trailing: CircleAvatar(
                            backgroundColor: Theme.of(context)
                                .colorScheme
                                .primary
                                .withOpacity(0.2),
                            child: IconButton(
                              onPressed: () {
                                ctrl.showEstimatePicker(context);
                              },
                              icon: Icon(
                                Icons.chevron_right_rounded,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                            ),
                          ),
                        ),
                      ),
                      ctrl.pensionDropSelected == "Form 16"
                          ? Container()
                          : Container(
                              child: ListTile(
                                contentPadding:
                                    EdgeInsets.fromLTRB(15, 0, 15, 0),
                                title: Text(
                                  "${ctrl.monthViewString.value}",
                                  style: Theme.of(context).textTheme.bodyLarge,
                                ),
                                subtitle: Text(
                                  "${ctrl.monthDropSelected.value}",
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                                trailing: CircleAvatar(
                                  backgroundColor: Theme.of(context)
                                      .colorScheme
                                      .primary
                                      .withOpacity(0.2),
                                  child: IconButton(
                                    onPressed: () {
                                      ctrl.showMonthPicker(context);
                                    },
                                    icon: Icon(
                                      Icons.chevron_right_rounded,
                                      color:
                                          Theme.of(context).colorScheme.primary,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                      Container(
                        child: ListTile(
                          onTap: () {
                            ctrl.showYearPicker();
                          },
                          contentPadding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                          title: Text(
                            "${ctrl.yearViewString.value}",
                            style: Theme.of(context).textTheme.bodyLarge,
                          ),
                          subtitle: Text(
                            "${ctrl.yearDropSelected.value}",
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                          trailing: CircleAvatar(
                            backgroundColor: Theme.of(context)
                                .colorScheme
                                .primary
                                .withOpacity(0.2),
                            child: IconButton(
                              onPressed: () {
                                ctrl.showYearPicker();
                              },
                              icon: Icon(
                                Icons.chevron_right_rounded,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 6,
                      ),
                      Container(
                        height: 70,
                        padding: EdgeInsets.fromLTRB(0, 15, 15, 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(
                              width: MediaQuery.of(context).size.width / 2.5,
                              child: Material(
                                color: Theme.of(context).colorScheme.primary,
                                borderRadius: BorderRadius.circular(300),
                                child: InkWell(
                                  onTap: () {
                                    var ctrl = Get.find<PayController>();
                                    ctrl.getDetail();
                                  },
                                  child: Center(
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        // SizedBox(
                                        //   width: 10,
                                        // ),
                                        Expanded(
                                          child: Text(
                                            textAlign: TextAlign.center,
                                            "Get Detail",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w600,
                                                fontSize: 15),
                                          ),
                                        ),
                                        // SizedBox(
                                        //   width: 10,
                                        // ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  );
                },
              ),
            )
          ],
        ),
      ),
      // bottomNavigationBar: Container(
      //   height: 80,
      //   decoration: BoxDecoration(color: Colors.white),
      //   child: Container(
      //     padding: EdgeInsets.fromLTRB(10, 15, 15, 10),
      //     child: Row(
      //       mainAxisAlignment: MainAxisAlignment.end,
      //       children: [
      //         SizedBox(
      //           width: MediaQuery.of(context).size.width / 2.5,
      //           child: Material(
      //             color: Theme.of(context).colorScheme.primary,
      //             borderRadius: BorderRadius.circular(300),
      //             child: InkWell(
      //               onTap: () {
      //                 var ctrl = Get.find<PayController>();
      //                 ctrl.getDetail();
      //               },
      //               child: Center(
      //                 child: Row(
      //                   mainAxisAlignment: MainAxisAlignment.center,
      //                   children: [
      //                     SizedBox(
      //                       width: 10,
      //                     ),
      //                     Expanded(
      //                       child: Text(
      //                         textAlign: TextAlign.center,
      //                         "Get Detail",
      //                         style: TextStyle(
      //                             color: Colors.white,
      //                             fontWeight: FontWeight.w600,
      //                             fontSize: 15),
      //                       ),
      //                     ),
      //                     CircleAvatar(
      //                       backgroundColor: Colors.white.withOpacity(0.5),
      //                       child: Icon(
      //                         Icons.chevron_right,
      //                         color: Colors.black,
      //                       ),
      //                     ),
      //                     SizedBox(
      //                       width: 10,
      //                     ),
      //                   ],
      //                 ),
      //               ),
      //             ),
      //           ),
      //         ),
      //       ],
      //     ),
      //   ),
      // ),
    );
  }
}
