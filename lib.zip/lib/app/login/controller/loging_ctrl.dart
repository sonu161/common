import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sidbi_app/admin/admin_home/view/admin_home_view.dart';
import 'package:sidbi_app/app/login/model/user_data.dart';
import 'package:sidbi_app/app/otp/view/otp_view.dart';
import 'package:sidbi_app/components/comp_controllers/loading_controller.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/entities/user_entity/user_entity.dart';

import '../repos/login_repo.dart';
import '../views/captcha_view.dart';


enum AppLoadingState { Loading, Loaded, Initial, Error, Blank }

enum RefreshState { Loading, Loaded, Initial, Error }

class LogingCtrl extends GetxController {
  var appLoadingState = AppLoadingState.Initial.obs;
  var refreshingState = RefreshState.Initial.obs;
  var emailCtrl = TextEditingController().obs;
  var passwordCtrl = TextEditingController().obs;
  var captcha = TextEditingController().obs;
  var userCaptchaInput = TextEditingController().obs; //SHA64 encrypt
  var passView = true.obs;
  var formFocused = false.obs;
  var formFocusedHide = true.obs;
  var emailCheck = false.obs;
  var passCheck = false.obs;
  Helper helper = new Helper();
  LoginRepo loginrepo = new LoginRepo();
  var captchaImage = "".obs;
  var captchValue = "".obs;
  var loadingCtrl = Get.find<LoadingController>();

  getCaptcha() async {
    try {
      appLoadingState.value = AppLoadingState.Loading;
      var resData = await loginrepo.getCaptcha();
      if (resData.statusCode == 200) {
        var jsonData = jsonDecode(resData.body);
        captchaImage.value = jsonData['captcha'];
        captchValue.value = jsonData['text'];
        print(captchValue.value);
        // captchaSheet();
        appLoadingState.value = AppLoadingState.Loaded;
      } else if (resData.statusCode == 404) {
        Get.snackbar("Network Error",
            "System is under maintenance, Please tyr after some time",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.FLOATING,
            backgroundColor: Colors.white,
            duration: Duration(seconds: 20));
        appLoadingState.value = AppLoadingState.Error;
        // captchaSheet();
      } else {
        Get.snackbar("Network Error", "${resData.body}",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.FLOATING,
            backgroundColor: Colors.white);
        appLoadingState.value = AppLoadingState.Error;
        // captchaSheet();
      }
    } catch (e) {
      // Get.snackbar("Login Error",
      //     "Network is not reachable, please try after some time.".tr,
      //     colorText: Colors.red,
      //     snackPosition: SnackPosition.BOTTOM,
      //     snackStyle: SnackStyle.FLOATING,
      //     backgroundColor: Colors.white,
      //     margin: EdgeInsets.only(bottom: 10, left: 10, right: 10),
      //     duration: Duration(seconds: 40));
      // // captchaSheet();
      helper.messageAlert(title: "Login Error", message: "Network is not reachable, please try after some time.".tr, type: AlertBoxType.Error);
    }
  }

  changeTONoneSecureText() {
    if (passView.value == true) {
      passView.value = false;
    } else {
      passView.value = true;
    }
  }

  onFocusChangeForm() {
    if (formFocused.value == true) {
      formFocused.value = false;
    } else {
      formFocused.value = true;
      formFocusedHide.value = false;
    }
    print("called");
  }

  checkForFocus() {
    formFocusedHide.value = false;
  }

  validate() {
    // Get.to(HomePage());
    if (emailCtrl.value.text == "" && passwordCtrl.value.text == "") {
      emailCheck.value = true;
      passCheck.value = true;
    } else if (emailCtrl.value.text != "" && passwordCtrl.value.text == "") {
      passCheck.value = true;
      emailCheck.value = false;
    } else if (emailCtrl.value.text == "" && passwordCtrl.value.text != "") {
      emailCheck.value = true;
      passCheck.value = false;
    } else {
      emailCheck.value = false;
      passCheck.value = false;
      ;
      verifyLogin();
    }
  }

  captchaSheet() {
    Get.bottomSheet(
      backgroundColor: Colors.white,
      enableDrag: true,
      isScrollControlled: false,
      SizedBox(
        height: 300,
        child: CaptchaView(
          ontap: () {
            verifyLogin();
          },
          capTchaText: userCaptchaInput.value,
          imageBase64: captchaImage.value,
          refresh: () {
            refreshCaptcha();
          },
        ),
      ),
    );
  }

  refreshCaptcha() async {
    try {
      loadingCtrl.refreshingState.value = RefreshState.Loading;
      var resData = await loginrepo.getCaptcha();
      if (resData.statusCode == 200) {
        var jsonData = jsonDecode(resData.body);
        captchaImage.value = jsonData['captcha'];
        captchValue.value = jsonData['text'];
        loadingCtrl.refreshingState.value = RefreshState.Loaded;
      } else {
        Get.snackbar("Network Error", "${resData.body}",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.GROUNDED);
        loadingCtrl.refreshingState.value = RefreshState.Error;
        ;
      }
      print(loadingCtrl.refreshingState.value);
    } catch (e) {
      print(e);
    }
  }

  verifyLogin() async {
    helper.fullAppLoading();
    try {
      if (captcha.value.text == captchValue.value) {
        login();
      } else {
        Get.back();
               helper.messageAlert(
            title: "Captcha Error",
            message: "Captcha is matching",
            type: AlertBoxType.Error);
        userCaptchaInput.value.clear();
        refreshCaptcha();
      }
    } on Exception catch (e) {}
  }

  login() async {
    // loadingCtrl.refreshingState.value = RefreshState.Loading;
    var pass = helper.shaConverter(newString: passwordCtrl.value.text);
    print(pass);
    try {
      if (captcha.value.text == captchValue.value) {
        UserData data = UserData(
            userId: emailCtrl.value.text,
            password: "12345${pass}12345",
            orgCaptcha: captcha.value.text,
            captcha: captchValue.value,
            errorMsg: "");
        print("${data.orgCaptcha} ${data.captcha}");
        var resData = await loginrepo.userLogin(data);
        print(resData.body);
        if (resData.statusCode == 200) {
          print(json.decode(resData.body)['errorMsg']);
          var decodeData = json.decode(resData.body);

          print("message ${decodeData['token']}");
          if (decodeData['responseCode'] == "P") {
            print(decodeData['emailId']);
            var sp = await SharedPreferences.getInstance();
            sp.clear();
            helper.setSharedPrefString(
                keyName: "emailId", value: decodeData['emailId']);
            helper.setSharedPrefString(
                keyName: "fullName", value: decodeData['fullName']);
            helper.setSharedPrefString(
                keyName: "empGrade", value: decodeData['empGrade']);
            helper.setSharedPrefString(
                keyName: "salaryCode", value: decodeData['salaryCode']);
            helper.setSharedPrefString(
                keyName: "empDOB", value: decodeData['empDOB']);
            helper.setSharedPrefString(
                keyName: "empAddress", value: decodeData['empAddress'].toString().replaceAll("null", ""));
            helper.setSharedPrefString(
                keyName: "token", value: decodeData['token']);
            helper.setSharedPrefString(
                keyName: "userid", value: decodeData['userId']);
            loadingCtrl.refreshingState.value = RefreshState.Loaded;
            if (decodeData['userId'] == "EEFC99") {
              Get.offAll(() => AdminHomeView());
            } else {
              Get.back();
              Get.to(() => OtpPage(), arguments: emailCtrl.value.text);
            }
          } else if(decodeData['responseCode'] == "A"){
            var userid = emailCtrl.value.text;
            await helper.setSharedPrefString(keyName: "userid",value: userid);
            await helper.setSharedPrefString(
                keyName: "token", value: decodeData['token']);
            Get.offAll(AdminHomeView());
          }
          else {
            Get.back();
            helper.messageAlert(
                title: "Login Error",
                message: "${json.decode(resData.body)['message']}",
                type: AlertBoxType.Error);
            loadingCtrl.refreshingState.value = RefreshState.Error;
          }
        } else {
          loadingCtrl.refreshingState.value = RefreshState.Error;
          helper.messageAlert(title: "Network Timeout", message: "Please check your network or try after some time", type: AlertBoxType.Error);
        }
      } else {
        helper.messageAlert(
            title: "Captcha Error",
            message: "Captcha is matching",
            type: AlertBoxType.Error);
      }
    } catch (e) {
      print(e);
      loadingCtrl.refreshingState.value = RefreshState.Loaded;
    }
  }

  @override
  void onInit() {
    super.onInit();
    getCaptcha();
  }

  @override
  void dispose() {
    super.dispose();
  }
}
