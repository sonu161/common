import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/app/login/model/user_data.dart';
import 'package:sidbi_app/app/login/views/login_page.dart';
import 'package:sidbi_app/app/user/model/ProfileData.dart';
import 'package:sidbi_app/components/helper.dart';

import '../../../entities/user_entity/user_entity.dart';
import 'package:http/http.dart' as http;

import '../../../network/app_config.dart';

class LoginRepo extends UserEntity{
  Helper helper = new Helper();
  @override
  getCaptcha() async{
    print("${config?[baseUrl]}captcha");
    try{
      var res = await helper.getService("cph/captcha",tokenRequired: false);
      return res;
    }catch(e){

    }
  }

  @override
  userLogin(UserData data) async{
    try{
      var body = {
        "userId": data.userId,
        "password": data.password,
        "captcha": data.captcha,
        "errorMsg": data.errorMsg,
        "orgCaptcha": data.orgCaptcha
      };
      print(body);
      var res = await helper.postService(url: "auth/loginHome",data: body,tokenRequired: false);
      return res;
    }
    catch(e){
    }
  }

  @override
  reSendOtp(String userid) async{
    try{
      var body = {
        "userId": "$userid",
      };
      var res = await helper.postService(url: "resendOTP",data: body);
      return res;
    }catch(e){

    }
  }

  @override
  verfiyOtp(String otp, String userid) async{
    try{
      var body = {
        "userId": "$userid",
        "otp": "$otp"
      };
      print(body);
      var res = await helper.postService(url: "auth/verifyOTP" , data: body);
      return res;
    }catch(e){

    }
  }

  @override
  forgotPassord(
      {String? userid, String? email, String? captcha, String? orgCaptcha}) async{
    try{
      var body = {
        "userId": "$userid",
        "emailId": "$email",
        "captcha": "$captcha",
        "errorMsg": "",
        "orgCaptcha": "$orgCaptcha"
      };
      var res = await helper.postService(url: "forgetPasswordSubmission",data: body,tokenRequired: false);
      return res;
    }catch(e){

    }
  }

  @override
  updatePassword({String? userid,String? newPassword, String? confirmPassword, String? otp, String? captcha, String? orgCaptcha}) async{
    try{
      var body = {
        "userId":"$userid",
        "password": "$newPassword",
        "confirmPass": "$confirmPassword",
        "otp":"$otp",
        "captcha":"$captcha",
        "orgCaptcha":"$orgCaptcha"
      };
      print(body);
      var res = await helper.postService(url: "updatePasswordSubmission",data: body,tokenRequired: false);
      return res;
    }catch(e){

    }
  }

  @override
  getUserDetail() async {
    try{
      var userid = await helper.getSharedPrefString(keyName: "userid");
      var res = await helper.getService("editProfile/$userid");
      return res;
    }catch(e){

    }
  }

  @override
  updateUserDetail(ProfileData proPayload) async{
    try{
      var res = await helper.postService(
        data: proPayload.toJson(),
        url: "editProfileSave"
      );
      return res;
    }catch(e){

    }
  }

  @override
  logout() async {
    await helper.clearSharedPrefs();
    Get.offAll(()=>LoginPage());
  }

}