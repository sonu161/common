class StaticDatas{
  List<Map<String, String>> pension_sslips = [
    {
      "name":"Form 16",
      "val":"FRM"
    },
    {
      "name":"Pension Slip",
      "val":"SAL"
    },
    {
      "name":"Estimate",
      "val":"EST"
    },
  ];

  List<Map<String, String>> month = [
    {
      "name":"January",
      "val":"JAN"
    },
    {
      "name":"February",
      "val":"FEB"
    },
    {
      "name":"March",
      "val":"MAR"
    },
    {
      "name":"April",
      "val":"APR"
    },
    {
      "name":"May",
      "val":"MAY"
    },
    {
      "name":"June",
      "val":"Jun"
    },
    {
      "name":"July",
      "val":"JUL"
    },
    {
      "name":"August",
      "val":"AUG"
    },
    {
      "name":"September",
      "val":"SEP"
    },
    {
      "name":"October",
      "val":"OCT"
    },
    {
      "name":"November",
      "val":"NOV"
    },
    {
      "name":"December",
      "val":"DEC"
    },
  ];

  List<Map<String, String>> hospitalLocaType = [
    {
      "name":"GOV/CGHS/CBDT",
      "val":"Y"
    },
    {
      "name":"NCBDT",
      "val":"N"
    }
  ];

  List<Map<String,String>> hospitalLocation=[
    {
      "name":"Metro",
      "val":"M"
    },
    {
      "name":"Non-Metro",
      "val":"N"
    }
  ];

  List<Map<String, String>> relationType = [
    {
      "name":"Spouse",
      "val":"S"
    },
    {
      "name":"Self",
      "val":"E"
    },
  ];
  List<Map<String, String>> claimType = [
    {
      "name":"CHC",
      "val":"1"
    },
    // {
    //   "name":"OPD",
    //   "val":"2"
    // },
  ];
  List<Map<String, String>> purpose = [
    {
      "name":"Personal",
      "val":"E"
    },
    {
      "name":"Attending CBI/Court Cases",
      "val":"S"
    },
  ];
  List<Map<String, String>> selfDepType = [
    {
      "name":"Self",
      "val":"E"
    },
    {
      "name":"Spouse",
      "val":"S"
    },
  ];
}