import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/comp_controllers/loading_controller.dart';
import 'package:sidbi_app/components/input_field.dart';
import 'package:sidbi_app/components/main_button.dart';

import '../../../components/light_button.dart';

class CaptchaView extends StatelessWidget {
  const CaptchaView({super.key, this.imageBase64 ,this.ontap, this.capTchaText, this.refresh, this.refresing});
  final Function()? ontap;
  final Function()? refresh;
  final TextEditingController? capTchaText;
  final String? imageBase64;
  final RefreshState? refresing;
  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvoked: (val){
        this.capTchaText!.clear();
      },
      child:  Container(
        margin: EdgeInsets.fromLTRB(15, 20, 15, 20),
        child: GetX(
          init: LoadingController(),
          builder: (ctrl) {
            return Column(
              children: [
                SizedBox(
                  height: 20,
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                          padding: EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                          ),
                          child: GetX(
                            init: LogingCtrl(),
                            builder: (ctrl){
                              return Image(
                                height: 50,
                                image: MemoryImage(
                                    base64Decode(ctrl.captchaImage.value)),
                              );
                            },
                          )
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  child: InputField(
                    textEditingController:this.capTchaText,
                    hint: "Enter Captcha",
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      LightButton(
                        buttonLable: "Cancel",
                        onTap: () {
                          Get.back();
                        },
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          ctrl.refreshingState.value == RefreshState.Loading
                              ? Row(
                            children: [
                              SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(),
                              ),
                              SizedBox(
                                width: 20,
                              )
                            ],
                          )
                              : IconButton(
                              onPressed: this.refresh,
                              icon: Icon(
                                Icons.refresh,
                                color: Theme.of(context).colorScheme.primary,
                              )),
                          MainButton(
                            buttonLable: "Verify Login",
                            // onTap: () {
                            //   // Get.to(OtpPage());
                            //   var ctf = Get.find<LogingCtrl>();
                            //   ctf.verifyLogin();
                            // },
                            onTap: this.ontap,
                          ),
                        ],
                      ),
                    ],
                  ),
                )
              ],
            );
          },
        ),
      ),
    );
  }
}
