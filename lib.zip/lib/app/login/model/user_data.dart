// To parse this JSON data, do
//
//     final userData = userDataFromJson(jsonString);

import 'dart:convert';

UserData userDataFromJson(String str) => UserData.fromJson(json.decode(str));

String userDataToJson(UserData data) => json.encode(data.toJson());

class UserData {
  String? userId;
  String? password;
  String? captcha;
  String? errorMsg;
  String? orgCaptcha;

  UserData({
    this.userId,
    this.password,
    this.captcha,
    this.errorMsg,
    this.orgCaptcha,
  });

  UserData copyWith({
    String? userId,
    String? password,
    String? captcha,
    String? errorMsg,
    String? orgCaptcha,
  }) =>
      UserData(
        userId: userId ?? this.userId,
        password: password ?? this.password,
        captcha: captcha ?? this.captcha,
        errorMsg: errorMsg ?? this.errorMsg,
        orgCaptcha: orgCaptcha ?? this.orgCaptcha,
      );

  factory UserData.fromJson(Map<String, dynamic> json) => UserData(
    userId: json["userId"],
    password: json["password"],
    captcha: json["captcha"],
    errorMsg: json["errorMsg"],
    orgCaptcha: json["orgCaptcha"],
  );

  Map<String, dynamic> toJson() => {
    "userId": userId,
    "password": password,
    "captcha": captcha,
    "errorMsg": errorMsg,
    "orgCaptcha": orgCaptcha,
  };
}
