import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:sidbi_app/app/hospitalization_request/model/AccFormData.dart';

import '../../components/helper.dart';
import '../../entities/indoor_hosp_entity/indoor_hosp_entity.dart';
import 'package:http/http.dart' as http;

class IndoorHospRepo extends IndoorHospEntity {
  Helper helper = new Helper();

  @override
  getIndoorHosp() async {
    try {
      var userid = await helper.getSharedPrefString(keyName: "userid");
      var url = "indoorHospForm/$userid";
      var userFor = await helper.getSharedPrefString(keyName: "userFor");
      bool? userToken;
      if (userFor != null) {
        var logUserid = await helper.getSharedPrefString(keyName: "userid");
        url = "adminIndHospHisList/$logUserid/$userFor";
        userToken = false;
      }
      var res = await helper.getService(url);
      print(res);
      return res;
    } catch (e) {
      print(e);
    }
  }

  @override
  viewDetailOfAccomodation(String formId) async {
    // 2300003906
    var userid = await helper.getSharedPrefString(keyName: "userid");
    var res = await helper.getService("accommodationDetails/$userid/$formId");
    return res;
  }

  @override
  submitAccForm({required AccFormData datas, String? files}) async {
    print(datas.toJson());
    var res = await helper.postNew(url: "indoorHospFormSave",data: datas.toJson(),path: files);
    // print("Status Code : ${res.statusCode}");
    print(res);
    return res;

    // try {
    //   var token = await helper.getSharedPrefString(keyName: "token");
    //   print("Bearer $token");
    //   var headers = {'Authorization': "Bearer $token"};
    //   var request = http.MultipartRequest(
    //       'POST',
    //       Uri.parse(
    //           'https://retireeportal-uat.sidbi.in/newretireeportal/indoorHospFormSave'));
    //   request.fields.addAll({
    //     'empName': 'Farukh',
    //     'userId': '000003',
    //     'userEmail': 'nisg_sachins@sidbi.in',
    //     'empRelation': 'S',
    //     'patientName': 'Farukh',
    //     'cityName': 'London',
    //     'hospitalName': 'Sindhya Hospital',
    //     'hospitalizedDate': '2022-10-09',
    //     'hospitalLocation': 'N',
    //     'hospitalType': 'Y',
    //     'comment': 'Test',
    //     'billNo': '12312323',
    //     'billDate': '2022-10-10',
    //     'billAmt': '456000',
    //     'amtPaidByEmp': '12300',
    //     'applicationUsed': 'W'
    //   });
    //   request.files.add(await http.MultipartFile.fromPath('file', files!));
    //   request.headers.addAll(headers);

    //   http.StreamedResponse response = await request.send();

    //   if (response.statusCode == 200) {
    //     // print(await response.stream.bytesToString());
    //     var data = await response;
    //     return data;
    //   } else {
    //     print("TEST ERROR : ${response.reasonPhrase}");
    //   }
    // } catch (e) {}
  }
}
