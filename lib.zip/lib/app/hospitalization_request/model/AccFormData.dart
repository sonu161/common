class AccFormData {
  AccFormData({
      this.userId, 
      this.userEmail,
      this.empName, 
      this.empRelation, 
      this.patientName, 
      this.cityName, 
      this.hospitalName,
      this.hospitalizedDate, 
      this.hospitalLocation,
      this.hospitalType, 
      this.comment, 
      this.billNo, 
      this.billDate, 
      this.billAmt, 
      this.amtPaidByEmp,
      this.applicationUsed});

  AccFormData.fromJson(dynamic json) {
    userId = json['userId'];
    userEmail = json['userEmail'];
    empName = json['empName'];
    empRelation = json['empRelation'];
    patientName = json['patientName'];
    cityName = json['cityName'];
    hospitalName = json['hospitalName'];
    hospitalizedDate = json['hospitalizedDate'];
    hospitalLocation = json['hospitalLocation'];
    hospitalType = json['hospitalType'];
    comment = json['comment'];
    billNo = json['billNo'];
    billDate = json['billDate'];
    billAmt = json['billAmt'];
    amtPaidByEmp = json['amtPaidByEmp'];
    applicationUsed = json['applicationUsed:W'];
  }
  String? userId;
  String? userEmail;
  String? empName;
  String? empRelation;
  String? patientName;
  String? cityName;
  String? hospitalName;
  String? hospitalizedDate;
  String? hospitalLocation;
  String? hospitalType;
  String? comment;
  String? billNo;
  String? billDate;
  String? billAmt;
  String? amtPaidByEmp;
  String?applicationUsed;
AccFormData copyWith({  String? userId,
  String? userEmail,
  String? empName,
  String? empRelation,
  String? patientName,
  String? cityName,
  String? hospitalName,
  String? hospitalizedDate,
  String? hospitalLocation,
  String? hospitalType,
  String? comment,
  String? billNo,
  String? billDate,
  String? billAmt,
  String? amtPaidByEmp,
  String?applicationUsed
}) => AccFormData(  userId: userId ?? this.userId,
  userEmail: userEmail ?? this.userEmail,
  empName: empName ?? this.empName,
  empRelation: empRelation ?? this.empRelation,
  patientName: patientName ?? this.patientName,
  cityName: cityName ?? this.cityName,
  hospitalName: hospitalName ?? this.hospitalName,
  hospitalizedDate: hospitalizedDate ?? this.hospitalizedDate,
  hospitalLocation: hospitalLocation ?? this.hospitalLocation,
  hospitalType: hospitalType ?? this.hospitalType,
  comment: comment ?? this.comment,
  billNo: billNo ?? this.billNo,
  billDate: billDate ?? this.billDate,
  billAmt: billAmt ?? this.billAmt,
  amtPaidByEmp: amtPaidByEmp ?? this.amtPaidByEmp,
  applicationUsed:applicationUsed ?? this.applicationUsed
);
  Map<String, String> toJson() {
    final map = <String, String>{};
    map['userId'] = userId!;
    map['userEmail'] = userEmail!;
    map['empName'] = empName!;
    map['empRelation'] = empRelation!;
    map['patientName'] = patientName!;
    map['cityName'] = cityName!;
    map['hospitalName'] = hospitalName!;
    map['hospitalizedDate'] = hospitalizedDate!;
    map['hospitalLocation'] = hospitalLocation!;
    map['hospitalType'] = hospitalType!;
    map['comment'] = comment!;
    map['billNo'] = billNo!;
    map['billDate'] = billDate!;
    map['billAmt'] = billAmt!;
    map['amtPaidByEmp'] = amtPaidByEmp!;
    map['applicationUsed'] = applicationUsed!;
    return map;
  }

}