class AccomodationDetailData {
  AccomodationDetailData({
      this.userId, 
      this.emailId, 
      this.empName, 
      this.empRelation, 
      this.patientName, 
      this.cityName, 
      this.hospitalName, 
      this.reqType, 
      this.hospitalizedDate, 
      this.hospitalLocationType, 
      this.hospitalType, 
      this.comment, 
      this.billNo, 
      this.billDate, 
      this.billAmt, 
      this.amtPaidByEmp, 
      this.file, 
      this.bookingList, 
      this.accommodationDtlList, 
      this.requestDtlSaved, 
      this.billDtlSaved, 
      this.emailErrDtlSaved, 
      this.loginLogSaved, 
      this.applicationUsed, 
      this.errorMsg, 
      this.successMsg, 
      this.httpStatus,});

  AccomodationDetailData.fromJson(dynamic json) {
    userId = json['userId'];
    emailId = json['emailId'];
    empName = json['empName'];
    empRelation = json['empRelation'];
    patientName = json['patientName'];
    cityName = json['cityName'];
    hospitalName = json['hospitalName'];
    reqType = json['reqType'];
    hospitalizedDate = json['hospitalizedDate'];
    hospitalLocationType = json['hospitalLocationType'];
    hospitalType = json['hospitalType'];
    comment = json['comment'];
    billNo = json['billNo'];
    billDate = json['billDate'];
    billAmt = json['billAmt'];
    amtPaidByEmp = json['amtPaidByEmp'];
    file = json['file'];
    bookingList = json['bookingList'];
    accommodationDtlList = json['accommodationDtlList'];
    requestDtlSaved = json['requestDtlSaved'];
    billDtlSaved = json['billDtlSaved'];
    emailErrDtlSaved = json['emailErrDtlSaved'];
    loginLogSaved = json['loginLogSaved'];
    applicationUsed = json['applicationUsed'];
    errorMsg = json['errorMsg'];
    successMsg = json['successMsg'];
    httpStatus = json['httpStatus'];
  }
  dynamic userId;
  dynamic emailId;
  dynamic empName;
  dynamic empRelation;
  dynamic patientName;
  dynamic cityName;
  dynamic hospitalName;
  dynamic reqType;
  dynamic hospitalizedDate;
  dynamic hospitalLocationType;
  dynamic hospitalType;
  dynamic comment;
  dynamic billNo;
  dynamic billDate;
  dynamic billAmt;
  dynamic amtPaidByEmp;
  dynamic file;
  dynamic bookingList;
  AccommodationDtlList? accommodationDtlList;
  dynamic requestDtlSaved;
  dynamic billDtlSaved;
  dynamic emailErrDtlSaved;
  dynamic loginLogSaved;
  dynamic applicationUsed;
  dynamic errorMsg;
  String? successMsg;
  String? httpStatus;
AccomodationDetailData copyWith({  dynamic userId,
  dynamic emailId,
  dynamic empName,
  dynamic empRelation,
  dynamic patientName,
  dynamic cityName,
  dynamic hospitalName,
  dynamic reqType,
  dynamic hospitalizedDate,
  dynamic hospitalLocationType,
  dynamic hospitalType,
  dynamic comment,
  dynamic billNo,
  dynamic billDate,
  dynamic billAmt,
  dynamic amtPaidByEmp,
  dynamic file,
  dynamic bookingList,
  AccommodationDtlList? accommodationDtlList,
  dynamic requestDtlSaved,
  dynamic billDtlSaved,
  dynamic emailErrDtlSaved,
  dynamic loginLogSaved,
  dynamic applicationUsed,
  dynamic errorMsg,
  String? successMsg,
  String? httpStatus,
}) => AccomodationDetailData(  userId: userId ?? this.userId,
  emailId: emailId ?? this.emailId,
  empName: empName ?? this.empName,
  empRelation: empRelation ?? this.empRelation,
  patientName: patientName ?? this.patientName,
  cityName: cityName ?? this.cityName,
  hospitalName: hospitalName ?? this.hospitalName,
  reqType: reqType ?? this.reqType,
  hospitalizedDate: hospitalizedDate ?? this.hospitalizedDate,
  hospitalLocationType: hospitalLocationType ?? this.hospitalLocationType,
  hospitalType: hospitalType ?? this.hospitalType,
  comment: comment ?? this.comment,
  billNo: billNo ?? this.billNo,
  billDate: billDate ?? this.billDate,
  billAmt: billAmt ?? this.billAmt,
  amtPaidByEmp: amtPaidByEmp ?? this.amtPaidByEmp,
  file: file ?? this.file,
  bookingList: bookingList ?? this.bookingList,
  accommodationDtlList: accommodationDtlList ?? this.accommodationDtlList,
  requestDtlSaved: requestDtlSaved ?? this.requestDtlSaved,
  billDtlSaved: billDtlSaved ?? this.billDtlSaved,
  emailErrDtlSaved: emailErrDtlSaved ?? this.emailErrDtlSaved,
  loginLogSaved: loginLogSaved ?? this.loginLogSaved,
  applicationUsed: applicationUsed ?? this.applicationUsed,
  errorMsg: errorMsg ?? this.errorMsg,
  successMsg: successMsg ?? this.successMsg,
  httpStatus: httpStatus ?? this.httpStatus,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['userId'] = userId;
    map['emailId'] = emailId;
    map['empName'] = empName;
    map['empRelation'] = empRelation;
    map['patientName'] = patientName;
    map['cityName'] = cityName;
    map['hospitalName'] = hospitalName;
    map['reqType'] = reqType;
    map['hospitalizedDate'] = hospitalizedDate;
    map['hospitalLocationType'] = hospitalLocationType;
    map['hospitalType'] = hospitalType;
    map['comment'] = comment;
    map['billNo'] = billNo;
    map['billDate'] = billDate;
    map['billAmt'] = billAmt;
    map['amtPaidByEmp'] = amtPaidByEmp;
    map['file'] = file;
    map['bookingList'] = bookingList;
    map['accommodationDtlList'] = accommodationDtlList;
    map['requestDtlSaved'] = requestDtlSaved;
    map['billDtlSaved'] = billDtlSaved;
    map['emailErrDtlSaved'] = emailErrDtlSaved;
    map['loginLogSaved'] = loginLogSaved;
    map['applicationUsed'] = applicationUsed;
    map['errorMsg'] = errorMsg;
    map['successMsg'] = successMsg;
    map['httpStatus'] = httpStatus;
    return map;
  }

}

class AccommodationDtlList {
  AccommodationDtlList({
      this.paymentDtlList, 
      this.releasePayList, 
      this.settledAmtList, 
      this.applDtlList,});

  AccommodationDtlList.fromJson(dynamic json) {
    if (json['PaymentDtlList'] != null) {
      paymentDtlList = [];
      json['PaymentDtlList'].forEach((v) {
        paymentDtlList?.add(PaymentDtlList.fromJson(v));
      });
    }
    if (json['ReleasePayList'] != null) {
      releasePayList = [];
      json['ReleasePayList'].forEach((v) {
        releasePayList?.add(ReleasePayList.fromJson(v));
      });
    }
    if (json['SettledAmtList'] != null) {
      settledAmtList = [];
      json['SettledAmtList'].forEach((v) {
        settledAmtList?.add(SettledAmtList.fromJson(v));
      });
    }
    if (json['ApplDtlList'] != null) {
      applDtlList = [];
      json['ApplDtlList'].forEach((v) {
        applDtlList?.add(ApplDtlList.fromJson(v));
      });
    }
  }
  List<PaymentDtlList>? paymentDtlList;
  List<ReleasePayList>? releasePayList;
  List<SettledAmtList>? settledAmtList;
  List<ApplDtlList>? applDtlList;
AccommodationDtlList copyWith({  List<PaymentDtlList>? paymentDtlList,
  List<ReleasePayList>? releasePayList,
  List<SettledAmtList>? settledAmtList,
  List<ApplDtlList>? applDtlList,
}) => AccommodationDtlList(  paymentDtlList: paymentDtlList ?? this.paymentDtlList,
  releasePayList: releasePayList ?? this.releasePayList,
  settledAmtList: settledAmtList ?? this.settledAmtList,
  applDtlList: applDtlList ?? this.applDtlList,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (paymentDtlList != null) {
      map['PaymentDtlList'] = paymentDtlList?.map((v) => v.toJson()).toList();
    }
    if (releasePayList != null) {
      map['ReleasePayList'] = releasePayList?.map((v) => v.toJson()).toList();
    }
    if (settledAmtList != null) {
      map['SettledAmtList'] = settledAmtList?.map((v) => v.toJson()).toList();
    }
    if (applDtlList != null) {
      map['ApplDtlList'] = applDtlList?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class ApplDtlList {
  ApplDtlList({
      this.applNo, 
      this.reqtype, 
      this.settledAmt, 
      this.status,});

  ApplDtlList.fromJson(dynamic json) {
    applNo = json['applNo'];
    reqtype = json['reqtype'];
    settledAmt = json['settledAmt'];
    status = json['status'];
  }
  String? applNo;
  String? reqtype;
  String? settledAmt;
  String? status;
ApplDtlList copyWith({  String? applNo,
  String? reqtype,
  String? settledAmt,
  String? status,
}) => ApplDtlList(  applNo: applNo ?? this.applNo,
  reqtype: reqtype ?? this.reqtype,
  settledAmt: settledAmt ?? this.settledAmt,
  status: status ?? this.status,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['applNo'] = applNo;
    map['reqtype'] = reqtype;
    map['settledAmt'] = settledAmt;
    map['status'] = status;
    return map;
  }

}

class SettledAmtList {
  SettledAmtList({
      this.serviceType, 
      this.billAmt, 
      this.eligibleAmt, 
      this.settledAmt,});

  SettledAmtList.fromJson(dynamic json) {
    serviceType = json['serviceType'];
    billAmt = json['billAmt'];
    eligibleAmt = json['eligibleAmt'];
    settledAmt = json['settledAmt'];
  }
  String? serviceType;
  String? billAmt;
  String? eligibleAmt;
  String? settledAmt;
SettledAmtList copyWith({  String? serviceType,
  String? billAmt,
  String? eligibleAmt,
  String? settledAmt,
}) => SettledAmtList(  serviceType: serviceType ?? this.serviceType,
  billAmt: billAmt ?? this.billAmt,
  eligibleAmt: eligibleAmt ?? this.eligibleAmt,
  settledAmt: settledAmt ?? this.settledAmt,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['serviceType'] = serviceType;
    map['billAmt'] = billAmt;
    map['eligibleAmt'] = eligibleAmt;
    map['settledAmt'] = settledAmt;
    return map;
  }

}

class ReleasePayList {
  ReleasePayList({
      this.paymentAppBy, 
      this.partPayAmt, 
      this.partPayTax, 
      this.partPayCess, 
      this.partPaySc,});

  ReleasePayList.fromJson(dynamic json) {
    paymentAppBy = json['paymentAppBy'];
    partPayAmt = json['partPayAmt'];
    partPayTax = json['partPayTax'];
    partPayCess = json['partPayCess'];
    partPaySc = json['partPaySc'];
  }
  String? paymentAppBy;
  String? partPayAmt;
  String? partPayTax;
  String? partPayCess;
  String? partPaySc;
ReleasePayList copyWith({  String? paymentAppBy,
  String? partPayAmt,
  String? partPayTax,
  String? partPayCess,
  String? partPaySc,
}) => ReleasePayList(  paymentAppBy: paymentAppBy ?? this.paymentAppBy,
  partPayAmt: partPayAmt ?? this.partPayAmt,
  partPayTax: partPayTax ?? this.partPayTax,
  partPayCess: partPayCess ?? this.partPayCess,
  partPaySc: partPaySc ?? this.partPaySc,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['paymentAppBy'] = paymentAppBy;
    map['partPayAmt'] = partPayAmt;
    map['partPayTax'] = partPayTax;
    map['partPayCess'] = partPayCess;
    map['partPaySc'] = partPaySc;
    return map;
  }

}

class PaymentDtlList {
  PaymentDtlList({
      this.totalBillAmt, 
      this.totalSettledAmt, 
      this.paidAmt, 
      this.tds, 
      this.cessAmt, 
      this.scAmt, 
      this.paymentType,});

  PaymentDtlList.fromJson(dynamic json) {
    totalBillAmt = json['totalBillAmt'];
    totalSettledAmt = json['totalSettledAmt'];
    paidAmt = json['paidAmt'];
    tds = json['tds'];
    cessAmt = json['cessAmt'];
    scAmt = json['scAmt'];
    paymentType = json['paymentType'];
  }
  String? totalBillAmt;
  String? totalSettledAmt;
  String? paidAmt;
  String? tds;
  String? cessAmt;
  String? scAmt;
  String? paymentType;
PaymentDtlList copyWith({  String? totalBillAmt,
  String? totalSettledAmt,
  String? paidAmt,
  String? tds,
  String? cessAmt,
  String? scAmt,
  String? paymentType,
}) => PaymentDtlList(  totalBillAmt: totalBillAmt ?? this.totalBillAmt,
  totalSettledAmt: totalSettledAmt ?? this.totalSettledAmt,
  paidAmt: paidAmt ?? this.paidAmt,
  tds: tds ?? this.tds,
  cessAmt: cessAmt ?? this.cessAmt,
  scAmt: scAmt ?? this.scAmt,
  paymentType: paymentType ?? this.paymentType,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['totalBillAmt'] = totalBillAmt;
    map['totalSettledAmt'] = totalSettledAmt;
    map['paidAmt'] = paidAmt;
    map['tds'] = tds;
    map['cessAmt'] = cessAmt;
    map['scAmt'] = scAmt;
    map['paymentType'] = paymentType;
    return map;
  }

}