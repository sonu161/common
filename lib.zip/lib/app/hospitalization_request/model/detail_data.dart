// To parse this JSON data, do
//
//     final hospitalDetailData = hospitalDetailDataFromJson(jsonString);

import 'dart:convert';

HospitalDetailData hospitalDetailDataFromJson(String str) => HospitalDetailData.fromJson(json.decode(str));

String hospitalDetailDataToJson(HospitalDetailData data) => json.encode(data.toJson());

class HospitalDetailData {
  List<Amount>? amounts;
  String? totalBillAmt;
  String? totalSettleAmt;

  HospitalDetailData({
    this.amounts,
    this.totalBillAmt,
    this.totalSettleAmt,
  });

  HospitalDetailData copyWith({
    List<Amount>? amounts,
    String? totalBillAmt,
    String? totalSettleAmt,
  }) =>
      HospitalDetailData(
        amounts: amounts ?? this.amounts,
        totalBillAmt: totalBillAmt ?? this.totalBillAmt,
        totalSettleAmt: totalSettleAmt ?? this.totalSettleAmt,
      );

  factory HospitalDetailData.fromJson(Map<String, dynamic> json) => HospitalDetailData(
    amounts: json["amounts"] == null ? [] : List<Amount>.from(json["amounts"]!.map((x) => Amount.fromJson(x))),
    totalBillAmt: json["totalBillAmt"],
    totalSettleAmt: json["totalSettleAmt"],
  );

  Map<String, dynamic> toJson() => {
    "amounts": amounts == null ? [] : List<dynamic>.from(amounts!.map((x) => x.toJson())),
    "totalBillAmt": totalBillAmt,
    "totalSettleAmt": totalSettleAmt,
  };
}

class Amount {
  String? serviceType;
  Details? details;

  Amount({
    this.serviceType,
    this.details,
  });

  Amount copyWith({
    String? serviceType,
    Details? details,
  }) =>
      Amount(
        serviceType: serviceType ?? this.serviceType,
        details: details ?? this.details,
      );

  factory Amount.fromJson(Map<String, dynamic> json) => Amount(
    serviceType: json["serviceType"],
    details: json["details"] == null ? null : Details.fromJson(json["details"]),
  );

  Map<String, dynamic> toJson() => {
    "serviceType": serviceType,
    "details": details?.toJson(),
  };
}

class Details {
  String? billAmt;
  String? eligibleAmt;
  String? settledAmt;

  Details({
    this.billAmt,
    this.eligibleAmt,
    this.settledAmt,
  });

  Details copyWith({
    String? billAmt,
    String? eligibleAmt,
    String? settledAmt,
  }) =>
      Details(
        billAmt: billAmt ?? this.billAmt,
        eligibleAmt: eligibleAmt ?? this.eligibleAmt,
        settledAmt: settledAmt ?? this.settledAmt,
      );

  factory Details.fromJson(Map<String, dynamic> json) => Details(
    billAmt: json["billAmt"],
    eligibleAmt: json["eligibleAmt"],
    settledAmt: json["settledAmt"],
  );

  Map<String, dynamic> toJson() => {
    "billAmt": billAmt,
    "eligibleAmt": eligibleAmt,
    "settledAmt": settledAmt,
  };
}
