class IndoorHospReqData {
  IndoorHospReqData({
      this.userId, 
      this.emailId, 
      this.empName, 
      this.empRelation, 
      this.patientName, 
      this.cityName, 
      this.hospitalName, 
      this.reqType, 
      this.hospitalizedDate, 
      this.hospitalLocationType, 
      this.hospitalType, 
      this.comment, 
      this.billNo, 
      this.billDate, 
      this.billAmt, 
      this.amtPaidByEmp, 
      this.file, 
      this.bookingList, 
      this.accommodationDtlList, 
      this.requestDtlSaved, 
      this.billDtlSaved, 
      this.emailErrDtlSaved, 
      this.loginLogSaved, 
      this.errorMsg, 
      this.successMsg, 
      this.httpStatus,});

  IndoorHospReqData.fromJson(dynamic json) {
    userId = json['userId'];
    emailId = json['emailId'];
    empName = json['empName'];
    empRelation = json['empRelation'];
    patientName = json['patientName'];
    cityName = json['cityName'];
    hospitalName = json['hospitalName'];
    reqType = json['reqType'];
    hospitalizedDate = json['hospitalizedDate'];
    hospitalLocationType = json['hospitalLocationType'];
    hospitalType = json['hospitalType'];
    comment = json['comment'];
    billNo = json['billNo'];
    billDate = json['billDate'];
    billAmt = json['billAmt'];
    amtPaidByEmp = json['amtPaidByEmp'];
    file = json['file'];
    if (json['bookingList'] != null) {
      bookingList = [];
      json['bookingList'].forEach((v) {
        bookingList?.add(BookingList.fromJson(v));
      });
    }
    accommodationDtlList = json['accommodationDtlList'];
    requestDtlSaved = json['requestDtlSaved'];
    billDtlSaved = json['billDtlSaved'];
    emailErrDtlSaved = json['emailErrDtlSaved'];
    loginLogSaved = json['loginLogSaved'];
    errorMsg = json['errorMsg'];
    successMsg = json['successMsg'];
    httpStatus = json['httpStatus'];
  }
  dynamic userId;
  dynamic emailId;
  dynamic empName;
  dynamic empRelation;
  dynamic patientName;
  dynamic cityName;
  dynamic hospitalName;
  dynamic reqType;
  dynamic hospitalizedDate;
  dynamic hospitalLocationType;
  dynamic hospitalType;
  dynamic comment;
  dynamic billNo;
  dynamic billDate;
  dynamic billAmt;
  dynamic amtPaidByEmp;
  dynamic file;
  List<BookingList>? bookingList;
  dynamic accommodationDtlList;
  dynamic requestDtlSaved;
  dynamic billDtlSaved;
  dynamic emailErrDtlSaved;
  dynamic loginLogSaved;
  dynamic errorMsg;
  String? successMsg;
  String? httpStatus;
IndoorHospReqData copyWith({  dynamic userId,
  dynamic emailId,
  dynamic empName,
  dynamic empRelation,
  dynamic patientName,
  dynamic cityName,
  dynamic hospitalName,
  dynamic reqType,
  dynamic hospitalizedDate,
  dynamic hospitalLocationType,
  dynamic hospitalType,
  dynamic comment,
  dynamic billNo,
  dynamic billDate,
  dynamic billAmt,
  dynamic amtPaidByEmp,
  dynamic file,
  List<BookingList>? bookingList,
  dynamic accommodationDtlList,
  dynamic requestDtlSaved,
  dynamic billDtlSaved,
  dynamic emailErrDtlSaved,
  dynamic loginLogSaved,
  dynamic errorMsg,
  String? successMsg,
  String? httpStatus,
}) => IndoorHospReqData(  userId: userId ?? this.userId,
  emailId: emailId ?? this.emailId,
  empName: empName ?? this.empName,
  empRelation: empRelation ?? this.empRelation,
  patientName: patientName ?? this.patientName,
  cityName: cityName ?? this.cityName,
  hospitalName: hospitalName ?? this.hospitalName,
  reqType: reqType ?? this.reqType,
  hospitalizedDate: hospitalizedDate ?? this.hospitalizedDate,
  hospitalLocationType: hospitalLocationType ?? this.hospitalLocationType,
  hospitalType: hospitalType ?? this.hospitalType,
  comment: comment ?? this.comment,
  billNo: billNo ?? this.billNo,
  billDate: billDate ?? this.billDate,
  billAmt: billAmt ?? this.billAmt,
  amtPaidByEmp: amtPaidByEmp ?? this.amtPaidByEmp,
  file: file ?? this.file,
  bookingList: bookingList ?? this.bookingList,
  accommodationDtlList: accommodationDtlList ?? this.accommodationDtlList,
  requestDtlSaved: requestDtlSaved ?? this.requestDtlSaved,
  billDtlSaved: billDtlSaved ?? this.billDtlSaved,
  emailErrDtlSaved: emailErrDtlSaved ?? this.emailErrDtlSaved,
  loginLogSaved: loginLogSaved ?? this.loginLogSaved,
  errorMsg: errorMsg ?? this.errorMsg,
  successMsg: successMsg ?? this.successMsg,
  httpStatus: httpStatus ?? this.httpStatus,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['userId'] = userId;
    map['emailId'] = emailId;
    map['empName'] = empName;
    map['empRelation'] = empRelation;
    map['patientName'] = patientName;
    map['cityName'] = cityName;
    map['hospitalName'] = hospitalName;
    map['reqType'] = reqType;
    map['hospitalizedDate'] = hospitalizedDate;
    map['hospitalLocationType'] = hospitalLocationType;
    map['hospitalType'] = hospitalType;
    map['comment'] = comment;
    map['billNo'] = billNo;
    map['billDate'] = billDate;
    map['billAmt'] = billAmt;
    map['amtPaidByEmp'] = amtPaidByEmp;
    map['file'] = file;
    if (bookingList != null) {
      map['bookingList'] = bookingList?.map((v) => v.toJson()).toList();
    }
    map['accommodationDtlList'] = accommodationDtlList;
    map['requestDtlSaved'] = requestDtlSaved;
    map['billDtlSaved'] = billDtlSaved;
    map['emailErrDtlSaved'] = emailErrDtlSaved;
    map['loginLogSaved'] = loginLogSaved;
    map['errorMsg'] = errorMsg;
    map['successMsg'] = successMsg;
    map['httpStatus'] = httpStatus;
    return map;
  }

}

class BookingList {
  BookingList({
      this.applNo, 
      this.patientName, 
      this.hospitalName, 
      this.hospitalizedDate, 
      this.hospitalType, 
      this.billDate, 
      this.billAmt, 
      this.relation, 
      this.reqStatus,});

  BookingList.fromJson(dynamic json) {
    applNo = json['applNo'];
    patientName = json['patientName'];
    hospitalName = json['hospitalName'];
    hospitalizedDate = json['hospitalizedDate'];
    hospitalType = json['hospitalType'];
    billDate = json['billDate'];
    billAmt = json['billAmt'];
    relation = json['relation'];
    reqStatus = json['reqStatus'];
  }
  String? applNo;
  String? patientName;
  String? hospitalName;
  String? hospitalizedDate;
  String? hospitalType;
  String? billDate;
  String? billAmt;
  String? relation;
  String? reqStatus;
BookingList copyWith({  String? applNo,
  String? patientName,
  String? hospitalName,
  String? hospitalizedDate,
  String? hospitalType,
  String? billDate,
  String? billAmt,
  String? relation,
  String? reqStatus,
}) => BookingList(  applNo: applNo ?? this.applNo,
  patientName: patientName ?? this.patientName,
  hospitalName: hospitalName ?? this.hospitalName,
  hospitalizedDate: hospitalizedDate ?? this.hospitalizedDate,
  hospitalType: hospitalType ?? this.hospitalType,
  billDate: billDate ?? this.billDate,
  billAmt: billAmt ?? this.billAmt,
  relation: relation ?? this.relation,
  reqStatus: reqStatus ?? this.reqStatus,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['applNo'] = applNo;
    map['patientName'] = patientName;
    map['hospitalName'] = hospitalName;
    map['hospitalizedDate'] = hospitalizedDate;
    map['hospitalType'] = hospitalType;
    map['billDate'] = billDate;
    map['billAmt'] = billAmt;
    map['relation'] = relation;
    map['reqStatus'] = reqStatus;
    return map;
  }

}