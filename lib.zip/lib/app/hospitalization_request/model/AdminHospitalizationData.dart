class AdminHospitalizationData {
  AdminHospitalizationData({
      this.status, 
      this.message, 
      this.responseCode, 
      this.httpStatusCode, 
      this.empName, 
      this.empAddress, 
      this.empEmail, 
      this.empMobileNo, 
      this.empRetireeCode, 
      this.empSalCode, 
      this.empGrade, 
      this.pensionOptee, 
      this.familyPension, 
      this.massOptee, 
      this.pensionProcessingStatus, 
      this.empLoginActStatus, 
      this.lastLoginTime, 
      this.lastCertificateFileUpload, 
      this.selectedTaxRegime, 
      this.fileObject, 
      this.retireesList, 
      this.lifeCertificateDtl, 
      this.accountStatus, 
      this.loghinHisList, 
      this.hhVofHisList, 
      this.indHospHistList, 
      this.financialYearList, 
      this.lifeCertificatesDtlList, 
      this.yearFilesMap, 
      this.circularDetails,});

  AdminHospitalizationData.fromJson(dynamic json) {
    status = json['status'];
    message = json['message'];
    responseCode = json['responseCode'];
    httpStatusCode = json['httpStatusCode'];
    empName = json['empName'];
    empAddress = json['empAddress'];
    empEmail = json['empEmail'];
    empMobileNo = json['empMobileNo'];
    empRetireeCode = json['empRetireeCode'];
    empSalCode = json['empSalCode'];
    empGrade = json['empGrade'];
    pensionOptee = json['pensionOptee'];
    familyPension = json['familyPension'];
    massOptee = json['massOptee'];
    pensionProcessingStatus = json['pensionProcessingStatus'];
    empLoginActStatus = json['empLoginActStatus'];
    lastLoginTime = json['lastLoginTime'];
    lastCertificateFileUpload = json['lastCertificateFileUpload'];
    selectedTaxRegime = json['selectedTaxRegime'];
    fileObject = json['fileObject'];
    retireesList = json['retireesList'];
    lifeCertificateDtl = json['lifeCertificateDtl'];
    accountStatus = json['accountStatus'];
    loghinHisList = json['loghinHisList'];
    hhVofHisList = json['hhVofHisList'];
    if (json['indHospHistList'] != null) {
      indHospHistList = [];
      json['indHospHistList'].forEach((v) {
        indHospHistList?.add(IndHospHistList.fromJson(v));
      });
    }
    financialYearList = json['financialYearList'];
    lifeCertificatesDtlList = json['lifeCertificatesDtlList'];
    yearFilesMap = json['yearFilesMap'];
    circularDetails = json['circularDetails'];
  }
  dynamic status;
  dynamic message;
  dynamic responseCode;
  dynamic httpStatusCode;
  dynamic empName;
  dynamic empAddress;
  dynamic empEmail;
  dynamic empMobileNo;
  dynamic empRetireeCode;
  dynamic empSalCode;
  dynamic empGrade;
  dynamic pensionOptee;
  dynamic familyPension;
  dynamic massOptee;
  dynamic pensionProcessingStatus;
  dynamic empLoginActStatus;
  dynamic lastLoginTime;
  dynamic lastCertificateFileUpload;
  dynamic selectedTaxRegime;
  dynamic fileObject;
  dynamic retireesList;
  dynamic lifeCertificateDtl;
  dynamic accountStatus;
  dynamic loghinHisList;
  dynamic hhVofHisList;
  List<IndHospHistList>? indHospHistList;
  dynamic financialYearList;
  dynamic lifeCertificatesDtlList;
  dynamic yearFilesMap;
  dynamic circularDetails;
AdminHospitalizationData copyWith({  dynamic status,
  dynamic message,
  dynamic responseCode,
  dynamic httpStatusCode,
  dynamic empName,
  dynamic empAddress,
  dynamic empEmail,
  dynamic empMobileNo,
  dynamic empRetireeCode,
  dynamic empSalCode,
  dynamic empGrade,
  dynamic pensionOptee,
  dynamic familyPension,
  dynamic massOptee,
  dynamic pensionProcessingStatus,
  dynamic empLoginActStatus,
  dynamic lastLoginTime,
  dynamic lastCertificateFileUpload,
  dynamic selectedTaxRegime,
  dynamic fileObject,
  dynamic retireesList,
  dynamic lifeCertificateDtl,
  dynamic accountStatus,
  dynamic loghinHisList,
  dynamic hhVofHisList,
  List<IndHospHistList>? indHospHistList,
  dynamic financialYearList,
  dynamic lifeCertificatesDtlList,
  dynamic yearFilesMap,
  dynamic circularDetails,
}) => AdminHospitalizationData(  status: status ?? this.status,
  message: message ?? this.message,
  responseCode: responseCode ?? this.responseCode,
  httpStatusCode: httpStatusCode ?? this.httpStatusCode,
  empName: empName ?? this.empName,
  empAddress: empAddress ?? this.empAddress,
  empEmail: empEmail ?? this.empEmail,
  empMobileNo: empMobileNo ?? this.empMobileNo,
  empRetireeCode: empRetireeCode ?? this.empRetireeCode,
  empSalCode: empSalCode ?? this.empSalCode,
  empGrade: empGrade ?? this.empGrade,
  pensionOptee: pensionOptee ?? this.pensionOptee,
  familyPension: familyPension ?? this.familyPension,
  massOptee: massOptee ?? this.massOptee,
  pensionProcessingStatus: pensionProcessingStatus ?? this.pensionProcessingStatus,
  empLoginActStatus: empLoginActStatus ?? this.empLoginActStatus,
  lastLoginTime: lastLoginTime ?? this.lastLoginTime,
  lastCertificateFileUpload: lastCertificateFileUpload ?? this.lastCertificateFileUpload,
  selectedTaxRegime: selectedTaxRegime ?? this.selectedTaxRegime,
  fileObject: fileObject ?? this.fileObject,
  retireesList: retireesList ?? this.retireesList,
  lifeCertificateDtl: lifeCertificateDtl ?? this.lifeCertificateDtl,
  accountStatus: accountStatus ?? this.accountStatus,
  loghinHisList: loghinHisList ?? this.loghinHisList,
  hhVofHisList: hhVofHisList ?? this.hhVofHisList,
  indHospHistList: indHospHistList ?? this.indHospHistList,
  financialYearList: financialYearList ?? this.financialYearList,
  lifeCertificatesDtlList: lifeCertificatesDtlList ?? this.lifeCertificatesDtlList,
  yearFilesMap: yearFilesMap ?? this.yearFilesMap,
  circularDetails: circularDetails ?? this.circularDetails,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['message'] = message;
    map['responseCode'] = responseCode;
    map['httpStatusCode'] = httpStatusCode;
    map['empName'] = empName;
    map['empAddress'] = empAddress;
    map['empEmail'] = empEmail;
    map['empMobileNo'] = empMobileNo;
    map['empRetireeCode'] = empRetireeCode;
    map['empSalCode'] = empSalCode;
    map['empGrade'] = empGrade;
    map['pensionOptee'] = pensionOptee;
    map['familyPension'] = familyPension;
    map['massOptee'] = massOptee;
    map['pensionProcessingStatus'] = pensionProcessingStatus;
    map['empLoginActStatus'] = empLoginActStatus;
    map['lastLoginTime'] = lastLoginTime;
    map['lastCertificateFileUpload'] = lastCertificateFileUpload;
    map['selectedTaxRegime'] = selectedTaxRegime;
    map['fileObject'] = fileObject;
    map['retireesList'] = retireesList;
    map['lifeCertificateDtl'] = lifeCertificateDtl;
    map['accountStatus'] = accountStatus;
    map['loghinHisList'] = loghinHisList;
    map['hhVofHisList'] = hhVofHisList;
    if (indHospHistList != null) {
      map['indHospHistList'] = indHospHistList?.map((v) => v.toJson()).toList();
    }
    map['financialYearList'] = financialYearList;
    map['lifeCertificatesDtlList'] = lifeCertificatesDtlList;
    map['yearFilesMap'] = yearFilesMap;
    map['circularDetails'] = circularDetails;
    return map;
  }

}

class IndHospHistList {
  IndHospHistList({
      this.applNo, 
      this.patientName, 
      this.hospitalName, 
      this.hospitalizedDate, 
      this.hospitalType, 
      this.billDate, 
      this.billAmt, 
      this.relation, 
      this.reqStatus,});

  IndHospHistList.fromJson(dynamic json) {
    applNo = json['applNo'];
    patientName = json['patientName'];
    hospitalName = json['hospitalName'];
    hospitalizedDate = json['hospitalizedDate'];
    hospitalType = json['hospitalType'];
    billDate = json['billDate'];
    billAmt = json['billAmt'];
    relation = json['relation'];
    reqStatus = json['reqStatus'];
  }
  String? applNo;
  String? patientName;
  String? hospitalName;
  String? hospitalizedDate;
  String? hospitalType;
  String? billDate;
  String? billAmt;
  String? relation;
  String? reqStatus;
IndHospHistList copyWith({  String? applNo,
  String? patientName,
  String? hospitalName,
  String? hospitalizedDate,
  String? hospitalType,
  String? billDate,
  String? billAmt,
  String? relation,
  String? reqStatus,
}) => IndHospHistList(  applNo: applNo ?? this.applNo,
  patientName: patientName ?? this.patientName,
  hospitalName: hospitalName ?? this.hospitalName,
  hospitalizedDate: hospitalizedDate ?? this.hospitalizedDate,
  hospitalType: hospitalType ?? this.hospitalType,
  billDate: billDate ?? this.billDate,
  billAmt: billAmt ?? this.billAmt,
  relation: relation ?? this.relation,
  reqStatus: reqStatus ?? this.reqStatus,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['applNo'] = applNo;
    map['patientName'] = patientName;
    map['hospitalName'] = hospitalName;
    map['hospitalizedDate'] = hospitalizedDate;
    map['hospitalType'] = hospitalType;
    map['billDate'] = billDate;
    map['billAmt'] = billAmt;
    map['relation'] = relation;
    map['reqStatus'] = reqStatus;
    return map;
  }

}