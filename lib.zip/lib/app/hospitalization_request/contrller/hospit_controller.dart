import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/hospitalization_request/indoor_hosp_repo.dart';
import 'package:sidbi_app/app/hospitalization_request/model/AccomodationDetailData.dart';
import 'package:sidbi_app/app/hospitalization_request/model/AdminHospitalizationData.dart';
import 'package:sidbi_app/components/helper.dart';

import '../../login/controller/loging_ctrl.dart';
import '../model/detail_data.dart';
import '../model/indoor_hosp_data.dart';
import '../views/claim_detail.dart';

class HospitalController extends GetxController {
  // Rx<HospitalDetailData> hospitalData = HospitalDetailData().obs;
  IndoorHospRepo repoHos = new IndoorHospRepo();
  Helper helper = new Helper();
  RxList<IndoorHospReqData> copyData = <IndoorHospReqData>[].obs;
  RxList<AccomodationDetailData> detailData = <AccomodationDetailData>[].obs;
  RxList<AccommodationDtlList> accDetailData = <AccommodationDtlList>[].obs;
  var loading = AppLoadingState.Initial.obs;
  RxList<AdminHospitalizationData> copyData2 = <AdminHospitalizationData>[].obs;
  getHospitalData() async {
    try {
      loading.value = AppLoadingState.Loading;
      // helper.fullAppLoading();
      var res = await repoHos.getIndoorHosp();
      var userFor = await helper.getSharedPrefString(keyName: "userFor");
      if (userFor != null) {
        print("hellllooo ${jsonDecode(res.body)}");
        AdminHospitalizationData data =
        AdminHospitalizationData.fromJson(jsonDecode(res.body));
        if (data.indHospHistList!.length > 0 || data.indHospHistList! != null) {
          copyData2?.add(data);
          loading.value = AppLoadingState.Loaded;
        } else {
          loading.value = AppLoadingState.Blank;
        }

      } else {
        IndoorHospReqData data =
        IndoorHospReqData.fromJson(jsonDecode(res.body));
        if (data.bookingList!.length > 0 || data.bookingList! != null) {
          copyData?.add(data);
          loading.value = AppLoadingState.Loaded;
        } else {
          loading.value = AppLoadingState.Blank;
        }
      }

      // Get.back();
    } catch (e) {
      print(e);
      loading.value = AppLoadingState.Error;
      // Get.back();
    }
  }

  getRefreshHospitalData() async {
    print("Hello");
    try {
      var res = await repoHos.getIndoorHosp();
      IndoorHospReqData data = IndoorHospReqData.fromJson(jsonDecode(res.body));
      if (data.bookingList!.length > 0 || data.bookingList! != null) {
        copyData?.add(data);
      } else {}
      // Get.back();
    } catch (e) {
      print(e);
      loading.value = AppLoadingState.Error;
      // Get.back();
    }
  }

  getDetail({required String formId, required String pateintName}) async {
    try {
      accDetailData.clear();
      print("form id : $formId");
      helper.fullAppLoading();
      var res = await repoHos.viewDetailOfAccomodation(formId);
      print(res.body);
      // AccomodationDetailData detailDatas = AccomodationDetailData.fromJson(jsonDecode(res.body));
      AccommodationDtlList accList = AccommodationDtlList.fromJson(
          jsonDecode(res.body)['accommodationDtlList']);
      accDetailData.add(accList);
      // detailData.add(accList.);
      print(accDetailData.first.settledAmtList!.length);
      Get.back();
      if (accDetailData.first.settledAmtList!.length > 0 ||
          accDetailData.first.paymentDtlList!.length > 0 &&
              accDetailData.first.applDtlList!.length > 0 &&
              accDetailData.first.releasePayList!.length > 0) {
        Get.to(() => ClaimDetailView(),
            arguments: pateintName, transition: Transition.fadeIn);
      } else {
        helper.appDialogBox(
            title: 'Information',
            message: 'Request forwarded to bank',
            show_confirm: false);
      }
    } catch (e) {
      print(e);
      Get.back();
    }
  }

  // @override
  // void onReady() {
  //   // TODO: implement onReady
  //   super.onReady();
  //   print("Hello");
  //   getHospitalData();
  // }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getHospitalData();
  }
}
