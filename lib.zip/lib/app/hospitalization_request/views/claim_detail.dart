import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/hospitalization_request/contrller/hospit_controller.dart';

class ClaimDetailView extends StatefulWidget {
  const ClaimDetailView({super.key});

  @override
  State<ClaimDetailView> createState() => _ClaimDetailViewState();
}

class _ClaimDetailViewState extends State<ClaimDetailView> {
  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        title: Text("${Get.arguments}"),
        titleSpacing: 0,
      ),
      body: Container(
        child: SingleChildScrollView(
          child: Container(
            child: Column(
              children: [
                Container(
                  height: 250,
                  // color: Colors.red,
                  child: Stack(
                    children: [
                      Container(
                        height: 230,
                        decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary),
                        child: Center(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                child: Text(
                                  "Total Amount".toString().toUpperCase(),
                                  style: TextStyle(color: Colors.white,fontWeight: FontWeight.w600),
                                ),
                              ),
                              Container(
                                // child: Text("\u{20B9} ${Get.arguments['billAmount']}",
                                //     style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold)),
                                child: GetX(
                                  init: HospitalController(),
                                  builder: (ctrl){
                                    var detail = ctrl.accDetailData.first.applDtlList![0];
                                    return RichText(
                                      text: TextSpan(
                                          children: [
                                            TextSpan(
                                                text: "${detail.settledAmt}",
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 45))
                                          ],
                                          text: "\u{20B9}",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 30)),
                                    );
                                  },
                                ),
                              ),
                              Container(
                                  child: Text(
                                    "Total Amount have been settled",
                                    style: TextStyle(color: Colors.white,fontWeight: FontWeight.w500),
                                  )
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 10,
                        left: 0,
                        right: 0,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate((width/20).round(), (ind){
                            return Container(
                              width: 20,
                              height: 20,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(300),
                                  color: Theme.of(context).colorScheme.background
                              ),
                            );
                          }),
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(20, 10, 20, 20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 1
                      )
                    ]
                  ),
                  child: Column(
                    children: [
                      Container(
                        padding:EdgeInsets.all(15),
                        child: Column(
                          children: [
                            Container(
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: Text("Indoor Hospitalization Claim Detail",style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600
                                ),),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            GetX(
                              init: HospitalController(),
                              builder: (ctrl){
                                var detail = ctrl.accDetailData.first.applDtlList![0];
                                return Container(
                                  child: Container(
                                    child: Column(
                                      children: [
                                        rowView(
                                            title: "Application No",
                                            value: "${detail.applNo}"
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        rowView(
                                            title: "Request Type",
                                            value: "${detail.reqtype}"
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        rowView(
                                            title: "Settled Amount",
                                            value: "\u{20B9}${detail.settledAmt}"
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        rowView(
                                            title: "Status",
                                            value: "${detail.status}"
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            )
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 50,
                          right: 50
                        ),
                        child: Divider(
                          thickness: 2,
                        ),
                      ),
                      Container(
                        padding:EdgeInsets.all(15),
                        child: Column(
                          children: [
                            Container(
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: Text("Service Type",style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600
                                ),),
                              ),
                            ),
                            GetX(
                              init: HospitalController(),
                              builder: (ctrl){
                                return Column(
                                  children: [
                                    SizedBox(height: 20,),
                                    ListView.builder(
                                      physics: NeverScrollableScrollPhysics(),
                                      shrinkWrap: true,
                                      itemCount: ctrl.accDetailData.first.settledAmtList!.length,
                                      itemBuilder: (context, index){
                                        var amtData = ctrl.accDetailData.first.settledAmtList![index];
                                        print("length of service type : ${amtData}");
                                        return Container(
                                            child: linkedTable(data: amtData)
                                        );
                                      },
                                    ),
                                    SizedBox(
                                      height: 15,
                                    ),
                                    Divider(),
                                    // Container(
                                    //   child: Column(
                                    //     children: [
                                    //       Row(
                                    //         children: [
                                    //           Expanded(child: Text("Total Bill Amount",
                                    //               style: TextStyle(
                                    //                   fontWeight: FontWeight.w700
                                    //               ))),
                                    //           Expanded(child: Text(
                                    //             "\u{20B9}${ctrl.accDetailData.first.paymentDtlList![0].totalBillAmt}",
                                    //             textAlign: TextAlign.right,
                                    //             style: TextStyle(
                                    //               fontWeight: FontWeight.w700
                                    //             ),
                                    //           ),
                                    //           ),
                                    //         ],
                                    //       ),
                                    //     ],
                                    //   ),
                                    // )
                                  ],
                                );
                                // return ListView.builder(
                                //   physics: NeverScrollableScrollPhysics(),
                                //   shrinkWrap: true,
                                //   itemCount: ctrl.hospitalData.value.amounts?.length,
                                //   itemBuilder: (context, index){
                                //     var amtData = ctrl.hospitalData.value.amounts![index];
                                //     return Container(
                                //       child: linkedTable(data: amtData)
                                //     );
                                //   },
                                // );
                              },
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  child: GetX(
                    init: HospitalController(),
                    builder: (ctrl){
                      if(ctrl.accDetailData.first.paymentDtlList!.length != 0){
                        return Container(
                          padding:EdgeInsets.all(15),
                          margin: EdgeInsets.fromLTRB(20, 10, 20, 20),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.black12,
                                    blurRadius: 1
                                )
                              ]
                          ),
                          child: Column(
                            children: [
                              Container(
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text("Payment Details",style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600
                                  ),),
                                ),
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              Container(
                                child:  Row(
                                  children: [
                                    Expanded(child: Text("Total Bill Amount",
                                        style: TextStyle(
                                            fontWeight: FontWeight.w700
                                        ))),
                                    Expanded(child: Text(
                                      "\u{20B9}${ctrl.accDetailData.first.paymentDtlList![0].totalBillAmt}",
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          fontWeight: FontWeight.w700
                                      ),
                                    ),
                                    ),
                                  ],
                                ),
                              ),
                              Divider(),
                              Container(
                                child:  Row(
                                  children: [
                                    Expanded(child: Text("Total Settled Amount",
                                        style: TextStyle(
                                            fontWeight: FontWeight.w700
                                        ))),
                                    Expanded(child: Text(
                                      "\u{20B9}${ctrl.accDetailData.first.paymentDtlList![0].totalSettledAmt}",
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          fontWeight: FontWeight.w700
                                      ),
                                    ),
                                    ),
                                  ],
                                ),
                              ),
                              Divider(),
                              Container(
                                child:  Row(
                                  children: [
                                    Expanded(child: Text("Paid Amount",
                                        style: TextStyle(
                                            fontWeight: FontWeight.w700
                                        ))),
                                    Expanded(child: Text(
                                      "\u{20B9}${ctrl.accDetailData.first.paymentDtlList![0].paidAmt}",
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          fontWeight: FontWeight.w700
                                      ),
                                    ),
                                    ),
                                  ],
                                ),
                              ),
                              Divider(),
                              Container(
                                child:  Row(
                                  children: [
                                    Expanded(child: Text("TDS",
                                        style: TextStyle(
                                            fontWeight: FontWeight.w700
                                        ))),
                                    Expanded(child: Text(
                                      "\u{20B9}${ctrl.accDetailData.first.paymentDtlList![0].tds}",
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          fontWeight: FontWeight.w700
                                      ),
                                    ),
                                    ),
                                  ],
                                ),
                              ),
                              Divider(),
                              Container(
                                child:  Row(
                                  children: [
                                    Expanded(child: Text("Cess Amount",
                                        style: TextStyle(
                                            fontWeight: FontWeight.w700
                                        ))),
                                    Expanded(child: Text(
                                      "\u{20B9}${ctrl.accDetailData.first.paymentDtlList![0].cessAmt}",
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          fontWeight: FontWeight.w700
                                      ),
                                    ),
                                    ),
                                  ],
                                ),
                              ),
                              Divider(),
                              Container(
                                child:  Row(
                                  children: [
                                    Expanded(child: Text("SC Amount",
                                        style: TextStyle(
                                            fontWeight: FontWeight.w700
                                        ))),
                                    Expanded(child: Text(
                                      "\u{20B9}${ctrl.accDetailData.first.paymentDtlList![0].scAmt}",
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          fontWeight: FontWeight.w700
                                      ),
                                    ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      }
                      else{
                        return Container();
                      }
                    },
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget rowView({title, value}){
    return Container(
      child: Row(
        children: [
          Expanded(child: Text("$title")),
          Expanded(child: Text("$value",textAlign: TextAlign.right,)),
        ],
      ),
    );
  }
  Widget linkedTable({data}){
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(
            // color: Color(0xffE9ECFDFF),
            // color:Theme.of(context).colorScheme.primary.withOpacity(0.1),
            color:Color(0xFFE9ECFD),

            borderRadius: BorderRadius.circular(5),
          ),
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 15,
              ),
              Container(
                padding: EdgeInsets.only(
                  left: 10
                ),
                child: Text("${data.serviceType}"),
              ),
              SizedBox(
                height: 5,
              ),
              Container(
                padding: EdgeInsets.all(10),
                margin: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  // color:Color(0xFFffffff),
                  borderRadius: BorderRadius.circular(5),
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFFffffff),
                      Color(0xFFffffff),
                      Color(0xFFE9ECFD),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter
                  )
                  // border: Border.all(
                  //   color:Color(0xffE3F0F4)
                  // )
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(child: Text("Billed Amount")),
                        Expanded(child: Text("\u{20B9}${data.billAmt}", textAlign: TextAlign.right,)),
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      children: [
                        Expanded(child: Text("Eligible Amount")),
                        Expanded(child: Text("\u{20B9}${data.eligibleAmt}", textAlign: TextAlign.right,)),
                      ],
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      children: [
                        Expanded(child: Text("Settled Amount")),
                        Expanded(child: Text("\u{20B9}${data.settledAmt}", textAlign: TextAlign.right,)),
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
        ),
        SizedBox(
          height: 10,
        )
      ],
    );
  }

}
