import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/hospitalization_request/contrller/hospit_controller.dart';
import 'package:sidbi_app/app/hospitalization_request/views/add_claim.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/loading.dart';
import 'package:sidbi_app/components/no_data.dart';
import 'package:sizer/sizer.dart';

import '../../../components/main_button.dart';

class HospitalizationView extends StatelessWidget {
  const HospitalizationView({super.key});

  @override
  Widget build(BuildContext context) {
    return const HospitalizationViewLoader();
  }
}

class HospitalizationViewLoader extends StatefulWidget {
  const HospitalizationViewLoader({super.key});

  @override
  State<HospitalizationViewLoader> createState() => _HospitalizationViewLoaderState();
}

class _HospitalizationViewLoaderState extends State<HospitalizationViewLoader> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft]);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.background,
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: Text("Hospitalization Claim"),
          titleSpacing: 1,
          actions: [
            IconButton(
              onPressed: () {
                Get.to(AllClaimPage());
              },
              icon: Icon(Icons.add),
            ),
            SizedBox(
              width: 10,
            )
          ],
        ),
        body: Container(
          child: SingleChildScrollView(
            child: Container(
              // margin: EdgeInsets.fromLTRB(20, 20, 20, 10),
              child: GetX(
                init: HospitalController(),
                builder: (ctrl) {
                  if (ctrl.loading == AppLoadingState.Loading) {
                    return LoadingApp();
                  } else if (ctrl.loading == AppLoadingState.Loaded) {
                    if (ctrl.copyData.length != 0) {
                      return ListView.builder(
                        padding: EdgeInsets.only(top: 6),
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemCount: ctrl.copyData.first.bookingList?.length,
                        itemBuilder: (context, index) {
                          var data = ctrl.copyData.first.bookingList;
                          return Container(
                            // padding: EdgeInsets.fromLTRB(15, 20, 15, 20),
                            // margin: EdgeInsets.fromLTRB(15, 0, 15, 6),
                            margin: EdgeInsets.fromLTRB(0, 0, 0, 6),
                            decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.onPrimary,
                                border: Border(
                                    bottom: BorderSide(color: Colors.black12)),
                                // borderRadius: BorderRadius.circular(15),
                                // boxShadow: [
                                //   BoxShadow(
                                //       color: Color.fromARGB(66, 175, 175, 175),
                                //       blurRadius: 5,
                                //       offset: Offset(0, 1))
                                // ]
                                ),
                                
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  padding:
                                      EdgeInsets.fromLTRB(20, 20, 20, 20),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        padding:
                                            EdgeInsets.fromLTRB(0, 0, 0, 10),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            Container(
                                              child: RichText(
                                                text: TextSpan(
                                                    text: "Bill Date : ",
                                                    style: TextStyle(
                                                        color: Theme.of(context).colorScheme.onSecondary,
                                                        fontWeight:
                                                            FontWeight.w600),
                                                    children: [
                                                      TextSpan(
                                                          text:
                                                              "${data![index].billDate}",
                                                          style: TextStyle(
                                                              color: Theme.of(context).colorScheme.onSecondary,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600))
                                                    ]),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 5,
                                            ),
                                            Container(
                                              child: Row(
                                                children: [
                                                  Container(
                                                    height: 5,
                                                    width: 15,
                                                    color: Color(0xff8747F0),
                                                  ),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Container(
                                                    height: 5,
                                                    width: 15,
                                                    color: Color(0xffE347F0),
                                                  )
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              child: ListTile(
                                                contentPadding: EdgeInsets.zero,
                                                title: Text(
                                                  "${data[index].relation}",
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      color: Theme.of(context).colorScheme.onSecondary)
                                                ),
                                                leading: Container(
                                                  width: 50,
                                                  height: 50,
                                                  decoration: BoxDecoration(
                                                      color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              600),
                                                      border: Border.all(
                                                          color: Theme.of(context).colorScheme.primary.withOpacity(0.2))),
                                                  child: Center(
                                                    child: SizedBox(
                                                      height: 25,
                                                      width: 25,
                                                      child: Opacity(
                                                        opacity: 0.9,
                                                        child: Image.asset(
                                                            "assets/icons/user.png",color: Theme.of(context).colorScheme.primary,),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                subtitle: Text(
                                                  "${data[index].patientName}",
                                                  style: TextStyle(
                                                      fontSize: 16,
                                                      fontWeight: FontWeight.w700,
                                                      color: Theme.of(context).colorScheme.onSecondary),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Container(
                                        child: RichText(
                                          text: TextSpan(
                                              text: "",
                                              style: TextStyle(
                                                  color: Colors.black54),
                                              children: [
                                                TextSpan(
                                                    text:
                                                        "\u{20B9}${numberFormate(number: data[index].billAmt)}",
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 2.5.h,
                                                        color:
                                                            Theme.of(context)
                                                                .colorScheme
                                                                .onSecondary))
                                              ]),
                                        ),
                                      ),
                                        ],
                                      ),
                                      SizedBox(height: 10),                                       
                                    ],
                                  ),
                                ),
                                // Divider(),
                                // SizedBox(height: 10),
                                Container(
                                  padding:
                                      EdgeInsets.fromLTRB(20, 10, 20, 10),
                                  decoration: BoxDecoration(
                                      color:
                                          Theme.of(context).colorScheme.secondary),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Container(
                                        child: Row(
                                          // mainAxisAlignment:
                                          //     MainAxisAlignment.spaceBetween,
                                          children: [
                                            // Column(
                                            //   mainAxisAlignment:
                                            //       MainAxisAlignment.start,
                                            //   crossAxisAlignment:
                                            //       CrossAxisAlignment.start,
                                            //   children: [
                                            //     Container(
                                            //       padding:
                                            //           EdgeInsets.fromLTRB(
                                            //               5, 3, 5, 3),
                                            //       decoration: BoxDecoration(
                                            //           color: Color.fromARGB(255, 203, 255, 231),
                                            //           borderRadius:
                                            //               BorderRadius
                                            //                   .circular(5)),
                                            //       child: Text(
                                            //           "${data[index].hospitalName}",
                                            //             style: TextStyle(
                                            //               color: Color.fromARGB(255, 0, 129, 69)
                                            //             ),
                                            //           ),
                                            //     ),
                                            //     // Container(
                                            //     //   child: Text(
                                            //     //       "${data[index].hospitalType}",
                                            //     //       style: TextStyle(
                                            //     //           color: Colors
                                            //     //               .black54)),
                                            //     // ),
                                            //     // SizedBox(
                                            //     //   height: 10,
                                            //     // ),
                                            //   ],
                                            // ),
                                            Container(
                                              padding: EdgeInsets.fromLTRB(
                                                  5, 3, 5, 3),
                                              decoration: BoxDecoration(
                                                  color: Color.fromARGB(
                                                      255, 203, 255, 231),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          5)),
                                              child: Row(
                                                children: [
                                                  Icon(
                                                    Icons.health_and_safety,
                                                    size: 18,
                                                    color: Color.fromARGB(
                                                            255, 0, 129, 69)
                                                  ),
                                                  Text(
                                                    "${data[index].hospitalName}",
                                                    style: TextStyle(
                                                        color: Color.fromARGB(
                                                            255, 0, 129, 69)),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Container(
                                              padding: EdgeInsets.fromLTRB(
                                                  5, 3, 5, 3),
                                              decoration: BoxDecoration(
                                                  color: Color.fromARGB(
                                                      255, 255, 220, 203),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          5)),
                                              child: Row(
                                                children: [
                                                  Icon(
                                                    Icons.calendar_month,
                                                    color: Color.fromARGB(
                                                        255, 255, 81, 0),
                                                    size: 18,
                                                  ),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Text(
                                                    "${data[index].hospitalizedDate}",
                                                    style: TextStyle(
                                                        color: Color.fromARGB(
                                                            255, 255, 81, 0)),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      MainButton(
                                        buttonLable: "View Detail",
                                        borderRadius: 5,
                                        padding: EdgeInsets.fromLTRB(20, 10, 20, 10),
                                        onTap: () {
                                          // Get.to(ClaimDetailView(),arguments: data);
                                          ctrl.getDetail(
                                              formId: "${data[index].applNo}",
                                              pateintName:
                                                  data[index].patientName!);
                                        },
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                          );
                        },
                      );
                    } else {
                      print("${ctrl.copyData2.length}");
                      if (ctrl.copyData2.length > 0 &&
                          ctrl.copyData2.first.indHospHistList!.length > 0) {
                        return ListView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount:
                              ctrl.copyData2.first.indHospHistList?.length,
                          itemBuilder: (context, index) {
                            var data = ctrl.copyData2.first.indHospHistList;
                            return Container(
                              // padding: EdgeInsets.fromLTRB(15, 20, 15, 20),
                              margin: EdgeInsets.only(bottom: 15),
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(15),
                                  boxShadow: [
                                    BoxShadow(
                                        color: Colors.black26,
                                        blurRadius: 5,
                                        offset: Offset(0, 1))
                                  ]),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    padding:
                                        EdgeInsets.fromLTRB(20, 20, 20, 20),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          padding: EdgeInsets.fromLTRB(
                                              0, 0, 0, 10),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              Container(
                                                child: RichText(
                                                  text: TextSpan(
                                                      text: "Bill Date : ",
                                                      style: TextStyle(
                                                          color:
                                                              Colors.black54,
                                                          fontWeight:
                                                              FontWeight
                                                                  .w600),
                                                      children: [
                                                        TextSpan(
                                                            text:
                                                                "${data![index].billDate}",
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .black54,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600))
                                                      ]),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Container(
                                                child: Row(
                                                  children: [
                                                    Container(
                                                      height: 5,
                                                      width: 15,
                                                      color:
                                                          Color(0xff8747F0),
                                                    ),
                                                    SizedBox(
                                                      width: 5,
                                                    ),
                                                    Container(
                                                      height: 5,
                                                      width: 15,
                                                      color:
                                                          Color(0xffE347F0),
                                                    )
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                        Container(
                                          child: ListTile(
                                            contentPadding: EdgeInsets.zero,
                                            title: Text(
                                              "${data[index].patientName}",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w600,
                                                  color: Color(0xff404040)),
                                            ),
                                            leading: Container(
                                              width: 50,
                                              height: 50,
                                              decoration: BoxDecoration(
                                                  // color: Colors.red,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          600),
                                                  border: Border.all(
                                                      color: Colors.black12)),
                                              child: Center(
                                                child: SizedBox(
                                                  height: 25,
                                                  width: 25,
                                                  child: Opacity(
                                                    opacity: 0.5,
                                                    child: Image.asset(
                                                        "assets/icons/user.png"),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            subtitle: Text(
                                              "${data[index].relation}",
                                              style: TextStyle(
                                                  color: Color(0xff7D7D7D)),
                                            ),
                                          ),
                                        ),
                                        SizedBox(height: 10),
                                        Container(
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                child: Text(
                                                    "${data[index].hospitalName}"),
                                              ),
                                              Container(
                                                child: Text(
                                                    "${data[index].hospitalType}",
                                                    style: TextStyle(
                                                        color:
                                                            Colors.black54)),
                                              ),
                                              SizedBox(
                                                height: 10,
                                              ),
                                              Container(
                                                child: RichText(
                                                  text: TextSpan(
                                                      text: "Bill Amount ",
                                                      style: TextStyle(
                                                          color:
                                                              Colors.black54),
                                                      children: [
                                                        TextSpan(
                                                            text:
                                                                "\u{20B9}${numberFormate(number: data[index].billAmt)}",
                                                            style: TextStyle(
                                                                color: Theme.of(
                                                                        context)
                                                                    .colorScheme
                                                                    .primary))
                                                      ]),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Divider(),
                                  SizedBox(height: 10),
                                  Container(
                                    padding:
                                        EdgeInsets.fromLTRB(20, 0, 20, 20),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.calendar_month,
                                              color: Colors.black45,
                                              size: 18,
                                            ),
                                            SizedBox(
                                              width: 5,
                                            ),
                                            Text(
                                                "${data[index].hospitalizedDate}"),
                                          ],
                                        ),
                                        MainButton(
                                          buttonLable: "View Detail",
                                          onTap: () {
                                            // Get.to(ClaimDetailView(),arguments: data);
                                            ctrl.getDetail(
                                                formId:
                                                    "${data[index].applNo}",
                                                pateintName:
                                                    data[index].patientName!);
                                          },
                                        )
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            );
                          },
                        );
                      } else {
                        return NoData(
                          refresh: () {
                            ctrl.getHospitalData();
                          },
                        );
                      }
                    }
                  } else if (ctrl.loading == AppLoadingState.Blank) {
                    return NoData(refresh: () {
                      ctrl.getHospitalData();
                    });
                  } else {
                    return NoData(refresh: () {
                      ctrl.getHospitalData();
                    });
                  }
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  String numberFormate({number}){
    var num = int.parse(number);
    String amount = num.toStringAsFixed(2).replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},');
    return amount;
  }
}
