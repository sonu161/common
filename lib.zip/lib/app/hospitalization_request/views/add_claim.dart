import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/hospitalization_request/contrller/add_claim_controller.dart';
import 'package:sidbi_app/app/login/repos/static_datas.dart';
import 'package:sidbi_app/components/date_input.dart';
import 'package:sidbi_app/components/drop_converter.dart';
import 'package:sidbi_app/components/drop_down_btn.dart';
import 'package:sidbi_app/components/form_field.dart';
import 'package:sidbi_app/components/input_field.dart';
import 'package:sidbi_app/components/main_button.dart';
import 'package:sidbi_app/components/text_area.dart';
import 'package:sidbi_app/components/text_field.dart';

class AllClaimPage extends StatefulWidget {
  const AllClaimPage({super.key});

  @override
  State<AllClaimPage> createState() => _AllClaimPageState();
}

class _AllClaimPageState extends State<AllClaimPage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Container(
        child: SingleChildScrollView(
          padding: EdgeInsets.only(top: 20, bottom: 20),
          child: Container(
            margin: EdgeInsets.only(left: 15, right: 15),
            padding: EdgeInsets.only(top: 20, bottom: 20, left: 20, right: 20),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)]),
            child: Column(
              children: [
                SizedBox(
                  height: 40,
                ),
                Text("Indoor Hospitalization Request",
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.black54)),
                SizedBox(
                  height: 40,
                ),
                GetX(
                  init: AddClaimController(),
                  builder: (ctrl) {
                    // return Form(
                    //   key: ctrl.formKey.value,
                    //   child: Column(
                    //     children: [
                    //       FormFields(
                    //         hint: "Enter your name here",
                    //         fullLabel: true,
                    //         fullLabelText: "Employee Name",
                    //         borderRadius: 6,
                    //       ),
                    //       SizedBox(
                    //         height: 10,
                    //       ),
                    //       DropDownBtn(
                    //         hint: "Select relation",
                    //         data: [],
                    //       ),
                    //       SizedBox(
                    //         height: 10,
                    //       ),
                    //       FormFields(
                    //         hint: "Enter name",
                    //         fullLabel: true,
                    //         fullLabelText: "Patient Name",
                    //         borderRadius: 6,
                    //       ),
                    //     ],
                    //   ),
                    // );

                    return Form(
                      key: ctrl.formKey.value,
                      child: Column(
                        children: [
                          // FormFields(
                          //   hint: "Enter your name here",
                          //   fullLabel: true,
                          //   fullLabelText: "Employee Name",
                          //   borderRadius: 6,
                          //   textEditingController: ctrl.textControllers[0],
                          // ),
                          // SizedBox(
                          //   height: 20,
                          // ),
                          DropDownBtn(
                            hint: ctrl.relationName.value,
                            data: StaticDatas().relationType,
                            dropItemChild: "name",
                            onChange: (val) {
                              var result = DropConverter().setDropValue(val);
                              ctrl.relationName.value = result['name'];
                              ctrl.relationVal.value = result['val'];
                              print(result['name']);
                              if (result['name'].toString().toUpperCase() ==
                                  "SELF") {
                                ctrl.setUserName(dropVal: result['name']);
                              } else {
                                ctrl.textControllers[1].text = "";
                              }
                            },
                            value: ctrl.relationVal.value,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          FormFields(
                            hint: "Enter name",
                            fullLabel: true,
                            fullLabelText: "Patient Name",
                            borderRadius: 6,
                            textEditingController: ctrl.textControllers[1],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          FormFields(
                            hint: "Enter city",
                            fullLabel: true,
                            fullLabelText: "City Name",
                            borderRadius: 6,
                            textEditingController: ctrl.textControllers[2],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          FormFields(
                            hint: "Enter Hospital",
                            fullLabel: true,
                            fullLabelText: "Hospital Name",
                            borderRadius: 6,
                            textEditingController: ctrl.textControllers[3],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          FormFields(
                            hint: "Reimbursement",
                            fullLabel: true,
                            fullLabelText: "Request Type",
                            borderRadius: 6,
                            textEditingController: ctrl.textControllers[4],
                            readOnly: true,
                            disabled: true,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          // DateInput(
                          //   hint: "dd-mm-yyyy",
                          //   fullLabel: true,
                          //   fullLabelText: "Hospitalized Date",
                          //   borderRadius: 6,
                          //   textEditingController: ctrl.textAreaCtrl[0],
                          //   readOnly: true,
                          //   dateDivider: "-",
                          // ),
                          DateInput(
                            hint: "dd-MM-yyyy",
                            fullLabel: true,
                            fullLabelText: "Hospitalized Date",
                            borderRadius: 6,
                            readOnly: false,
                            textEditingController: ctrl.textAreaCtrl[0],
                            lightTextBox: true,
                            endDate: DateTime.now(),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          DropDownBtn(
                              hint: ctrl.hospitalLocationType.value,
                              data: StaticDatas().hospitalLocation,
                              dropItemChild: "name",
                              onChange: (val) {
                                var result = DropConverter().setDropValue(val);
                                ctrl.hospitalLocationType.value =
                                    result['name'];
                                ctrl.hospitalLocationTypeval.value =
                                    result['val'];
                                print(result['name']);
                              }),
                          SizedBox(
                            height: 20,
                          ),
                          DropDownBtn(
                            hint: ctrl.hosTypeName.value,
                            data: StaticDatas().hospitalLocaType,
                            dropItemChild: "name",
                            onChange: (val) {
                              var result = DropConverter().setDropValue(val);
                              ctrl.hosTypeName.value = result['name'];
                              ctrl.hosTypeVal.value = result['val'];
                              print(result['name']);
                            },
                            value: ctrl.hosTypeVal.value,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          TextArea(
                            hint: "Type comment...",
                            // lable: "Hospitalized Date",
                            fullLabel: true,
                            fullLabelText: "Comment",
                            borderRadius: 6,
                            textEditingController: ctrl.comment.value,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          FormFields(
                            hint: "Enter bill number",
                            fullLabel: true,
                            fullLabelText: "Hospital Bill Number",
                            borderRadius: 6,
                            textEditingController: ctrl.textControllers[5],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          DateInput(
                            hint: "dd-MM-yyyy",
                            fullLabel: true,
                            fullLabelText: "Bill Date",
                            borderRadius: 6,
                            readOnly: ctrl.clickable.value ? false : true,
                            textEditingController: ctrl.textControllers[6],
                            lightTextBox: true,
                            startDate: ctrl.startDate.value == ""
                                ? null
                                : DateTime.parse(ctrl.startDate.value),
                            endDate: DateTime.now(),
                            clickable: ctrl.clickable.value,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          FormFields(
                            hint: "Enter Amount",
                            fullLabel: true,
                            fullLabelText: "Bill Amount",
                            borderRadius: 6,
                            textEditingController: ctrl.textControllers[7],
                            textInputType: TextInputType.text,
                            textInputFormatter:
                                FilteringTextInputFormatter.singleLineFormatter,
                            showCustomMsg: false,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          FormFields(
                              readOnly: true,
                              disabled: true,
                              hint: "Enter Amount",
                              fullLabel: true,
                              fullLabelText: "Amount paid by employee",
                              borderRadius: 6,
                              textEditingController: ctrl.textControllers[7],
                              textInputType: TextInputType.text,
                              textInputFormatter: FilteringTextInputFormatter
                                  .singleLineFormatter),
                          SizedBox(
                            height: 20,
                          ),
                          Container(
                            child: Row(
                              children: [
                                // SizedBox(
                                //   width: 10,
                                // ),
                                Expanded(
                                  child: GestureDetector(
                                      onTap: () {
                                        print(ctrl.file.value);
                                        print("hello");
                                      },
                                      child: Text(
                                        "${ctrl.fileName.value}",
                                        style: TextStyle(fontSize: 16),
                                        maxLines: 1,
                                      )),
                                ),
                                // SizedBox(
                                //   width: 20,
                                // ),
                                Material(
                                  borderRadius: BorderRadius.circular(10),
                                  child: InkWell(
                                    borderRadius: BorderRadius.circular(10),
                                    onTap: () async {
                                      ctrl.selectFile();
                                    },
                                    child: Container(
                                      height: 50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                          border:
                                              Border.all(color: Colors.black12),
                                          borderRadius:
                                              BorderRadius.circular(12)),
                                      child: Center(
                                        child: Icon(
                                          Icons.add,
                                          color: Colors.black45,
                                          size: 32,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          ctrl.fileSize.value != ""
                                    ? Container(
                                        padding: EdgeInsets.all(5),
                                        // decoration: BoxDecoration(color: Colors.redAccent),
                                        child: Row(
                                          children: [
                                            Text(
                                              "File size : ${double.parse(ctrl.fileSize.value).toStringAsFixed(2)}mb",
                                              style: TextStyle(
                                                  color: const Color.fromARGB(
                                                      255, 233, 1, 1),
                                                  fontWeight: FontWeight.w600),
                                            ),
                                          ],
                                        ),
                                      )
                                    : Container()
                        ],
                      ),
                    );
                  },
                )
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        height: 80,
        decoration: BoxDecoration(color: Colors.white),
        child: Container(
          padding: EdgeInsets.fromLTRB(15, 15, 15, 10),
          child: MainButton(
            buttonLable: "Submit",
            padding: EdgeInsets.fromLTRB(30, 10, 30, 10),
            borderRadius: 7,
            onTap: () {
              var ctrl = Get.find<AddClaimController>();
              ctrl.validateForm();
            },
          ),
        ),
      ),
    );
  }
}
