import 'dart:ui';

import 'package:get/get.dart';
import 'package:sidbi_app/components/helper.dart';
import 'dart:math' as math;

class HomeController extends GetxController{
  var listTabs = [
    {
      "tabName":"PENSION SLIP/FORM 16",
    },
    {
      "tabName":"HOLIDAY HOME REIMBURSEMENT",
    },
    {
      "tabName":"CHC / OPD CLAIM",
    },
    {
      "tabName":"INDOOR HOSP REQUEST",
    },
    {
      "tabName":"TAX DECLARATION",
    },
    {
      "tabName":"HOLIDAY HOME / VOf",
    },
    {
      "tabName":"UPLOAD LIFE CERTIFICATE",
    },
    {
      "tabName":"VIEW CIRCULARS",
    },

  ].obs;
  var name = "".obs;
  var email = "".obs;
  var bagColor = Color((math.Random().nextDouble() * 0xFFFFFF).toInt()).obs;

  Helper helper = new Helper();
  var time = new DateTime.now().obs;
  var wish = "Good Morning".obs;

  setFields() async{
    name.value = await helper.getSharedPrefString(keyName: "fullName")??"Admin";
    email.value = await helper.getSharedPrefString(keyName: "emailId")??"admin";
  }

  getTimelyWish(){
    print(time.value.hour);
    if(time.value.hour > 16){
      wish.value = "Good Evening".tr;
    }
    if(time.value.hour > 11){
      wish.value = "Good Afternoon".tr;
    }
    if(time.value.hour > 5 && time.value.hour < 11){
      wish.value = "".tr;
    }
    if(time.value.hour > 18){
      wish.value = "Good Night".tr;
    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    setFields();
    getTimelyWish();
    debounce(time, (val){
      print(val);
    });

    update();
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
    setFields();
    getTimelyWish();
    debounce(time, (val){
      print(val);
    });
    update();
  }
}