import 'package:sidbi_app/components/helper.dart';

class FeedbackRepo{
  Helper helper = new Helper();

  saveFeedback() async{
    try{
      var res = helper.postService();
    }catch(e){

    }
  }
}