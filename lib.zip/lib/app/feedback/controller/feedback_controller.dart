import 'package:get/get.dart';

class FeedbackController extends GetxController{

  var selectedFeeling = "".obs;

  submitFeedback() async{

  }
}
