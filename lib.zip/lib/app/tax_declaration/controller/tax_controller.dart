import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/app/tax_declaration/model/selected_tax.dart';
import 'package:sidbi_app/app/tax_declaration/model/tax_dec_data.dart';
import 'package:sidbi_app/app/tax_declaration/model/tax_regime_data.dart';
import 'package:sidbi_app/app/tax_declaration/repo/tax_dec_repo.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/components/strings.dart';

class TaxController extends GetxController with GetTickerProviderStateMixin {
  late final AnimationController _controller =
      AnimationController(vsync: this, duration: Duration(milliseconds: 500));

  late final Animation<Offset> animation =
      Tween<Offset>(begin: Offset(0.0, 1.0), end: Offset.zero)
          .animate(_controller);

  RxList<TaxDecData> dataList = <TaxDecData>[].obs;

  RxList<SelectedTax> selUnsSetList = <SelectedTax>[].obs;
  RxList<SelectedTax> selUnsSetList2 = <SelectedTax>[].obs;

  Helper helper = new Helper();
  var btnStatus = "S".obs;

  var loading = AppLoadingState.Initial.obs;

  var amountSetController = TextEditingController().obs;
  TaxDecRepo taxDec = new TaxDecRepo();

  var showSubmit = false.obs;
  var taxregimVal = 0.obs;
  var selectedRad = 3.obs;
  var submitTaxreg = true.obs;
  var taxRegime = "O".obs;
  var selectAll = false.obs;

  selectAllData(bool val) async {
    selectAll.value = val;
    for (var i = 0; i < selUnsSetList.length; i++) {
      if (selectAll.value == true) {
        if(selUnsSetList[i].amt! > 0){
          selUnsSetList[i].selected = true;
        }

      } else {
        selUnsSetList[i].selected = false;
      }
    }
    // _controller..forward();
    selUnsSetList.refresh();
  }

  checkList({index, valGot}) {
    selUnsSetList[index].selected = valGot;
    var trueLen = selUnsSetList.where((item) => item.selected == true).length;
    if (trueLen > 0.0) {
      if(selUnsSetList[index].amt! > 0.0){
        showSubmit.value = true;
        _controller..forward();
      }else{
        helper.messageAlert(title: "Alert", message: "You can not check if amount is 0", type: AlertBoxType.Error);
      }
    } else {
      showSubmit.value = false;
      _controller..reverse();
    }
    dataList.refresh();
  }

  setAmmount({index, value, indName, innName}) {
    if(double.parse(value) > 0){
      selUnsSetList[index].amt = double.parse(value);
      selUnsSetList[index].selected = true;
    }else{
      selUnsSetList[index].amt = double.parse(value);
      if(selUnsSetList2[index].amt! > 0){
        selUnsSetList[index].selected = true;
      }else{
        selUnsSetList[index].selected = false;
      }

    }

    dataList.refresh();
    selUnsSetList.refresh();
  }

  submitData() async {
    try {
      helper.fullAppLoading();
      Map<String, String> declarationAmountMap = {};
      for (var i = 0; i < selUnsSetList.length; i++) {
        if (selUnsSetList[i].selected == true) {
          declarationAmountMap.addAll({
            "${selUnsSetList[i].ivrInvestCd.toString()}":
                "${selUnsSetList[i].amt.toString()}"
          });
        }
      }
      var res;
      print(dataList[0].submissionBtnStatus);
      if (dataList[0].submissionBtnStatus == 'U') {
        res = await taxDec.updateTaxDeclaration(taxData: declarationAmountMap);
      } else {
        res = await taxDec.submitTaxDeclaration(taxData: declarationAmountMap);
      }

      print(res.statusCode);
      var jsonRes = jsonDecode(res.body);
      if (res.statusCode == 408) {
        Get.back();
        Get.snackbar("$timeout_error_heading", "$timeout_error_msg",
            snackPosition: SnackPosition.BOTTOM);
      } else if (res.statusCode == 200) {
        print(jsonRes['message']);
        print(res.body);
        Get.back();
        // if(jsonRes['message'].toString() == "successfully saved tax declaration data!!"){
        helper.doneDialog();
        showSubmit.value = false;
        taxregimVal.value = 0;
        selectedRad.value = 3;
        submitTaxreg.value = true;
        taxRegime.value = "O";
        selectAll.value = false;
        getDeclarationList();

        // }
      } else {
        Get.back();
      }
    } catch (e) {
      print(e);
      Get.back();
    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    dataList.refresh();
    getDeclarationList();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    amountSetController.value.dispose();
  }

  getDeclarationList() async {
    try {
      loading.value = AppLoadingState.Loading;
      dataList.clear();
      selUnsSetList.clear();
      selUnsSetList2.clear();
      var res = await taxDec.getDeclarationList();
      var jsonData = jsonDecode(await res.body);
      print(jsonData);
      TaxDecData taxData = TaxDecData.fromJson(jsonData);
      dataList.add(taxData);
      dataList.refresh();
      taxRegime.value = dataList[0].itxFyOption??"N";
      if (dataList[0].itxFyOption == "N") {
        taxregimVal.value = 1;
      }
      if (dataList[0].itxFyOption == "O") {
        taxregimVal.value = 0;
      }

      submitTaxreg.value = dataList[0].taxRegimeSelected!;

      for (var i = 0; i < dataList[0].payInvestReckonerList.length; i++) {
        selUnsSetList.add(SelectedTax(
            amt: dataList[0].tmapCodeName[
                    '${dataList[0].payInvestReckonerList[i].ivrInvestCd}']![
                '${dataList[0].payInvestReckonerList[i].ivrInvestDesc}'],
            ivrInvestCd: dataList[0].payInvestReckonerList[i].ivrInvestCd,
            selected: dataList[0].tmapCodeName[
            '${dataList[0].payInvestReckonerList[i].ivrInvestCd}']![
            '${dataList[0].payInvestReckonerList[i].ivrInvestDesc}']! > 0.0 ?true:false));

        selUnsSetList2.add(SelectedTax(
            amt: dataList[0].tmapCodeName[
            '${dataList[0].payInvestReckonerList[i].ivrInvestCd}']![
            '${dataList[0].payInvestReckonerList[i].ivrInvestDesc}'],
            ivrInvestCd: dataList[0].payInvestReckonerList[i].ivrInvestCd,
            selected: dataList[0].tmapCodeName[
            '${dataList[0].payInvestReckonerList[i].ivrInvestCd}']![
            '${dataList[0].payInvestReckonerList[i].ivrInvestDesc}']! > 0.0 ?true:false));
      }

      _controller..forward();
      loading.value = AppLoadingState.Loaded;
    } catch (e) {}
  }

  saveTaxRegime() async {
    loading.value = AppLoadingState.Loading;
    var userid = await helper.getSharedPrefString(keyName: "userid");
    var userEmail = await helper.getSharedPrefString(keyName: "emailId");
    var userName = await helper.getSharedPrefString(keyName: "fullName");
    TaxRegimeData regmData = TaxRegimeData(
        applicationUsed: "M",
        userId: userid,
        taxRegime: taxRegime.value,
        userEmail: userEmail,
        userName: userName);
    var res = await taxDec.saveTaxRegime(regmData: regmData);
    if (res.statusCode == 200) {
      getDeclarationList();
    }
  }
}
