import 'package:sidbi_app/components/helper.dart';

import '../../../entities/tax_dec_entity/tax_dec_entity.dart';

import 'package:http/http.dart' as http;

import '../model/tax_regime_data.dart';

class TaxDecRepo extends TaxDecEntity{

  Helper helper = new Helper();

  @override
  getDeclarationList() async{
    var userid = await helper.getSharedPrefString(keyName: "userid");
    // var body = {
    //   "userId": "$userid"
    // };
    // var res = await helper.getStreamedService(url:"declarationOfTax/$userid",tokenRequired: true);
    var res = await helper.getService("declarationOfTax/$userid");
    return res;
  }

  @override
  submitTaxDeclaration({taxData}) async{
    var userid = await helper.getSharedPrefString(keyName: "userid");
    var data = {
      "userId":userid,
      "declarationAmountMap":taxData,
      "applicationUsed":"M"
    };
    print(data);
    var res = await helper.postService(url: "taxDeclarationSave", data: data);
    return res;
  }

  updateTaxDeclaration({taxData}) async{
    var userid = await helper.getSharedPrefString(keyName: "userid");
    var data = {
      "userId":userid,
      "declarationAmountMap":taxData,
      "applicationUsed":"M"
    };
    print(data);
    var res = await helper.postService(url: "taxDeclarationUpdate", data: data);
    return res;
  }

  @override
  saveTaxRegime({required TaxRegimeData regmData}) async{
    var data = {
      "userId": regmData.userId,
      "userName": regmData.userName,
      "userEmail": regmData.userEmail,
      "taxRegime": regmData.taxRegime,
      "applicationUsed": regmData.applicationUsed
    };
    var res = await helper.postService(url: "taxRegimeSave", data: data);
    return res;
  }

}