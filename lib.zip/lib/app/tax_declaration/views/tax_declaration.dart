import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/app/tax_declaration/controller/tax_controller.dart';
import 'package:sidbi_app/components/device_data.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/components/loading.dart';
import 'package:sidbi_app/components/main_button.dart';

class TaxDeclarationView extends StatefulWidget {
  const TaxDeclarationView({super.key});

  @override
  State<TaxDeclarationView> createState() => _TaxDeclarationViewState();
}

class _TaxDeclarationViewState extends State<TaxDeclarationView>
    with SingleTickerProviderStateMixin {
  var ctr = Get.find<TaxController>();
  Helper helper = new Helper();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        title: Text("Tax Declaration"),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: EdgeInsets.only(bottom: 100),
            child: Column(
              children: [
                GetX(
                  init: TaxController(),
                  builder: (ctrl) {
                    if (ctrl.loading == AppLoadingState.Loading) {
                      return Container();
                    } else {
                      return Container(
                        decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.onPrimary),
                        // margin: EdgeInsets.only(
                        //     left: 15, right: 15, top: 20, bottom: 20),
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
                          child: Column(
                            children: [
                              Container(
                                child: Align(
                                  child: Text(
                                    "Tax Regime",
                                    style:
                                        Theme.of(context).textTheme.bodyLarge,
                                  ),
                                  alignment: Alignment.centerLeft,
                                ),
                              ),
                              Container(
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          child: RadioMenuButton(
                                            onChanged: (val) {
                                              ctrl.taxregimVal.value = 0;
                                              ctrl.taxRegime.value = "O";
                                            },
                                            value: 0,
                                            groupValue: ctrl.taxregimVal.value,
                                            child: Text(
                                              "Old Tax",
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodyLarge,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          child: RadioMenuButton(
                                            onChanged: (val) {
                                              ctrl.taxregimVal.value = 1;
                                              ctrl.taxRegime.value = "N";
                                            },
                                            value: 1,
                                            groupValue: ctrl.taxregimVal.value,
                                            child: Text("New Tax",
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .bodyLarge),
                                          ),
                                        ),
                                      ],
                                    ),
                                    // Container(
                                    //   child: Material(
                                    //     color: Theme.of(context).colorScheme.primary,
                                    //     borderRadius: BorderRadius.circular(5),
                                    //     child: InkWell(
                                    //       child: Padding(
                                    //         padding: const EdgeInsets.all(8.0),
                                    //         child: Text(
                                    //           "Submit",
                                    //           style: TextStyle(color: Colors.white),
                                    //         ),
                                    //       ),
                                    //     ),
                                    //   ),
                                    // )
                                    MainButton(
                                      buttonLable: "Submit",
                                      borderRadius: 6,
                                      onTap: () {
                                        ctrl.saveTaxRegime();
                                      },
                                      disabled: ctrl.submitTaxreg.value,
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      );
                    }
                  },
                ),
                GetX(
                  init: TaxController(),
                  builder: (ctrl) {
                    if (ctrl.loading == AppLoadingState.Loading) {
                      return LoadingApp();
                    } else if (ctrl.dataList.length == 0) {
                      return Container();
                    } else {
                      return Column(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.onPrimary,
                                border: Border(
                                  bottom: BorderSide(
                                    color: Colors.black12,
                                  ),
                                  top: BorderSide(
                                    color: Colors.black12,
                                  ),
                                )),
                            child: CheckboxListTile(
                              value: ctrl.selectAll.value,
                              onChanged: (val) {
                                print(val);
                                ctrl.selectAllData(val!);
                              },
                              title: Text("Check all ",
                                  style: Theme.of(context).textTheme.bodyLarge),
                              controlAffinity: ListTileControlAffinity.leading,
                            ),
                          ),
                          SizedBox(height: 10),
                          ListView.builder(
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount:
                                  ctrl.dataList[0].payInvestReckonerList.length,
                              itemBuilder: (context, index) {
                                var data = ctrl
                                    .dataList[0].payInvestReckonerList[index];
                                var selectedData = ctrl.selUnsSetList[index];
                                return Container(
                                  decoration: BoxDecoration(
                                      border: Border(
                                          bottom: BorderSide(
                                              color: Colors.black12))),
                                  child: CheckboxListTile(
                                    tileColor:
                                        Theme.of(context).colorScheme.onPrimary,
                                    secondary: IconButton(
                                      style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStateProperty.all(
                                                Colors.black.withOpacity(0.05)),
                                      ),
                                      icon: Icon(
                                        Icons.edit,
                                        size: 17,
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary,
                                      ),
                                      onPressed: () {
                                        showModel(
                                            context: context,
                                            index: index,
                                            indexName: data.ivrInvestCd,
                                            innerIndexName: data.ivrInvestDesc);
                                      },
                                    ),
                                    controlAffinity:
                                        ListTileControlAffinity.leading,
                                    value: selectedData.selected,
                                    enabled: ctrl.submitTaxreg.value,
                                    onChanged:
                                        ctrl.selUnsSetList[index].amt! > 0
                                            ? (bool? value) {
                                                ctrl.checkList(
                                                    index: index,
                                                    valGot: value);
                                              }
                                            : null,
                                    title: Text(
                                      "${data.ivrInvestDesc}",
                                      style: TextStyle(color: Colors.black),
                                    ),
                                    selected: selectedData.selected!,
                                    selectedTileColor: Theme.of(context)
                                        .colorScheme
                                        .primary
                                        .withOpacity(0.2),
                                    subtitle: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            ctrl.selUnsSetList2[index].amt ==
                                                    ctrl.selUnsSetList[index]
                                                        .amt
                                                ? Container()
                                                : Text(
                                                    // "\u{20B9} ${ctrl.dataList[0].tmapCodeName["${data.ivrInvestCd}"]?["${data.ivrInvestDesc}"]??0.0}",
                                                    "\u{20B9} ${ctrl.selUnsSetList2[index].amt}",
                                                    style: TextStyle(
                                                        fontSize: 16,
                                                        color: Colors.red,
                                                        fontWeight:
                                                            FontWeight.w700),
                                                  ),
                                            SizedBox(
                                              width: ctrl.selUnsSetList2[index]
                                                          .amt ==
                                                      ctrl.selUnsSetList[index]
                                                          .amt
                                                  ? 0
                                                  : 10,
                                            ),
                                            Container(
                                              padding: EdgeInsets.all(8.0),
                                              margin: EdgeInsets.only(top: 5),
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: Colors.black12),
                                                  color: Colors.white,
                                                  borderRadius:
                                                      BorderRadius.circular(5)),
                                              child: Text(
                                                // "\u{20B9} ${ctrl.dataList[0].tmapCodeName["${data.ivrInvestCd}"]?["${data.ivrInvestDesc}"]??0.0}",
                                                "\u{20B9} ${ctrl.selUnsSetList[index].amt}",
                                                style: TextStyle(
                                                    fontSize: 16,
                                                    color: Colors.black54,
                                                    fontWeight:
                                                        FontWeight.w700),
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        (ctrl.selUnsSetList[index].amt! ==
                                                        ctrl
                                                            .selUnsSetList2[
                                                                index]
                                                            .amt &&
                                                    ctrl.selUnsSetList2[index]
                                                            .amt! >
                                                        0.0 &&
                                                    ctrl.selUnsSetList[index]
                                                            .selected ==
                                                        false) ||
                                                (ctrl.selUnsSetList2[index]
                                                            .amt! >
                                                        0 &&
                                                    ctrl.selUnsSetList[index]
                                                            .selected ==
                                                        false)
                                            ? Text(
                                                "This amount will get \u{20B9}0",
                                                style: TextStyle(
                                                    color: Colors.red,
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 15),
                                              )
                                            : Container()
                                      ],
                                    ),
                                  ),
                                );
                              }),
                        ],
                      );
                    }
                  },
                ),
              ],
            ),
          ),
          GetX(
            init: TaxController(),
            builder: (ctrl) {
              if (ctrl.loading.value == AppLoadingState.Loading) {
                return Container(height: 0);
              } else {
                return Positioned(
                  bottom: 0,
                  right: 0,
                  left: 0,
                  child: SlideTransition(
                    position: ctrl.animation,
                    child: Container(
                      height: 80,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(color: Colors.black26, blurRadius: 5)
                          ]),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(10, 15, 15, 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(
                              width: MediaQuery.of(context).size.width / 2.5,
                              child: Material(
                                color: Theme.of(context).colorScheme.primary,
                                borderRadius: BorderRadius.circular(300),
                                child: InkWell(
                                  onTap: () {
                                    var ctl = Get.find<TaxController>();
                                    ctl.submitData();
                                  },
                                  child: Center(
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Expanded(
                                          child: Text(
                                            textAlign: TextAlign.center,
                                            "Submit",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.w600,
                                                fontSize: 15),
                                          ),
                                        ),
                                        CircleAvatar(
                                          backgroundColor:
                                              Colors.white.withOpacity(0.5),
                                          child: Icon(
                                            Icons.done,
                                            color: Colors.black,
                                          ),
                                        ),
                                        SizedBox(
                                          width: 10,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              }
            },
          )
        ],
      ),
      // bottomNavigationBar: ,
    );
  }

  showModel({context, index, indexName, innerIndexName}) {
    Get.bottomSheet(StatefulBuilder(builder: (context, state) {
      return Container(
        height: 200,
        padding: EdgeInsets.fromLTRB(15, 10, 15, 20),
        child: Column(
          children: [
            SizedBox(
              height: 20,
            ),
            Container(
              child: Text(
                "Set Amount",
                style: TextStyle(fontSize: 18),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              children: [
                Expanded(
                  child: Container(
                    padding: EdgeInsets.only(left: 15, right: 15),
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: Colors.black12)),
                    child: TextField(
                      controller: ctr.amountSetController.value,
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}'))
                      ],
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: "Enter amount",
                      ),
                      keyboardType: TextInputType.number,
                      autofocus: true,
                    ),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                Material(
                  color: Theme.of(context).colorScheme.primary,
                  borderRadius: BorderRadius.circular(5),
                  child: InkWell(
                    onTap: () {
                      var ctr = Get.find<TaxController>();
                      ctr.setAmmount(
                          index: index,
                          value: ctr.amountSetController.value.text,
                          indName: indexName,
                          innName: innerIndexName);
                      ctr.amountSetController.value.clear();
                      Get.back();
                    },
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(10, 13, 10, 13),
                      child: Row(
                        children: [
                          Text(
                            "set",
                            style: TextStyle(color: Colors.white, fontSize: 17),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Icon(
                            Icons.done,
                            color: Colors.white,
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              ],
            )
          ],
        ),
      );
    }), backgroundColor: Colors.white);
  }
}
