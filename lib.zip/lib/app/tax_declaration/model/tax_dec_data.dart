class TaxDecData {
  TaxDecData({
    required this.status,
    required this.message,
    required this.itxFyOption,
    required this.payInvestReckonerList,
    required this.tmapCodeName,
    required this.taxRegimeSelected,
    required this.submissionBtnStatus
  });

  final String? status;
  final String? message;
  final String? itxFyOption;
  final List<PayInvestReckonerList> payInvestReckonerList;
  final Map<String, Map<String, double>> tmapCodeName;
  final bool? taxRegimeSelected;
  final String? submissionBtnStatus;

  factory TaxDecData.fromJson(Map<String, dynamic> json){
    return TaxDecData(
      status: json["status"],
      message: json["message"],
      itxFyOption: json["itxFyOption"],
      payInvestReckonerList: json["payInvestReckonerList"] == null ? [] : List<PayInvestReckonerList>.from(json["payInvestReckonerList"]!.map((x) => PayInvestReckonerList.fromJson(x))),
      tmapCodeName: Map.from(json["tmapCodeName"]).map((k, v) => MapEntry<String, Map<String, double>>(k, Map.from(v).map((k, v) => MapEntry<String, double>(k, v)))),
      taxRegimeSelected: json["taxRegimeSelected"],
      submissionBtnStatus : json["submissionBtnStatus"]
    );
  }

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "itxFyOption": itxFyOption,
    "payInvestReckonerList": payInvestReckonerList.map((x) => x?.toJson()).toList(),
    "tmapCodeName": Map.from(tmapCodeName).map((k, v) => MapEntry<String, dynamic>(k, Map.from(v).map((k, v) => MapEntry<String, dynamic>(k, v)))),
    "taxRegimeSelected": taxRegimeSelected,
    "submissionBtnStatus": submissionBtnStatus
  };

}

class PayInvestReckonerList {
  PayInvestReckonerList({
    required this.ivrInvestCd,
    required this.ivrFnclYear,
    required this.ivrInvestDesc,
    required this.ivrInvestAbbr,
    required this.ivrItxSecCd,
    required this.ivrStatus,
  });

  final String? ivrInvestCd;
  final DateTime? ivrFnclYear;
  final String? ivrInvestDesc;
  final String? ivrInvestAbbr;
  final String? ivrItxSecCd;
  final String? ivrStatus;

  factory PayInvestReckonerList.fromJson(Map<String, dynamic> json){
    return PayInvestReckonerList(
      ivrInvestCd: json["ivrInvestCd"],
      ivrFnclYear: DateTime.tryParse(json["ivrFnclYear"] ?? ""),
      ivrInvestDesc: json["ivrInvestDesc"],
      ivrInvestAbbr: json["ivrInvestAbbr"],
      ivrItxSecCd: json["ivrItxSecCd"],
      ivrStatus: json["ivrStatus"],
    );
  }

  Map<String, dynamic> toJson() => {
    "ivrInvestCd": ivrInvestCd,
    "ivrFnclYear": ivrFnclYear?.toIso8601String(),
    "ivrInvestDesc": ivrInvestDesc,
    "ivrInvestAbbr": ivrInvestAbbr,
    "ivrItxSecCd": ivrItxSecCd,
    "ivrStatus": ivrStatus,
  };

}
