class TaxRegimeData {
  String? userId;
  String? userName;
  String? userEmail;
  String? taxRegime;
  String? applicationUsed;

  TaxRegimeData({
    this.userId,
    this.userName,
    this.userEmail,
    this.taxRegime,
    this.applicationUsed,
  });

  TaxRegimeData copyWith({
    String? userId,
    String? userName,
    String? userEmail,
    String? taxRegime,
    String? applicationUsed,
  }) =>
      TaxRegimeData(
        userId: userId ?? this.userId,
        userName: userName ?? this.userName,
        userEmail: userEmail ?? this.userEmail,
        taxRegime: taxRegime ?? this.taxRegime,
        applicationUsed: applicationUsed ?? this.applicationUsed,
      );
}
