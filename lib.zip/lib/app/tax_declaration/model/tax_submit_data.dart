class TaxSubmitData {
  TaxSubmitData({
    required this.userId,
    required this.cbox,
    required this.declarationAmount,
    required this.applicationUsed,
  });

  final String? userId;
  final List<dynamic> cbox;
  final String? declarationAmount;
  final String? applicationUsed;

  factory TaxSubmitData.fromJson(Map<String, dynamic> json){
    return TaxSubmitData(
      userId: json["userId"],
      cbox: json["checkbox"] == null ? [] : List<String>.from(json["checkbox"]!.map((x) => x)),
      declarationAmount: json["declarationAmount"],
      applicationUsed: json["applicationUsed"],
    );
  }

  Map<String, dynamic> toJson() => {
    "userId": userId,
    "checkbox": cbox.map((x) => x).toList(),
    "declarationAmount": declarationAmount,
    "applicationUsed": applicationUsed,
  };

}
