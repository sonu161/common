class SelectedTax {
  double? amt;
  bool? selected;
  String? ivrInvestCd;

  SelectedTax({
    this.amt,
    this.selected,
    this.ivrInvestCd,
  });

  SelectedTax copyWith({
    double? amt,
    bool? selected,
    String? ivrInvestCd,
  }) =>
      SelectedTax(
        amt: amt ?? this.amt,
        selected: selected ?? this.selected,
        ivrInvestCd: ivrInvestCd ?? this.ivrInvestCd,
      );
}
