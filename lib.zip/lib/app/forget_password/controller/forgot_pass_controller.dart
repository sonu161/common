import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/app/login/views/captcha_view.dart';
import 'package:sidbi_app/app/update_password/views/update_password_views.dart';
import 'package:sidbi_app/components/comp_controllers/loading_controller.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/app/login/repos/login_repo.dart';

class ForgotPassController extends GetxController {
  var appLoadingState = AppLoadingState.Initial.obs;
  var formKey = GlobalKey<FormState>().obs;
  var refreshingState = RefreshState.Initial.obs;
  var userid = TextEditingController().obs;
  var emailAdd = TextEditingController().obs;
  var captcha = TextEditingController().obs;
  var userCaptchaInput = TextEditingController().obs;
  var emailCheck = false.obs;
  var useridCheck = false.obs;
  Helper helper = new Helper();
  LoginRepo loginrepo = new LoginRepo();
  var captchaImage = "".obs;
  var captchValue = "".obs;
  var loadingCtrl = Get.find<LoadingController>();

  checkFields() async {
    // if(userid.value.text == "" && emailAdd.value.text == ""){
    //   emailCheck.value = true;
    //   useridCheck.value = true;
    // }
    // else if(userid.value.text != "" && emailAdd.value.text == ""){
    //   emailCheck.value = true;
    //   useridCheck.value = false;
    // }
    // else if(userid.value.text == "" && emailAdd.value.text != ""){
    //   useridCheck.value = true;
    //   emailCheck.value = false;
    // }
    // else {
    //   emailCheck.value = false;
    //   useridCheck.value = false;
    //   sendResetRequest();

    // }

    final isValid = formKey.value.currentState?.validate();
    if (!isValid!) {
      return;
    } else {
      sendResetRequest();
    }
  }

  getCaptcha() async {
    try {
      appLoadingState.value = AppLoadingState.Loading;
      var resData = await loginrepo.getCaptcha();
      if (resData.statusCode == 200) {
        var jsonData = jsonDecode(resData.body);
        captchaImage.value = jsonData['captcha'];
        captchValue.value = jsonData['text'];
        print(captchValue.value);
        // captchaSheet();
        appLoadingState.value = AppLoadingState.Loaded;
      } else if (resData.statusCode == 404) {
        Get.snackbar("Network Error",
            "System is under maintenance, Please tyr after some time",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.FLOATING,
            backgroundColor: Colors.white,
            duration: Duration(seconds: 20));
        appLoadingState.value = AppLoadingState.Error;
        // captchaSheet();
      } else {
        Get.snackbar("Network Error", "${resData.body}",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.FLOATING,
            backgroundColor: Colors.white);
        appLoadingState.value = AppLoadingState.Error;
        // captchaSheet();
      }
    } catch (e) {
      Get.snackbar("Login Error",
          "Network is not reachable, please try after some time.".tr,
          colorText: Colors.red,
          snackPosition: SnackPosition.BOTTOM,
          snackStyle: SnackStyle.FLOATING,
          backgroundColor: Colors.white,
          margin: EdgeInsets.only(bottom: 10, left: 10, right: 10),
          duration: Duration(seconds: 40));
      // captchaSheet();
    }
  }

  refreshCaptcha() async {
    try {
      loadingCtrl.refreshingState.value = RefreshState.Loading;
      var resData = await loginrepo.getCaptcha();
      if (resData.statusCode == 200) {
        var jsonData = jsonDecode(resData.body);
        captchaImage.value = jsonData['captcha'];
        captchValue.value = jsonData['text'];
        loadingCtrl.refreshingState.value = RefreshState.Loaded;
      } else {
        Get.snackbar("Network Error", "${resData.body}",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.GROUNDED);
        loadingCtrl.refreshingState.value = RefreshState.Error;
        ;
      }
      print(loadingCtrl.refreshingState.value);
    } catch (e) {
      print(e);
    }
  }

  captchaSheet() {
    Get.bottomSheet(
      backgroundColor: Colors.white,
      enableDrag: true,
      isScrollControlled: false,
      SizedBox(
        height: 300,
        child: CaptchaView(
          ontap: () {
            sendResetRequest();
          },
          capTchaText: userCaptchaInput.value,
          imageBase64: captchaImage.value,
          // refresh: (){refreshCaptcha()},
        ),
      ),
    );
  }

  sendResetRequest() async {
    try {
      loadingCtrl.refreshingState.value = RefreshState.Loading;
      if (captcha.value.text == captchValue.value) {
        helper.fullAppLoading();
        loadingCtrl.refreshingState.value = RefreshState.Loading;
        var res = await loginrepo.forgotPassord(
            userid: userid.value.text,
            email: emailAdd.value.text,
            captcha: captchValue.value,
            orgCaptcha: captcha.value.text);
        print(res.body);
        var jData = json.decode(res.body);
        if (res.statusCode == 200) {
          if (jData['errorMsg'] != "success") {
            Get.back();
            helper.messageAlert(
              title: "Error",
              message: "${jData['errorMsg']}",
              type: AlertBoxType.Error,
            );
          }else{
            Get.back();
            Get.off(() => UpdatePasswordViews(), arguments: userid.value.text);
          }
          
        } else {
          Get.back();
          Get.snackbar("Network Error", "Something went wrong.".tr,
              colorText: Colors.red,
              snackPosition: SnackPosition.BOTTOM,
              snackStyle: SnackStyle.FLOATING,
              backgroundColor: Colors.white,
              margin: EdgeInsets.only(bottom: 10, left: 10, right: 10),
              duration: Duration(seconds: 40));
        }
        loadingCtrl.refreshingState.value = RefreshState.Loaded;
      } else {
        refreshCaptcha();
        helper.messageAlert(
          title: "Captcha Error",
          message: "Your captcha is not matching, please try again.".tr,
          type: AlertBoxType.Error,
        );
        
      }
    } catch (e) {}
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getCaptcha();
  }
}
