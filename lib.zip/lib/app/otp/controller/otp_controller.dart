import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/admin/admin_home/view/admin_home_view.dart';
import 'package:sidbi_app/app/home/view/home_page.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/app/login/repos/login_repo.dart';

import '../../../components/enc_helper.dart';

class OtpController extends GetxController {
  var otptextCtrl = TextEditingController().obs;
  var loading = false.obs;
  LoginRepo repo = new LoginRepo();
  Helper helper = new Helper();
  var user = "";
  var mailid = "".obs;
  Timer? timer;
  var timeShow = 20.obs;

  submitingOtp() async {
    if (otptextCtrl.value.text.length == 5) {
      // Get.to(HomePage());
      // YmwU2MVqZguglnkMB74ZPQ==
      // YmwU2MVqZguglnkMB74ZPQ==
      loading.value = true;
      var ctrl = Get.find<LogingCtrl>();
      var userid = ctrl.emailCtrl.value.text;
      var encUserid = EncHelper().encryptOtp(text:otptextCtrl.value.text);
      var res = await repo.verfiyOtp(encUserid, userid);
      print(jsonDecode(res.body));
      if (jsonDecode(res.body)['responseCode'] == "P") {
        loading.value = false;
        await helper.setSharedPrefString(keyName: "userid",value: userid);
        if(userid == "EEFC99"){
          Get.offAll(()=>AdminHomeView());
        }else{
          Get.offAll(()=>HomePage());
        }

      } 
      else if(jsonDecode(res.body)['responseCode'] == "X"){
        Get.back();
        Get.snackbar("Otp Error", "${jsonDecode(res.body)['errorMsg']}",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.FLOATING,
            backgroundColor: Colors.white,
        onTap: (sd){
          print(sd);
        });
      }
      else {
        loading.value = false;
        Get.snackbar("Otp Error", "${jsonDecode(res.body)['errorMsg']}",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.FLOATING,
            backgroundColor: Colors.white,
        onTap: (sd){
          print(sd);
        });
      }
    } else {
      loading.value = false;
    }
  }
  
  resendOtp() async{
    try{
      loading.value = true;
      var ctrl = Get.find<LogingCtrl>();
      var userid = ctrl.emailCtrl.value.text;
      var res = await repo.reSendOtp(userid);
      print("${res.body}");
      if(res.statusCode == 200){
        startTimer();
        loading.value = false;
        Get.snackbar("Message", "${jsonDecode(res.body)['successMsg']}",
            snackPosition: SnackPosition.BOTTOM,
            snackStyle: SnackStyle.FLOATING,
            backgroundColor: Colors.white,
        duration: Duration(seconds: 20));
      }

    }catch(e){
      loading.value = false;
      Get.snackbar("Otp Error", "Network not found",
          snackPosition: SnackPosition.BOTTOM,
          snackStyle: SnackStyle.FLOATING,
          backgroundColor: Colors.white);
    }
  }

  setUserId(userid) {
    user = userid;
  }

  void getMailId() async{
    mailid.value = await helper.getSharedPrefString(keyName: "emailId");
  }

  startTimer() async{
    timeShow.value = 20;
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      timeShow.value = timeShow.value-1;
      if(timeShow.value == 0){
        timer.cancel();
      }
    });
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getMailId();
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      timeShow.value = timeShow.value-1;
      if(timeShow.value == 0){
        timer.cancel();
      }
    });
  }
}
