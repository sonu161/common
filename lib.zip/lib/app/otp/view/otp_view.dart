import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:sidbi_app/components/light_button.dart';
import 'package:sidbi_app/components/load_d.dart';

import '../controller/otp_controller.dart';

class OtpPage extends StatelessWidget {
  const OtpPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary),
            child: Center(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Hero(tag: "logo", child: Container(
                      // margin: EdgeInsets.only(right: 25),
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(300)),
                          color: Colors.white,
                          gradient: RadialGradient(colors: [
                            Color(0xffffffff),
                            Color(0xffffffff),
                            Color(0xffBEE1EE),
                            Color(0xff24ACE1),
                          ])),
                      child: Center(
                        child: Image(
                          image: AssetImage("assets/images/sidbi_logo2.png"),
                          height: 40,
                          width: 40,
                        ),
                      ),
                    )),
                    SizedBox(height: 20),
                    Text("Verification Code",
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.white)),
                    SizedBox(height: 10),
                    Text("Please type verification code send",
                        style: TextStyle(fontSize: 17, color: Colors.white)),
                    GetX(
                      init: OtpController(),
                      builder: (ctrl){
                        return Text("to ${ctrl.mailid.value}",
                        style: TextStyle(fontSize: 17, color: Colors.white));
                      },
                    ),
                    SizedBox(height: 15),
                    GetX(
                      init: OtpController(),
                      builder: (ctrl){
                        return Column(
                          children: [
                            Pinput(
                              controller: ctrl.otptextCtrl.value,
                              autofocus: true,
                              keyboardType: TextInputType.number,
                              obscureText: false,
                              pinAnimationType: PinAnimationType.scale,
                              focusedPinTheme: PinTheme(
                                  height: 60,
                                  width: 60,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10)),
                                  textStyle: TextStyle(fontSize: 18)),
                              followingPinTheme: PinTheme(
                                  height: 60,
                                  width: 60,
                                  decoration: BoxDecoration(
                                      color: Colors.white24,
                                      borderRadius: BorderRadius.circular(10)),
                                  textStyle: TextStyle(fontSize: 25)),
                              defaultPinTheme: PinTheme(
                                  height: 60,
                                  width: 60,
                                  decoration: BoxDecoration(
                                      color: Colors.white24,
                                      borderRadius: BorderRadius.circular(10)),
                                  textStyle: TextStyle(color: Colors.white, fontSize: 25)),
                              length: 5,
                              onChanged: (val){
                                ctrl.submitingOtp();
                              },
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            ctrl.loading.value? LoadD():Container(height: 0,width: 0,),
                            SizedBox(
                              height: 20,
                            ),
                            Container(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  ctrl.loading.value? Container():
                                  ctrl.timeShow.value == 0?
                                  LightButton(
                                    showIcon: false,
                                    buttonLable: "Resend Otp",onTap: (){
                                    ctrl.resendOtp();
                                  },):Text("Resend in : ${ctrl.timeShow.value}s",style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold
                                  ),),
                                ],
                              ),
                            )
                          ],
                        );
                      },
                    )
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: 80,
            right: 20,
            child: IconButton(
              onPressed: (){
                Get.back();
              },
              icon: Icon(Icons.close, color: Colors.white,),
            ),
          )
        ],
      ),
    );
  }
}
