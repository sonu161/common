class ProfileData {
  ProfileData({
      this.retUpdatCredId, 
      this.userId, 
      this.userName, 
      this.firstAdd, 
      this.secondAdd, 
      this.thirdAdd, 
      this.pinCode, 
      this.email, 
      this.grade, 
      this.mobileNumber, 
      this.status, 
      this.resultStatus,});

  ProfileData.fromJson(dynamic json) {
    retUpdatCredId = json['retUpdatCredId'];
    userId = json['userId'];
    userName = json['userName'];
    firstAdd = json['firstAdd'];
    secondAdd = json['secondAdd'];
    thirdAdd = json['thirdAdd'];
    pinCode = json['pinCode'];
    email = json['email'];
    grade = json['grade'];
    mobileNumber = json['mobileNumber'];
    status = json['status'];
    resultStatus = json['resultStatus'];
  }
  num? retUpdatCredId;
  String? userId;
  String? userName;
  String? firstAdd;
  String? secondAdd;
  String? thirdAdd;
  String? pinCode;
  String? email;
  String? grade;
  num? mobileNumber;
  String? status;
  dynamic resultStatus;
ProfileData copyWith({  num? retUpdatCredId,
  String? userId,
  String? userName,
  String? firstAdd,
  String? secondAdd,
  String? thirdAdd,
  String? pinCode,
  String? email,
  String? grade,
  num? mobileNumber,
  String? status,
  dynamic resultStatus,
}) => ProfileData(  retUpdatCredId: retUpdatCredId ?? this.retUpdatCredId,
  userId: userId ?? this.userId,
  userName: userName ?? this.userName,
  firstAdd: firstAdd ?? this.firstAdd,
  secondAdd: secondAdd ?? this.secondAdd,
  thirdAdd: thirdAdd ?? this.thirdAdd,
  pinCode: pinCode ?? this.pinCode,
  email: email ?? this.email,
  grade: grade ?? this.grade,
  mobileNumber: mobileNumber ?? this.mobileNumber,
  status: status ?? this.status,
  resultStatus: resultStatus ?? this.resultStatus,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['retUpdatCredId'] = retUpdatCredId;
    map['userId'] = userId;
    map['userName'] = userName;
    map['firstAdd'] = firstAdd;
    map['secondAdd'] = secondAdd;
    map['thirdAdd'] = thirdAdd;
    map['pinCode'] = pinCode;
    map['email'] = email;
    map['grade'] = grade;
    map['mobileNumber'] = mobileNumber;
    map['status'] = status;
    map['resultStatus'] = resultStatus;
    return map;
  }

}