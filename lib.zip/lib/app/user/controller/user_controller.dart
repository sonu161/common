import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:sidbi_app/app/login/repos/login_repo.dart';
import 'package:sidbi_app/app/user/model/ProfileData.dart';
import 'package:sidbi_app/components/helper.dart';

import '../../login/controller/loging_ctrl.dart';

class UserController extends GetxController {
  var refreshingState = RefreshState.Initial.obs;
  var name = TextEditingController().obs;
  var number = TextEditingController().obs;
  var email = TextEditingController().obs;
  var pin_code = TextEditingController().obs;
  var first_address = TextEditingController().obs;
  var second_address = TextEditingController().obs;
  var last_address = TextEditingController().obs;

  Helper helper = new Helper();
  LoginRepo repo = new LoginRepo();
  ProfileData? data;

  getUserDetail() async {
    helper.fullAppLoading();
    refreshingState.value = RefreshState.Loading;
    try {
      var res = await repo.getUserDetail();
      if (res.statusCode == 200) {
        Get.back();
        print(json.decode(res.body));
        if (json.decode(res.body) == "" ||
            json.decode(res.body) == [] ||
            json.decode(res.body) == "[]" ||
            json.decode(res.body).length == 0) {
          refreshingState.value = RefreshState.Error;
        } else {
          var decodeData = json.decode(res.body);
          data = ProfileData.fromJson(decodeData);
          name.value.text = data!.userName!;
          number.value.text = data!.mobileNumber.toString();
          email.value.text = data!.email!;
          pin_code.value.text = data!.pinCode!;
          first_address.value.text = data!.firstAdd!;
          second_address.value.text = data!.secondAdd!;
          last_address.value.text = data!.thirdAdd!;
          refreshingState.value = RefreshState.Loaded;
        }
      }
    } catch (e) {
      refreshingState.value = RefreshState.Error;
    }
  }

  updateData() async {
    try {
      print("hello");
      // refreshingState.value = RefreshState.Loading;
      helper.fullAppLoading();
      var payLoad = ProfileData(
          userId: data!.userId!,
          userName: name.value.text,
          mobileNumber: int.parse(number.value.text),
          email: email.value.text,
          pinCode: pin_code.value.text,
          firstAdd: first_address.value.text,
          secondAdd: second_address.value.text,
          thirdAdd: last_address.value.text,
          grade: data!.grade,
          retUpdatCredId: data!.retUpdatCredId,
          status: data!.status);
      var res = await repo.updateUserDetail(payLoad);
      if (res.statusCode == 200) {
        Get.back();
        helper.doneDialog(msg: "Your request for profile data up-dation has been submitted successfully, details will be updated after approval from eefc cell.");
      } else {
        Get.back();
      }
    } catch (e) {
      // refreshingState.value = RefreshState.Loaded;
      Get.back();
    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
    getUserDetail();
  }
}
