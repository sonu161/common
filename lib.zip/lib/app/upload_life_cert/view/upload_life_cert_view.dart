import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/app/upload_life_cert/controller/upload_life_cert_controller.dart';
import 'package:sidbi_app/components/date_input.dart';
import 'package:sidbi_app/components/input_field.dart';
import 'package:sidbi_app/components/load_d.dart';
import 'package:sidbi_app/components/main_button.dart';

class UploadLifeCertView extends StatelessWidget {
  const UploadLifeCertView({super.key});

  @override
  Widget build(BuildContext context) {
    return UploadLifeCertViewLoader();
  }
}

class UploadLifeCertViewLoader extends StatefulWidget {
  const UploadLifeCertViewLoader({super.key});

  @override
  State<UploadLifeCertViewLoader> createState() =>
      _UploadLifeCertViewLoaderState();
}

class _UploadLifeCertViewLoaderState extends State<UploadLifeCertViewLoader> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.onBackground,
      appBar: AppBar(
        title: Text(
          "Upload Life certificate".tr,
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.only(top: 20),
        child: Container(
          margin: EdgeInsets.only(left: 15, right: 15),
          padding: EdgeInsets.only(top: 20, bottom: 20, left: 20, right: 20),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)]),
          child: GetX(
            init: UploadLifeCertController(),
            builder: (ctrl) {
              return Column(
                children: [
                  SizedBox(
                    height: 40,
                  ),
                  Text("Upload form".tr,
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: Colors.black54)),
                  SizedBox(
                    height: 40,
                  ),
                  Column(
                    children: [
                      // Container(
                      //   decoration: BoxDecoration(
                      //       border: Border(
                      //         top: BorderSide(color: Colors.black12),
                      //         left: BorderSide(color: Colors.black12),
                      //         right: BorderSide(color: Colors.black12),
                      //       ),
                      //       borderRadius: BorderRadius.only(
                      //           topLeft: Radius.circular(5),
                      //           topRight: Radius.circular(5))),
                      //   child: TextField(
                      //     decoration: InputDecoration(
                      //         contentPadding: EdgeInsets.only(
                      //             left: 15, right: 15, top: 10, bottom: 10),
                      //         border: UnderlineInputBorder(
                      //             borderSide: BorderSide(
                      //                 color:
                      //                     Theme.of(context).colorScheme.primary)),
                      //         hintText: "Enter your name here",
                      //         label: Text("Employee Name")),
                      //   ),
                      // ),
                      InputField(
                        hint: "Enter Name".tr,
                        borderRadius: 6,
                        fullLabel: true,
                        fullLabelText: "Employee Name".tr,
                        textEditingController: ctrl.empname.value,
                        readOnly: true,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      DateInput(
                        hint: "DD/MM/YYYY",
                        textEditingController: ctrl.dobCtrl.value,
                        readOnly: true,
                        fullLabelText: "Date of birth".tr,
                        fullLabel: true,
                        borderRadius: 6,
                        disabled: true,
                        clickable: false,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      InputField(
                        hint: "Year".tr,
                        borderRadius: 6,
                        fullLabel: true,
                        fullLabelText: "Year".tr,
                        textEditingController: ctrl.year.value,
                        readOnly: true,
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      filePicker(
                          fileName: "${ctrl.fileId}",
                          onatap: () {
                            ctrl.selectFile();
                          },
                          selected: ctrl.file.value.path == "" ? false : true,
                          file: ctrl.file.value),
                      ctrl.fileSize.value != ""
                          ? Container(
                              padding: EdgeInsets.all(5),
                              // decoration: BoxDecoration(color: Colors.redAccent),
                              child: Row(
                                children: [
                                  Text(
                                    "File size : ${double.parse(ctrl.fileSize.value).toStringAsFixed(2)}mb",
                                    style: TextStyle(
                                        color: const Color.fromARGB(
                                            255, 233, 1, 1),
                                        fontWeight: FontWeight.w600),
                                  ),
                                ],
                              ),
                            )
                          : Container(),

                      // SizedBox(
                      //   height: 30,
                      // ),
                      // Container(
                      //   child: Column(
                      //     children: [
                      //       Row(
                      //         children: [
                      //           GestureDetector(
                      //             child: Container(
                      //               padding: EdgeInsets.only(
                      //                 left: 20,
                      //                 right: 20
                      //               ),
                      //               decoration: BoxDecoration(
                      //                 color: Theme.of(context).colorScheme.primary,
                      //                 borderRadius: BorderRadius.circular(5)
                      //               ),
                      //               child: Row(
                      //                 mainAxisAlignment: MainAxisAlignment.center,
                      //                 children: [
                      //                   Text("View Last uploaded file",style: TextStyle(color: Colors.white),),
                      //                   IconButton(
                      //                     onPressed: (){},
                      //                     icon: Icon(Icons.open_in_full,color: Colors.white,)
                      //                   )
                      //                 ],
                      //               ),
                      //             ),
                      //           ),
                      //         ],
                      //       ),
                      //     ],
                      //   ),
                      // )
                    ],
                  )
                ],
              );
            },
          ),
        ),
      ),
      bottomNavigationBar: Container(
        height: 80,
        decoration: BoxDecoration(color: Colors.white),
        child: Container(
          padding: EdgeInsets.fromLTRB(10, 15, 15, 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.only(left: 10),
                child: GetX<UploadLifeCertController>(
                  init: UploadLifeCertController(),
                  builder: (ctrl) {
                    if (ctrl.loading.value == AppLoadingState.Loading) {
                      return SizedBox(
                        // width: 30,
                        // height: 30,
                        child: LoadD(),
                      );
                    } else {
                      if (ctrl.fileName.value != "") {
                        return MainButton(
                          buttonLable: "View Last File",
                          warnState: true,
                          onTap: (){
                            ctrl.downloadFile(fileName: ctrl.fileName.value);
                          },
                        );
                      } else {
                        return Container();
                      }
                    }
                  },
                ),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width / 2.5,
                child: Material(
                  color: Theme.of(context).colorScheme.primary,
                  borderRadius: BorderRadius.circular(300),
                  child: InkWell(
                    onTap: () {
                      var ctrl = Get.find<UploadLifeCertController>();
                      ctrl.uploadLifeCert();
                    },
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 10,
                          ),
                          Expanded(
                            child: Text(
                              textAlign: TextAlign.center,
                              "Upload File",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 15),
                            ),
                          ),
                          CircleAvatar(
                            backgroundColor: Colors.white.withOpacity(0.5),
                            child: Icon(
                              Icons.chevron_right,
                              color: Colors.black,
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget filePicker({onatap, fileName, selected, File? file}) {
    return GestureDetector(
      onTap: () {
        if (file?.path == "") {
        } else {
          // Get.to(() => PdfViewPage(), arguments: file!.uri.path);
        }
      },
      child: Container(
        padding: EdgeInsets.only(left: selected == true ? 10 : 20),
        decoration: BoxDecoration(
            border: Border.all(color: Color(0xffF3F3F3)),
            borderRadius: BorderRadius.circular(10),
            color: Color(0xffFAFAFA)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Row(
                children: [
                  selected == true
                      ? GestureDetector(
                          onTap: () {
                            // var ctrl = Get.find<HolidayReimbController>();
                            // ctrl.removeFile(file: file!);
                          },
                          child: CircleAvatar(
                            maxRadius: 15,
                            minRadius: 15,
                            backgroundColor: Colors.transparent,
                            child: Icon(
                              Icons.picture_as_pdf,
                              color: Colors.green,
                            ),
                          ),
                        )
                      : Container(),
                  SizedBox(
                    width: selected == true ? 10 : 0,
                  ),
                  Flexible(
                    child: Text(
                      textAlign: TextAlign.left,
                      "$fileName",
                      style: TextStyle(fontSize: 16),
                      maxLines: 1,
                    ),
                  ),
                ],
              ),
            ),
            Material(
              borderRadius: BorderRadius.circular(10),
              child: InkWell(
                borderRadius: BorderRadius.circular(10),
                //
                onTap: onatap,
                child: Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.black12),
                      borderRadius: BorderRadius.circular(12)),
                  child: Center(
                    child: Icon(
                      Icons.add,
                      color: Colors.black45,
                      size: 32,
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
