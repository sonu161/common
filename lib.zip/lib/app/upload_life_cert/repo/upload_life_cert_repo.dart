import 'dart:convert';
import 'dart:io';

import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/entities/upload_life_cert_entity/upload_life_cert_entity.dart';
import 'package:sidbi_app/network/app_config.dart';
import 'package:http/http.dart' as http;

class UploadLifeCertRepo extends UploadLifeCertEntity {
  Helper helper = new Helper();

  @override
  uploadLifeCert({String? filepath}) async {
    try {
      var logUserid = await helper.getSharedPrefString(keyName: "userid");
      var empName = await helper.getSharedPrefString(keyName: "fullName");
      var dobs = await helper.getSharedPrefString(keyName: "empDOB");
      var addr = await helper.getSharedPrefString(keyName: "empAddress");
      var email = await helper.getSharedPrefString(keyName: "emailId");
      var dataa = {
        "userName": "$empName",
        "userId": "$logUserid",
        "userDOB": "$dobs",
        "userAddress": "$addr",
        "userEmail": "$email",
        "year": new DateTime.now().year.toString(),
        "applicationUsed": "M",
        "message": ""
      };
      print(dataa);
      var res = await helper.postFormField(
          url: "lifecertificateFileUpload",
          data: dataa,
          path: filepath,
          fileKey: "file");
      return res;
    } catch (e) {}
  }

  getLastFile() async {
    var userid = await helper.getSharedPrefString(keyName: "userid");
    var url = "lifecertificate/$userid";
    var res = await helper.getService(url);
    return res;
  }

  @override
  downloadFile({fileName}) async {
    // try {
      var userid = await helper.getSharedPrefString(keyName: "userid");
      var url = "downloadPdfMobile/$userid";
    //   var file = await helper.downloadPdfFile(
    //       url: url,
    //       setFileName: fileName,
    //       type: "GET",
    //       data: {"fileName": "$fileName"});
    //   return file;
    // } catch (e) {}

      try{
      var token = await Helper().getSharedPrefString(keyName: "token");
    // var url = userid == "EEFC99"?"adminDownloadPensionPdfMobile/${userid}":"downloadPDF";
    var headers = {
      'Authorization':'Bearer $token',
      'Content-Type': 'application/json'
    };
    // Uri.parse(""
    // var request = http.Request('POST',
    //     Uri.parse('http://172.30.1.235:8080/newretireeportal/downloadPDF'));
    print("${config?[baseUrl]}$url");
    var request = http.Request('GET',
        Uri.parse('${config?[baseUrl]}$url'));
    // request.body = json.encode({
    //   "userId": pensData.userId,
    //   "year": pensData.year,
    //   "optionList": pensData.listOption,
    //   "month": pensData.month.toString().toLowerCase()
    // });

    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();
    var res = await http.Response.fromStream(response);

    if (res.statusCode == 200) {
      final Directory? appDir = Platform.isAndroid
            ? await getExternalStorageDirectory()
            : await getApplicationDocumentsDirectory();
        // var dir = await getExternalStorageDirectory();
        // var direct = dir?.path
          // .toString()
          // .replaceAll("Android/data/com.sidbi.retireesidbiportal/files", "Download");
        if(appDir == null){
          print("Directory is not avilable");
          return null;
        }
        final String direct = Platform.isAndroid
            ?appDir.path.toString()
          .replaceAll("Android/data/com.sidbi.retireesidbiportal/files", "Download"):appDir.path;
        final String fileNames =
            "$fileName";
        File file = new File('$direct/$fileNames');

        if (await file.exists()) {
          await file.create();
        }
        var list = await res.bodyBytes;
        // Uint8List bytes = await Uint8List.fromList(list);
        print(list);
        await file.writeAsBytes(list);
        return file;
    } else {
      print(res.reasonPhrase);
    }
    }catch(e){
      Get.back();
      Helper().messageAlert(title: "Error", message: "$e", type: AlertBoxType.Error);
    }
  }
}
