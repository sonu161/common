import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/app/upload_life_cert/repo/upload_life_cert_repo.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/components/pdf_view.dart';
import 'package:sidbi_app/entities/upload_life_cert_entity/upload_life_cert_entity.dart';

class UploadLifeCertController extends GetxController{
  UploadLifeCertRepo repo = UploadLifeCertRepo();
  var loading = AppLoadingState.Initial.obs;
  var empname = TextEditingController().obs;
  var dobCtrl = TextEditingController().obs;
  var year = TextEditingController().obs;
  Helper helper = new Helper();
  var fileName = "".obs;

  var fileSize = "".obs;
  var fileId = "File(.pdf) file (1mb)".obs;
  var file = new File("").obs;

  selectFile({selector}) async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['jpg', 'pdf', 'doc'],
        allowMultiple: true);
    result?.files.first.bytes;
    if (result!.files.first.name.toString().split(".")[1] != "pdf") {
      Helper().messageAlert(
          title: "File error",
          message: "Please select .pdf file",
          type: AlertBoxType.Error);
    } else {
      List<File> files = result!.paths.map((path) => File(path!)).toList();
      fileId.value = result.files.first.name.toString();
      file.value = files.first;
      fileSize.value = ((await file.value.length()) / 1000000).toString();
    }
  }

  uploadLifeCert() async {
    try {
      if (file.value.path == "") {
        helper.messageAlert(
            title: "Error",
            message: 'Please Select the file',
            type: AlertBoxType.Error);
      } 
      else if(await file.value.length() > 1000000){
        helper.messageAlert(
            title: "Information",
            message: "file is exceeding 1mb, please check",
            type: AlertBoxType.Error);
      }
      else {
        helper.fullAppLoading();
        var res = await repo.uploadLifeCert(filepath: file.value.path);
        // if(res.statusCode == 200){
        Get.back();
        print(jsonDecode(res));
        if(jsonDecode(res)['response'] == "P"){
          helper.doneDialog(
            msg: "${jsonDecode(res)['message']}",
            onClose: () {
              Get.back();
            });
        }else{
          helper.messageAlert(
            title: "Information",
            message: "${jsonDecode(res)['message']}",
            type: AlertBoxType.Error);
        }
        
        
      }

      // }
    } catch (e) {}
  }

  setFields() async {
    var empName = await helper.getSharedPrefString(keyName: "fullName");
    var dobs = await helper.getSharedPrefString(keyName: "empDOB");
    empname.value.text = empName ?? "";
    dobCtrl.value.text = dobs ?? "";
    year.value.text = new DateTime.now().year.toString();
  }

  getLastFile() async{
    try{
      // helper.fullAppLoading();
      loading.value = AppLoadingState.Loading;
      final res = await repo.getLastFile();
      final jdata = json.decode(res.body);
      if(jdata['fileName'] != ""){
        // Get.back();
        loading.value = AppLoadingState.Loaded;
        fileName.value = jdata['fileName'];
      }else{
        loading.value = AppLoadingState.Loaded;
        // Get.back();
      }
    }catch(e){
      loading.value = AppLoadingState.Loaded;
    }
  }

  downloadFile({fileName}) async{
    try{
      var res = await repo.downloadFile(fileName: fileName);
      try{
        // Get.back();
        Get.to(() => PdfViewPage(), arguments: res.uri.path);
      }catch(e){
        // Get.back();
        helper.messageAlert(title: "Error", message: "Some error occurred", type: AlertBoxType.Error);
      }
    }catch(e){

    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    setFields();
    getLastFile();
  }
}
