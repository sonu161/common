import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:sidbi_app/app/claims/controller/claim_ctrl.dart';
import 'package:sidbi_app/app/login/repos/static_datas.dart';
import 'package:sidbi_app/app/view_image.dart';
import 'package:sidbi_app/components/date_input.dart';
import 'package:sidbi_app/components/drop_converter.dart';
import 'package:sidbi_app/components/drop_down_btn.dart';
import 'package:sidbi_app/components/form_field.dart';

import '../../../components/helper.dart';
import '../../pension_slip/controller/pensionsl_controller.dart';

class ClaimForm extends StatefulWidget {
  const ClaimForm({super.key});

  @override
  State<ClaimForm> createState() => _ClaimFormState();
}

class _ClaimFormState extends State<ClaimForm> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text('CHC Claim'),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.only(top: 20),
          child: Container(
            margin: EdgeInsets.only(left: 15, right: 15),
            padding: EdgeInsets.only(top: 20, bottom: 20, left: 20, right: 20),
            decoration: BoxDecoration(
              color: Colors.white,
              // borderRadius: BorderRadius.circular(15),
              // boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)]),
            ),
            child: Column(
              children: [
                // SizedBox(
                //   height: 40,
                // ),
                // Text("CHC / OPD Claim",
                //     style: TextStyle(
                //         fontSize: 18,
                //         fontWeight: FontWeight.w700,
                //         color: Colors.black54)),
                // SizedBox(
                //   height: 40,
                // ),
                GetX(
                  init: ClaimController(),
                  builder: (ctrl) {
                    return Form(
                      key: ctrl.formKey.value,
                      child: Column(
                        children: [
                          DropDownBtn(
                            hint: ctrl.selcClimType.value,
                            data: StaticDatas().claimType,
                            dropItemChild: "name",
                            value: ctrl.selcClimTypeValue.value,
                            onChange: (val) {
                              var result = DropConverter().setDropValue(val);
                              ctrl.selcClimType.value = result['name'];
                              ctrl.selcClimTypeValue.value = result['val'];
                            },
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          FormFields(
                              hint: ctrl.retireeName.value,
                              textEditingController: ctrl.retireeEmpName.value,
                              borderRadius: 5,
                              disabled: true,
                              readOnly: true,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          DropDownBtn(
                            hint: ctrl.selfDependent.value,
                            data: StaticDatas().selfDepType,
                            dropItemChild: "name",
                            value: ctrl.selfDependentValue.value,
                            onChange: (val) {
                              var result = DropConverter().setDropValue(val);
                              ctrl.selfDependent.value = result['name'];
                              ctrl.selfDependentValue.value = result['val'];
                              if(ctrl.selfDependentValue.value == "E"){
                                ctrl.retireeEmpName.value.text = ctrl.retireeName.value;
                              }else{}
                            },
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          FormFields(
                              hint: "Self/Spouse Name",
                              textEditingController: ctrl.depSpName.value,
                              borderRadius: 5),
                          SizedBox(
                            height: 20,
                          ),
                          // Container(
                          //   decoration: BoxDecoration(
                          //       border: Border(
                          //         top: BorderSide(color: Colors.black12),
                          //         left: BorderSide(color: Colors.black12),
                          //         right: BorderSide(color: Colors.black12),
                          //       ),
                          //       borderRadius: BorderRadius.only(
                          //           topLeft: Radius.circular(5),
                          //           topRight: Radius.circular(5))),
                          //   child: TextField(
                          //     readOnly: true,
                          //     onTap: () {
                          //       var helper = Get.find<Helper>();
                          //       var ctrl = Get.find<PayController>();
                          //       helper.calenderShow(
                          //           controller: ctrl.datePicController.value,
                          //           context: context);
                          //     },
                          //     decoration: InputDecoration(
                          //       contentPadding: EdgeInsets.only(
                          //           left: 15, right: 15, top: 10, bottom: 10),
                          //       border: UnderlineInputBorder(),
                          //       hintText: "DD/MM/YYYY",
                          //       label: Text("CHC Date"),
                          //       suffix: Material(
                          //         child: InkWell(
                          //           onTap: () async {
                          //             // var helper = Get.find<Helper>();
                          //             // helper.calenderShow(controller: ctrl.datepicController.value);
                          //           },
                          //           child: Icon(Icons.calendar_month),
                          //         ),
                          //       ),
                          //     ),
                          //     keyboardType: TextInputType.datetime,
                          //   ),
                          // ),

                          DateInput(
                            hint: "dd/MM/yyyy",
                            fullLabel: true,
                            fullLabelText: "Bill Date",
                            borderRadius: 6,
                            readOnly: true,
                            textEditingController: ctrl.chcDate.value,
                            lightTextBox: true,
                            endDate: DateTime.now(),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          FormFields(
                            hint: "Amount to be paid",
                            textEditingController: ctrl.amtPaid.value,
                            borderRadius: 5,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          GetX(
                            init: ClaimController(),
                            builder: (ctrl) {
                              return Container(
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: GestureDetector(
                                          onTap: () {
                                            print(ctrl.file.value);
                                            // if(ctrl.file.value != null){
                                            print("hello");
                                            Get.to(ViewImage(),
                                                arguments: ctrl.file.value);
                                            // }else{
                                            //   print("hello");
                                            // }
                                          },
                                          child: Text(
                                            "${ctrl.fileName.value}",
                                            style: TextStyle(
                                                fontSize: 16,
                                                overflow:
                                                    TextOverflow.ellipsis),
                                            maxLines: 1,
                                          )),
                                    ),
                                    Material(
                                      borderRadius: BorderRadius.circular(10),
                                      child: InkWell(
                                        borderRadius: BorderRadius.circular(10),
                                        onTap: () async {
                                          ctrl.selectFile();
                                        },
                                        child: Container(
                                          height: 50,
                                          width: 50,
                                          decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: Colors.black12),
                                              borderRadius:
                                                  BorderRadius.circular(12)),
                                          child: Center(
                                            child: Icon(
                                              Icons.add,
                                              color: Colors.black45,
                                              size: 32,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                          // SizedBox(
                          //   height: 20,
                          // ),
                          ctrl.fileSize.value != ""? Container(
                            padding: EdgeInsets.all(5),
                            // decoration: BoxDecoration(color: Colors.redAccent),
                            child: Row(
                              children: [
                                Text(
                                    "File size : ${double.parse(ctrl.fileSize.value).toStringAsFixed(2)}mb",style: TextStyle(color: const Color.fromARGB(255, 233, 1, 1),fontWeight: FontWeight.w600),),
                              ],
                            ),
                          ):Container()
                        ],
                      ),
                    );
                  },
                )
              ],
            ),
          ),
        ),
        bottomNavigationBar: Container(
          height: 80,
          decoration: BoxDecoration(color: Colors.white),
          child: Container(
            padding: EdgeInsets.fromLTRB(10, 15, 15, 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                SizedBox(
                  width: MediaQuery.of(context).size.width / 2.5,
                  child: Material(
                    color: Theme.of(context).colorScheme.primary,
                    borderRadius: BorderRadius.circular(300),
                    child: InkWell(
                      onTap: () {
                        var ctrl = Get.find<ClaimController>();
                        ctrl.validateForm();
                      },
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 10,
                            ),
                            Expanded(
                              child: Text(
                                textAlign: TextAlign.center,
                                "Submit",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 15),
                              ),
                            ),
                            CircleAvatar(
                              backgroundColor: Colors.white.withOpacity(0.5),
                              child: Icon(
                                Icons.done,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ));
  }
}
