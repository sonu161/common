import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/holiday_vof/controller/holiday_data_controller.dart';
import 'package:sidbi_app/app/holiday_vof/holiday_vof_repo.dart';
import 'package:sidbi_app/app/holiday_vof/model/UtilityData.dart';
import 'package:sidbi_app/components/helper.dart';

class UtilityController extends GetxController {
  var formKey = GlobalKey<FormState>().obs;
  var strtDate = TextEditingController().obs;
  var endDateCtrl = TextEditingController().obs;
  var city = TextEditingController().obs;
  var utilityCharge = TextEditingController().obs;
  var remark = TextEditingController().obs;
  var test = "".obs;
  final cityGet;
  final appIdGet;
  var appId = "".obs;
  final strDt;
  final endDt;
  var fileSize = "".obs;
  var fileId = "File(.pdf) file (1mb)".obs;
  var file = new File("").obs;

  var submBtn = "Submit".obs;

  var charge;
  var remarks;

  HolidayVofRepo repo = new HolidayVofRepo();
  UtilityController({this.cityGet,this.appIdGet, this.strDt, this.endDt,this.charge,this.remarks});
  Helper helper = new Helper();
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    city.value.text = this.cityGet;
    appId.value = this.appIdGet;
    strtDate.value.text = this.strDt;
    endDateCtrl.value.text = this.endDt;
    
    utilityCharge.value.text = this.charge??"";
    remark.value.text = this.remarks??"";

    if(this.charge != null){
      submBtn.value = "Update";
    }
  }

  void validateForm({appType}) {
    final isValid = formKey.value.currentState?.validate();
    if (!isValid!) {
      // submitForm();
      return;
    } else {
      checkTexts();
    }
    formKey.value.currentState?.save();
  }

  checkTexts() async{
    helper.fullAppLoading();
    
    var rctrl = Get.find<HolidayDataController>();
    var userid = await helper.getSharedPrefString(keyName: "userid");
    var salCode = await helper.getSharedPrefString(keyName: "salaryCode");
    UtilityData data = UtilityData(
      applNumber: appId.value,
      applicationUsed: "M",
      userId: userid,
      utilityCharges: utilityCharge.value.text,
      utilityRemark: remark.value.text,
      salaryCode : salCode
    );
    print(data.toJson());
    var res = await repo.submitUtility(data: data,filepath: file.value.path);
    print(jsonDecode(res));
    try{
    Get.back();
    if(jsonDecode(res)['responseCode'] == "P"){
        await rctrl.getdata();
          helper.doneDialog(
              msg: "${jsonDecode(res)['message']}",
              onClose: () {
                Get.back();
                Get.back();
              });
    }else{
      helper.messageAlert(
              title: "Message",
              message: "${jsonDecode(res)['message']}",
              type: AlertBoxType.Error);
    }
    }catch(e){
      Get.back();
      helper.messageAlert(
              title: "Message",
              message: "Something went wrong",
              type: AlertBoxType.Error);
    }

    // 
  }

  selectFile({selector}) async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        allowMultiple: true);
    result?.files.first.bytes;
  //   Uint8List? bytes = result!.files.first.bytes;
  //   final PdfDocument document = PdfDocument(inputBytes: bytes);
  //   String content = PdfTextExtractor(document).extractText();
  // print("Sonu : "+content);
    if (result!.files.first.name.toString().split(".")[1] != "pdf") {
      Helper().messageAlert(
          title: "File error",
          message: "Please select .pdf file",
          type: AlertBoxType.Error);
    } else {
      List<File> files = result.paths.map((path) => File(path!)).toList();
      fileId.value = result.files.first.name.toString();
      file.value = files.first;
      // FileAuthCheck(file: await file.value.readAsBytes());
      fileSize.value = ((await file.value.length()) / 1000000).toString();
    }
  }

}