import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sidbi_app/admin/admin_home/model/AdminVofHomListData.dart';
import 'package:sidbi_app/app/holiday_vof/controller/holiday_data_controller.dart';
import 'package:sidbi_app/app/holiday_vof/holiday_vof_repo.dart';
import 'package:sidbi_app/app/holiday_vof/model/HolidayHomeModel.dart';
import 'package:sidbi_app/app/holiday_vof/model/HolidayVofModel.dart';
import 'package:sidbi_app/app/holiday_vof/model/SaveHolidayVofModel.dart';
import 'package:sidbi_app/components/helper.dart';

import '../../login/controller/loging_ctrl.dart';

class HolidayVofController extends GetxController {
  var formKey = GlobalKey<FormState>().obs;
  var startDateCtrl = TextEditingController().obs;
  var endDateCtrl = TextEditingController().obs;
  var startTimeCtrl = TextEditingController().obs;
  var endTimeCtrl = TextEditingController().obs;
  var numberOfRooms = TextEditingController().obs;
  var numberOfPeople = TextEditingController().obs;
  var contactField = TextEditingController().obs;
  var descCtrl = TextEditingController().obs;
  var opted = false.obs;

  var selectedType;

  var loading = AppLoadingState.Initial.obs;
  var purpose = "Select Purpose".obs;
  var selcPurposeValue = "".obs;

  HolidayVofRepo repo = new HolidayVofRepo();
  var dataPush = HolidayVofModel().obs;
  var holidayHomeData = HolidayHomeModel().obs;
  var adminHolidayHomeData = AdminVofHomListData().obs;
  Helper helper = new Helper();
  var startDate = "".obs;
  var clickable = false.obs;
  var validEndTime = false.obs;
  var age = 30.obs;
  var appType;

  HolidayVofController({this.selectedType,this.appType});


  bool checkDateFuture({date}){
    DateTime dateToday = new DateTime.now();
    DateTime newDate = DateTime.parse(date);
    // var newDate = new DateFormat().parse(date);
    print("Sonu : ${newDate.isAfter(dateToday)}");
    return newDate.isAfter(dateToday);
  }

  get selectType{
    return selectedType;
  }

  set setType(type){
    this.selectedType = type;
  }

  void validateForm({appType}) {
    final isValid = formKey.value.currentState?.validate();
    if (!isValid!) {
      // submitForm();
      return;
    } else {
      submitForm(appType: appType);
    }
    formKey.value.currentState?.save();
  }

  void checkVedidator() {
    final isValid = formKey.value.currentState?.validate();
    if (!isValid!) {
      // submitForm();
      return;
    } else {}
    formKey.value.currentState?.save();
  }

  getBookings() async {
    try {
      loading.value = AppLoadingState.Loading;
      var res = await repo.getBookings(appType: this.appType);
      print(jsonDecode(res.body));
      // print(adminHolidayHomeData.value.hhVofHisList!.first.startDate);
      if (res.statusCode == 200) {
        var data = jsonDecode(res.body);
        var userFor = await helper.getSharedPrefString(keyName: "userFor");
        if (userFor != null) {
          adminHolidayHomeData.value = AdminVofHomListData.fromJson(data);
        } else {
          dataPush.value = HolidayVofModel.fromJson(data);
        }
        // print(adminHolidayHomeData.value.hhVofHisList!.first.startDate);
        loading.value = AppLoadingState.Loaded;
      }
    } catch (e) {
      loading.value = AppLoadingState.Error;
      print(e);
    }
  }

  getRefresh() async {
    try {
      var res = await repo.getBookings();
      if (res.statusCode == 200) {
        var data = jsonDecode(res.body);
        dataPush.value = HolidayVofModel.fromJson(data);
        print(dataPush.value.vofHHBookingList!.first.startDate);
      }
    } catch (e) {
      print(e);
    }
  }

  getHolidayHomeList() async {
    try {
      loading.value = AppLoadingState.Loading;
      var res = await repo.getHolidayHomeData();
      if (res.statusCode == 200) {
        var data = jsonDecode(res.body);
        holidayHomeData.value = HolidayHomeModel.fromJson(data);
        loading.value = AppLoadingState.Loaded;
      }
    } catch (e) {}
  }

  submitForm({appType}) async {
    try {
      helper.fullAppLoading();
      var userid = await helper.getSharedPrefString(keyName: "userid");
      var empName = await helper.getSharedPrefString(keyName: "fullName");
      var email = await helper.getSharedPrefString(keyName: "emailId");
      var formDataCtrl = Get.find<HolidayDataController>();
      var hhList = "${formDataCtrl.selectedKey}-${formDataCtrl.selectedVal}";
      var holidayVofCheck = appType; 
      // selectedType.value == 0 ? "hh" : "vf";
      var data = SaveHolidayVofModel(
          applicationUsed: "M",
          message: "",
          userId: "$userid",
          empName: "$empName",
          userEmail: "$email",
          endDate: "${await formateDate(data: endDateCtrl.value.text)}",
          startDate: "${await formateDate(data: startDateCtrl.value.text)}",
          contactNumber: "${contactField.value.text}",
          description: "${descCtrl.value.text}",
          endTime: "${endTimeCtrl.value.text}",
          hhListVal: appType == "hh" ? "$hhList" : "",
          holidayhome: "$holidayVofCheck",
          noOfPeople: "${numberOfPeople.value.text}",
          noOfRooms: "${numberOfRooms.value.text}",
          purpose: "${selcPurposeValue.value}",
          startTime: "${startTimeCtrl.value.text}",
          vofListVal: appType == "vf" ? "$hhList" : "");
      print(data.toJson());

      var res = await repo.submitForm(data: data);
      if (res.statusCode == 200) {
        print(jsonDecode(res.body));
        if (jsonDecode(res.body)['responseCode'] == "P") {
          getRefresh();
          Get.back();
          helper.doneDialog(
              msg: "${jsonDecode(res.body)['message']}",
              onClose: () {
                Get.back();
                Get.back();
              });
        } else {
          getRefresh();
          Get.back();
          helper.messageAlert(
              title: "Message",
              message: "${jsonDecode(res.body)['message']}",
              type: AlertBoxType.Error);
        }
        // helper.messageAlert(title: "Message", message: "${jsonDecode(res.body)['message']}", type: AlertBoxType.Success);
      }
    } catch (e) {
      Get.back();
      helper.messageAlert(
          title: "Error",
          message: "Something went wrong, Try again",
          type: AlertBoxType.Error,
          duration: Duration(seconds: 25));
    }
  }

  formateDate({data}) async {
    var dateF = await DateFormat("dd-MM-yyyy").parse(data.toString());
    var day = "${dateF.year}-${dateF.month}-${dateF.day}";
    print("formate : $day");
    return day.toString();
  }

  cancelVfHhBooking({formid}) async {
    var helper = Get.find<Helper>();
    helper.appDialogBox(
        message: "Are you sure you want cancel the booking ?".tr,
        title: "Confirm Cancellation".tr,
        onTap: () async {
          helper.fullAppLoading();
          var res = await repo.cancelHHVfBooking(formId: formid);
          print(jsonDecode(res.body));
          if (jsonDecode(res.body)['status'] == null) {
            print(res);
            getRefresh();
            Get.back();
            helper.messageAlert(
                title: "Information",
                message: "Sucessfully cancelled your booking",
                type: AlertBoxType.Error);
          } else {
            helper.messageAlert(
                title: "Information",
                message: "${jsonDecode(res.body)['message']}",
                type: AlertBoxType.Error);
          }
        });
  }

  endDateListener() async {
    endTimeCtrl.value.addListener(() {
      if (endTimeCtrl.value.text != "") {
        if (startDateCtrl.value.text == endDateCtrl.value.text) {
          var strTimeH = startTimeCtrl.value.text.split(":")[0];
          var strTimeM = startTimeCtrl.value.text.split(":")[1];
          var endTimeH = endTimeCtrl.value.text.split(":")[0];
          var endTimeM = endTimeCtrl.value.text.split(":")[1];
          if (int.parse(strTimeH) > int.parse(endTimeH)) {
            validEndTime.value = false;
          } else if (int.parse(strTimeH) == int.parse(endTimeH) &&
              int.parse(strTimeM) > int.parse(endTimeM)) {
            validEndTime.value = false;
          } else {
            validEndTime.value = true;
          }
        } else {
          validEndTime.value = true;
        }
      }
    });
    startTimeCtrl.value.addListener(() {
      if (startDateCtrl.value.text != "" && endTimeCtrl.value.text != "") {
        if (startDateCtrl.value.text == endDateCtrl.value.text) {
          var strTimeH = startTimeCtrl.value.text.split(":")[0];
          var strTimeM = startTimeCtrl.value.text.split(":")[1];
          var endTimeH = endTimeCtrl.value.text.split(":")[0];
          var endTimeM = endTimeCtrl.value.text.split(":")[1];
          if (int.parse(strTimeH) > int.parse(endTimeH)) {
            validEndTime.value = false;
          } else if (int.parse(strTimeH) == int.parse(endTimeH) &&
              int.parse(strTimeM) > int.parse(endTimeM)) {
            validEndTime.value = false;
          } else {
            validEndTime.value = true;
          }
        } else {
          validEndTime.value = true;
        }
      }
    });
    endDateCtrl.value.addListener(() {
      if (startDateCtrl.value.text != endDateCtrl.value.text) {
        validEndTime.value = true;
      } else {
        validEndTime.value = false;
      }
    });
  }

  getAge() async {
    try {
      var res = await repo.getAge();
      print(jsonDecode(res.body));
      final jData = jsonDecode(res.body);
      if (jData['retireeAge'] != null) {
        age.value = int.parse(jData['retireeAge']);
        if (age.value > 59) {
          opted.value = true;
        }
      }
    } catch (e) {
      helper.messageAlert(
          title: "Error", message: "$e", type: AlertBoxType.Error);
    }
  }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getBookings();
    endDateListener();
    getAge();
    startDateCtrl.value.addListener(() {
      if (startDateCtrl.value.text == "") {
        clickable.value = false;
      } else {
        endDateCtrl.value.clear();
        startDate.value =
            DateFormat("dd-MM-yyyy").parse(startDateCtrl.value.text).toString();
        clickable.value = true;
      }
    });
  }
}
