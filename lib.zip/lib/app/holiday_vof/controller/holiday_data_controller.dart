import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/holiday_vof/holiday_vof_repo.dart';
import 'package:sidbi_app/app/holiday_vof/model/HolidayHomeModel.dart';
import 'package:sidbi_app/app/holiday_vof/model/VOFModel.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';

class HolidayDataController extends GetxController{
  var loading = AppLoadingState.Initial.obs;
  var formKey = GlobalKey<FormState>().obs;
  var dropHint = "Select Location".obs;

  HolidayVofRepo repo = new HolidayVofRepo();


  var vofData = VofModel().obs;
  var holidayHomeData = HolidayHomeModel().obs;

  var selectedVal = "".obs;
  var selectedKey = "".obs;
  var lists = <Map<String,String>>[].obs;
  var vofList = <Map<String,String>>[].obs;
  List da = [];
  getHolidayHomeList() async{
    try{
      var res = await repo.getHolidayHomeData();
      if(res.statusCode == 200){
        var data = jsonDecode(res.body);
        holidayHomeData.value = HolidayHomeModel.fromJson(data);
        for(var i =0; i<holidayHomeData.value.holiHomeMap!.length;i++){
          lists.add(
              {
                "name":"${holidayHomeData.value.holiHomeMap![i].name}",
                "val":"${holidayHomeData.value.holiHomeMap![i].id}"
              }
          );
        }

      }
    }catch(e){

    }
  }

  getVofList() async{
    try{
      var res = await repo.getVofData();
      if(res.statusCode == 200){
        var data = jsonDecode(res.body);
        vofData.value = VofModel.fromJson(data);
        for(var i =0; i<vofData.value.vofMap!.length;i++){
          vofList.add(
              {
                "name":"${vofData.value.vofMap![i].name}",
                "val":"${vofData.value.vofMap![i].id}"
              }
          );
        }
      }
    }catch(e){

    }
  }

  getdata() async{
    // loading.value = AppLoadingState.Loading;
    // getHolidayHomeList();
    // getVofList();
    // loading.value = AppLoadingState.Loaded;
    loading.value = AppLoadingState.Loading;
    List<Future<void>> future = [getHolidayHomeList(),getVofList()];
    await future.wait;
    loading.value = AppLoadingState.Loaded;
  }



  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getdata();
  }
}