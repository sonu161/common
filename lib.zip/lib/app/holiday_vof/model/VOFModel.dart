class VofModel {
  VofModel({
      this.status, 
      this.message, 
      this.holiHomeMap, 
      this.vofHHBookingList, 
      this.removedVOFHHBooking, 
      this.applicationUsed, 
      this.httpStatus, 
      this.responseCode, 
      this.vofMap,});

  VofModel.fromJson(dynamic json) {
    status = json['status'];
    message = json['message'];
    holiHomeMap = json['holiHomeMap'];
    vofHHBookingList = json['vofHHBookingList'];
    removedVOFHHBooking = json['removedVOFHHBooking'];
    applicationUsed = json['applicationUsed'];
    httpStatus = json['httpStatus'];
    responseCode = json['responseCode'];
    if (json['vofMap'] != null) {
      vofMap = [];
      json['vofMap'].forEach((v) {
        vofMap?.add(VofMap.fromJson(v));
      });
    }
  }
  String? status;
  String? message;
  dynamic holiHomeMap;
  dynamic vofHHBookingList;
  dynamic removedVOFHHBooking;
  dynamic applicationUsed;
  String? httpStatus;
  String? responseCode;
  List<VofMap>? vofMap;
VofModel copyWith({  String? status,
  String? message,
  dynamic holiHomeMap,
  dynamic vofHHBookingList,
  dynamic removedVOFHHBooking,
  dynamic applicationUsed,
  String? httpStatus,
  String? responseCode,
  List<VofMap>? vofMap,
}) => VofModel(  status: status ?? this.status,
  message: message ?? this.message,
  holiHomeMap: holiHomeMap ?? this.holiHomeMap,
  vofHHBookingList: vofHHBookingList ?? this.vofHHBookingList,
  removedVOFHHBooking: removedVOFHHBooking ?? this.removedVOFHHBooking,
  applicationUsed: applicationUsed ?? this.applicationUsed,
  httpStatus: httpStatus ?? this.httpStatus,
  responseCode: responseCode ?? this.responseCode,
  vofMap: vofMap ?? this.vofMap,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['message'] = message;
    map['holiHomeMap'] = holiHomeMap;
    map['vofHHBookingList'] = vofHHBookingList;
    map['removedVOFHHBooking'] = removedVOFHHBooking;
    map['applicationUsed'] = applicationUsed;
    map['httpStatus'] = httpStatus;
    map['responseCode'] = responseCode;
    if (vofMap != null) {
      map['vofMap'] = vofMap?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class VofMap {
  VofMap({
      this.id, 
      this.name,});

  VofMap.fromJson(dynamic json) {
    id = json['id'];
    name = json['name'];
  }
  String? id;
  String? name;
VofMap copyWith({  String? id,
  String? name,
}) => VofMap(  id: id ?? this.id,
  name: name ?? this.name,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    return map;
  }

}