class HolidayHomeModel {
  HolidayHomeModel({
      this.status, 
      this.message, 
      this.holiHomeMap, 
      this.vofHHBookingList, 
      this.removedVOFHHBooking, 
      this.applicationUsed, 
      this.httpStatus, 
      this.responseCode, 
      this.vofMap,});

  HolidayHomeModel.fromJson(dynamic json) {
    status = json['status'];
    message = json['message'];
    if (json['holiHomeMap'] != null) {
      holiHomeMap = [];
      json['holiHomeMap'].forEach((v) {
        holiHomeMap?.add(HoliHomeMap.fromJson(v));
      });
    }
    vofHHBookingList = json['vofHHBookingList'];
    removedVOFHHBooking = json['removedVOFHHBooking'];
    applicationUsed = json['applicationUsed'];
    httpStatus = json['httpStatus'];
    responseCode = json['responseCode'];
    vofMap = json['vofMap'];
  }
  String? status;
  String? message;
  List<HoliHomeMap>? holiHomeMap;
  dynamic vofHHBookingList;
  dynamic removedVOFHHBooking;
  dynamic applicationUsed;
  String? httpStatus;
  String? responseCode;
  dynamic vofMap;
HolidayHomeModel copyWith({  String? status,
  String? message,
  List<HoliHomeMap>? holiHomeMap,
  dynamic vofHHBookingList,
  dynamic removedVOFHHBooking,
  dynamic applicationUsed,
  String? httpStatus,
  String? responseCode,
  dynamic vofMap,
}) => HolidayHomeModel(  status: status ?? this.status,
  message: message ?? this.message,
  holiHomeMap: holiHomeMap ?? this.holiHomeMap,
  vofHHBookingList: vofHHBookingList ?? this.vofHHBookingList,
  removedVOFHHBooking: removedVOFHHBooking ?? this.removedVOFHHBooking,
  applicationUsed: applicationUsed ?? this.applicationUsed,
  httpStatus: httpStatus ?? this.httpStatus,
  responseCode: responseCode ?? this.responseCode,
  vofMap: vofMap ?? this.vofMap,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['message'] = message;
    if (holiHomeMap != null) {
      map['holiHomeMap'] = holiHomeMap?.map((v) => v.toJson()).toList();
    }
    map['vofHHBookingList'] = vofHHBookingList;
    map['removedVOFHHBooking'] = removedVOFHHBooking;
    map['applicationUsed'] = applicationUsed;
    map['httpStatus'] = httpStatus;
    map['responseCode'] = responseCode;
    map['vofMap'] = vofMap;
    return map;
  }

}

class HoliHomeMap {
  HoliHomeMap({
      this.id, 
      this.name,});

  HoliHomeMap.fromJson(dynamic json) {
    id = json['id'];
    name = json['name'];
  }
  String? id;
  String? name;
HoliHomeMap copyWith({  String? id,
  String? name,
}) => HoliHomeMap(  id: id ?? this.id,
  name: name ?? this.name,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['name'] = name;
    return map;
  }

}