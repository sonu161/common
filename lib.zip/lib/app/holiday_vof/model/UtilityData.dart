class UtilityData {
  UtilityData({
      this.userId, 
      this.applNumber, 
      this.utilityCharges, 
      this.utilityRemark, 
      this.applicationUsed, 
      this.salaryCode,});

  UtilityData.fromJson(dynamic json) {
    userId = json['userId'];
    applNumber = json['applNumber'];
    utilityCharges = json['utilityCharges'];
    utilityRemark = json['utilityRemark'];
    applicationUsed = json['applicationUsed'];
    salaryCode = json['salaryCode'];
  }
  String? userId;
  String? applNumber;
  String? utilityCharges;
  String? utilityRemark;
  String? applicationUsed;
  String? salaryCode;
UtilityData copyWith({  String? userId,
  String? applNumber,
  String? utilityCharges,
  String? utilityRemark,
  String? applicationUsed,
  String? salaryCode
}) => UtilityData(  userId: userId ?? this.userId,
  applNumber: applNumber ?? this.applNumber,
  utilityCharges: utilityCharges ?? this.utilityCharges,
  utilityRemark: utilityRemark ?? this.utilityRemark,
  applicationUsed: applicationUsed ?? this.applicationUsed, 
  salaryCode: salaryCode ?? this.salaryCode,
);
  Map<String, String> toJson() {
    final map = <String, String>{};
    map['userId'] = userId!;
    map['applNumber'] = applNumber!;
    map['utilityCharges'] = utilityCharges!;
    map['utilityRemark'] = utilityRemark!;
    map['applicationUsed'] = applicationUsed!;
    map['salaryCode'] = salaryCode!;
    return map;
  }

}