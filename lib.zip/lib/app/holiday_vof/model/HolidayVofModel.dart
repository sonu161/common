class HolidayVofModel {
  HolidayVofModel({
      this.status, 
      this.message, 
      this.holiHomeMap, 
      this.vofHHBookingList, 
      this.removedVOFHHBooking, 
      this.applicationUsed, 
      this.httpStatus, 
      this.responseCode, 
      this.vofMap,});

  HolidayVofModel.fromJson(dynamic json) {
    status = json['status'];
    message = json['message'];
    holiHomeMap = json['holiHomeMap'];
    if (json['vofHHBookingList'] != null) {
      vofHHBookingList = [];
      json['vofHHBookingList'].forEach((v) {
        vofHHBookingList?.add(VofHhBookingList.fromJson(v));
      });
    }
    removedVOFHHBooking = json['removedVOFHHBooking'];
    applicationUsed = json['applicationUsed'];
    httpStatus = json['httpStatus'];
    responseCode = json['responseCode'];
    vofMap = json['vofMap'];
  }
  String? status;
  String? message;
  dynamic holiHomeMap;
  List<VofHhBookingList>? vofHHBookingList;
  dynamic removedVOFHHBooking;
  dynamic applicationUsed;
  String? httpStatus;
  String? responseCode;
  dynamic vofMap;
HolidayVofModel copyWith({  String? status,
  String? message,
  dynamic holiHomeMap,
  List<VofHhBookingList>? vofHHBookingList,
  dynamic removedVOFHHBooking,
  dynamic applicationUsed,
  String? httpStatus,
  String? responseCode,
  dynamic vofMap,
}) => HolidayVofModel(  status: status ?? this.status,
  message: message ?? this.message,
  holiHomeMap: holiHomeMap ?? this.holiHomeMap,
  vofHHBookingList: vofHHBookingList ?? this.vofHHBookingList,
  removedVOFHHBooking: removedVOFHHBooking ?? this.removedVOFHHBooking,
  applicationUsed: applicationUsed ?? this.applicationUsed,
  httpStatus: httpStatus ?? this.httpStatus,
  responseCode: responseCode ?? this.responseCode,
  vofMap: vofMap ?? this.vofMap,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['message'] = message;
    map['holiHomeMap'] = holiHomeMap;
    if (vofHHBookingList != null) {
      map['vofHHBookingList'] = vofHHBookingList?.map((v) => v.toJson()).toList();
    }
    map['removedVOFHHBooking'] = removedVOFHHBooking;
    map['applicationUsed'] = applicationUsed;
    map['httpStatus'] = httpStatus;
    map['responseCode'] = responseCode;
    map['vofMap'] = vofMap;
    return map;
  }

}

class VofHhBookingList {
  VofHhBookingList({
      this.srNumber, 
      this.applType, 
      this.bookingPlace, 
      this.startDate, 
      this.startTime, 
      this.endDate, 
      this.endTime, 
      this.remark, 
      this.status, 
      this.applNumber, 
      this.empId, 
      this.bookingStatus, 
      this.mailSentStatus, 
      this.numberOfPeople, 
      this.numberOfRoom,});

  VofHhBookingList.fromJson(dynamic json) {
    srNumber = json['srNumber'];
    applType = json['applType'];
    bookingPlace = json['bookingPlace'];
    startDate = json['startDate'];
    startTime = json['startTime'];
    endDate = json['endDate'];
    endTime = json['endTime'];
    remark = json['remark'];
    status = json['status'];
    applNumber = json['applNumber'];
    empId = json['empId'];
    bookingStatus = json['bookingStatus'];
    mailSentStatus = json['mailSentStatus'];
    numberOfPeople = json['numberOfPeople'];
    numberOfRoom = json['numberOfRoom'];
  }
  String? srNumber;
  String? applType;
  String? bookingPlace;
  String? startDate;
  String? startTime;
  String? endDate;
  String? endTime;
  String? remark;
  String? status;
  String? applNumber;
  String? empId;
  String? bookingStatus;
  String? mailSentStatus;
  String? numberOfPeople;
  String? numberOfRoom;
VofHhBookingList copyWith({  String? srNumber,
  String? applType,
  String? bookingPlace,
  String? startDate,
  String? startTime,
  String? endDate,
  String? endTime,
  String? remark,
  String? status,
  String? applNumber,
  String? empId,
  String? bookingStatus,
  String? mailSentStatus,
  String? numberOfPeople,
  String? numberOfRoom,
}) => VofHhBookingList(  srNumber: srNumber ?? this.srNumber,
  applType: applType ?? this.applType,
  bookingPlace: bookingPlace ?? this.bookingPlace,
  startDate: startDate ?? this.startDate,
  startTime: startTime ?? this.startTime,
  endDate: endDate ?? this.endDate,
  endTime: endTime ?? this.endTime,
  remark: remark ?? this.remark,
  status: status ?? this.status,
  applNumber: applNumber ?? this.applNumber,
  empId: empId ?? this.empId,
  bookingStatus: bookingStatus ?? this.bookingStatus,
  mailSentStatus: mailSentStatus ?? this.mailSentStatus,
  numberOfPeople: numberOfPeople ?? this.numberOfPeople,
  numberOfRoom: numberOfRoom ?? this.numberOfRoom,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['srNumber'] = srNumber;
    map['applType'] = applType;
    map['bookingPlace'] = bookingPlace;
    map['startDate'] = startDate;
    map['startTime'] = startTime;
    map['endDate'] = endDate;
    map['endTime'] = endTime;
    map['remark'] = remark;
    map['status'] = status;
    map['applNumber'] = applNumber;
    map['empId'] = empId;
    map['bookingStatus'] = bookingStatus;
    map['mailSentStatus'] = mailSentStatus;
    map['numberOfPeople'] = numberOfPeople;
    map['numberOfRoom'] = numberOfRoom;
    return map;
  }

}