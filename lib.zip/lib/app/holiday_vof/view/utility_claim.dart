import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/holiday_vof/controller/utility_controller.dart';
import 'package:sidbi_app/components/date_input.dart';
import 'package:sidbi_app/components/form_field.dart';
import 'package:sidbi_app/components/main_button.dart';
import 'package:sidbi_app/components/text_area.dart';
// vf // hh
class UtilityClaimPage extends StatelessWidget {
  final String appNo;
  final String appType;
  final String city;
  final String startDate;
  final String endDate;
  final String? charge;
  final String? remarks;
  const UtilityClaimPage({super.key, required this.appNo,
  required this.appType,required this.city,
  required this.startDate, required this.endDate, this.charge, this.remarks});

  @override
  Widget build(BuildContext context) {
    return UtilityClaimLoader(appNo: this.appNo,appType: this.appType,
    city: this.city,startDate: this.startDate,endDate: this.endDate,charge: this.charge,remarks: this.remarks,);
  }
}

class UtilityClaimLoader extends StatefulWidget {
  final String appNo;
  final String appType;
  final String city;
  final String startDate;
  final String endDate;
  final String? charge;
  final String? remarks;
  const UtilityClaimLoader({super.key,required this.appNo,required this.appType,
  required this.city,
  required this.startDate, required this.endDate, this.charge, this.remarks});

  @override
  State<UtilityClaimLoader> createState() => _UtilityClaimLoaderState();
}

class _UtilityClaimLoaderState extends State<UtilityClaimLoader> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "${widget.appType} - ${widget.appNo}"
        ),
      ),
      body: SingleChildScrollView(
          padding: EdgeInsets.only(top: 20, bottom: 20),
          child: Container(
            margin: EdgeInsets.only(left: 15, right: 15),
            padding: EdgeInsets.only(top: 20, bottom: 20, left: 20, right: 20),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)]),
            child: Column(
              children: [
                GetX(
                  init: UtilityController(cityGet: widget.city,
                  appIdGet: widget.appNo,
                  strDt: widget.startDate,
                  endDt: widget.endDate,
                  charge: widget.charge,
                  remarks: widget.remarks
                ),
                  builder: (ctrl) {
                    return Form(
                      key: ctrl.formKey.value,
                      child: Column(
                        children: [
                           Column(
                                  children: [
                                    SizedBox(
                                      height: 20,
                                    ),
                                    FormFields(
                                      hint: "dd-MM-yyyy",
                                      fullLabel: true,
                                      fullLabelText: "Start Date",
                                      borderRadius: 6,
                                      readOnly: true,
                                      disabled: true,
                                      lightTextBox: true,
                                      textEditingController:
                                          ctrl.strtDate.value,
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    FormFields(
                                      hint: "dd-MM-yyyy",
                                      fullLabel: true,
                                      fullLabelText: "End Date",
                                      borderRadius: 6,
                                      readOnly: true,
                                      disabled: true,
                                      textEditingController:
                                          ctrl.endDateCtrl.value
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    FormFields(
                                      hint: "Enter City",
                                      fullLabelText: "City",
                                      fullLabel: true,
                                      borderRadius: 6,
                                      textEditingController:
                                          ctrl.city.value,
                                      textInputType: TextInputType.number,
                                      readOnly: true,
                                      disabled: true,
                                    ),
                                    SizedBox(
                                      height:20 
                                    ),
                                    FormFields(
                                      hint: "Enter Charges",
                                      fullLabelText: "Utility Charges",
                                      fullLabel: true,
                                      borderRadius: 6,
                                      textInputType: TextInputType.number,
                                      textEditingController:
                                          ctrl.utilityCharge.value
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    filePicker(
                                      fileName: "${ctrl.fileId}",
                                      onatap: () {
                                        ctrl.selectFile();
                                      },
                                      selected: ctrl.file.value.path == "" ? false : true,
                                      file: ctrl.file.value
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    TextArea(
                                        hint: "Write here...",
                                        borderRadius: 6,
                                        fullLabel: true,
                                        fullLabelText: "Remarks",
                                        textEditingController:
                                            ctrl.remark.value),
                                  ],
                                ),
                            // builder: (ctrl) {
                                
                            //   }
                          
                        ],
                      ),
                    );
                  },
                )
              ],
            ),
          ),
        ),

      bottomNavigationBar: GetX(
          init: UtilityController(),
          builder: (ctrl) {
            print(ctrl.test.value);
              return Container(
                height: 80,
                padding: EdgeInsets.fromLTRB(10, 15, 15, 10),
                decoration: BoxDecoration(color: Colors.white),
                child: Row(
                  children: [
                     Flexible(child: Container(),flex: 1,),
                    Flexible(
                      flex: 1,
                      child: MainButton(
                        buttonLable: ctrl.submBtn.value,
                        onTap : (){
                          ctrl.validateForm();
                        }  
                      ),
                      ),
                     
                  ],
                ),
              );
            }
      )
    );
  }

  Widget filePicker({onatap, fileName, selected, File? file}) {
    return GestureDetector(
      onTap: () {
        if (file?.path == "") {
        } else {
          // Get.to(() => PdfViewPage(), arguments: file!.uri.path);
        }
      },
      child: Container(
        padding: EdgeInsets.only(left: selected == true ? 10 : 20),
        decoration: BoxDecoration(
            border: Border.all(color: Color(0xffF3F3F3)),
            borderRadius: BorderRadius.circular(10),
            color: Color(0xffFAFAFA)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Row(
                children: [
                  selected == true
                      ? GestureDetector(
                          onTap: () {
                            // var ctrl = Get.find<HolidayReimbController>();
                            // ctrl.removeFile(file: file!);
                          },
                          child: CircleAvatar(
                            maxRadius: 15,
                            minRadius: 15,
                            backgroundColor: Colors.transparent,
                            child: Icon(
                              Icons.picture_as_pdf,
                              color: Colors.green,
                            ),
                          ),
                        )
                      : Container(),
                  SizedBox(
                    width: selected == true ? 10 : 0,
                  ),
                  Flexible(
                    child: Text(
                      textAlign: TextAlign.left,
                      "$fileName",
                      style: TextStyle(fontSize: 16),
                      maxLines: 1,
                    ),
                  ),
                ],
              ),
            ),
            Material(
              borderRadius: BorderRadius.circular(10),
              child: InkWell(
                borderRadius: BorderRadius.circular(10),
                //
                onTap: onatap,
                child: Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.black12),
                      borderRadius: BorderRadius.circular(12)),
                  child: Center(
                    child: Icon(
                      Icons.add,
                      color: Colors.black45,
                      size: 32,
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}