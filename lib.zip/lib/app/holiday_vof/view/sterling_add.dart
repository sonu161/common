import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/holiday_vof/controller/holiday_data_controller.dart';
import 'package:sidbi_app/app/holiday_vof/controller/holiday_vof_controller.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/comp_controllers/input_controller.dart';
import 'package:sidbi_app/components/drop_converter.dart';
import 'package:sidbi_app/components/drop_down_btn.dart';
import 'package:sidbi_app/components/form_field.dart';
import 'package:sidbi_app/components/loading.dart';
import 'package:sidbi_app/components/main_button.dart';
import 'package:sidbi_app/components/text_area.dart';
import 'package:sidbi_app/components/time_picker.dart';

import '../../../components/date_input.dart';
import '../../login/repos/static_datas.dart';

class AddSterlingPage extends StatefulWidget {
  const AddSterlingPage({super.key});

  @override
  State<AddSterlingPage> createState() => _AddSterlingState();
}

class _AddSterlingState extends State<AddSterlingPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Visiting Officer Flat"),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.only(top: 20, bottom: 20),
          child: Container(
            margin: EdgeInsets.only(left: 15, right: 15),
            padding: EdgeInsets.only(top: 20, bottom: 20, left: 20, right: 20),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)]),
            child: Column(
              children: [
                // SizedBox(
                //   height: 20,
                // ),
                // Container(
                //   child: Row(
                //     children: [
                //       Container(
                //         child: RadioMenuButton(
                //           onChanged: (val){
                //             print(val);
                //           },
                //           value: 0,
                //           groupValue: "taxregime",
                //           child: Text("Holiday Home"),
                //         ),
                //       ),
                //       Container(
                //         child: RadioMenuButton(
                //           onChanged: (val){},
                //           value: 1,
                //           groupValue: "taxregime",
                //           child: Text("Visiting Officer flat"),
                //         ),
                //       ),
                //
                //     ],
                //   ),
                // ),
                // SizedBox(
                //   height: 10,
                // ),

                GetX(
                  init: HolidayVofController(selectedType: 1),
                  builder: (ctrl) {
                    return Form(
                      key: ctrl.formKey.value,
                      child: Column(
                        children: [
                          // RadioListTile(
                          //   contentPadding: EdgeInsets.zero,
                          //   title: Text(
                          //     "Holiday Home",
                          //     style:
                          //         TextStyle(color: Colors.green, fontSize: 16),
                          //     softWrap: true,
                          //   ),
                          //   groupValue: 0,
                          //   value: ctrl.selectedType.value,
                          //   activeColor: Colors.green,
                          //   onChanged: (val) {
                          //     var dropCtrl = Get.find<HolidayDataController>();
                          //     if (val == 1) {
                          //       ctrl.selectedType.value = 0;
                          //       if (dropCtrl.dropHint.value == "Select VOF") {
                          //         dropCtrl.dropHint.value =
                          //             "Select Holiday Home";
                          //       } else {
                          //         dropCtrl.selectedVal.value = "";
                          //         dropCtrl.selectedKey.value = "";
                          //         dropCtrl.dropHint.value =
                          //             "Select Holiday Home";
                          //       }
                          //     }
                          //   },
                          // ),
                          // RadioListTile(
                          //   contentPadding: EdgeInsets.zero,
                          //   title: Text(
                          //     "Visiting Officer flat",
                          //     style:
                          //         TextStyle(color: Colors.green, fontSize: 16),
                          //     softWrap: true,
                          //   ),
                          //   groupValue: 1,
                          //   value: ctrl.selectedType.value,
                          //   activeColor: Colors.green,
                          //   onChanged: (val) {
                          //     var dropCtrl = Get.find<HolidayDataController>();
                          //     if (val == 0) {
                          //       ctrl.selectedType.value = 1;

                          //       // if (dropCtrl.dropHint.value ==
                          //       //     "Select Holiday Home") {
                          //       //   dropCtrl.dropHint.value = "Select VOF";
                          //       // } else {
                          //         dropCtrl.selectedVal.value = "";
                          //         dropCtrl.selectedKey.value = "";
                          //         dropCtrl.dropHint.value = "Select VOF";
                          //       }
                          //     // }
                          //   },
                          // ),
                          // SizedBox(
                          //   height: 20,
                          // ),
                          GetX(
                            init: HolidayDataController(),
                            builder: (holidayCtrl) {
                              if (holidayCtrl.loading ==
                                  AppLoadingState.Loading) {
                                return LoadingApp();
                              } else {
                                return Column(
                                  children: [
                                    // ctrl.selectedType.value == 0
                                    //     ? DropDownBtn(
                                    //         hint: holidayCtrl.dropHint.value,
                                    //         data: holidayCtrl.lists.toJson(),
                                    //         dropItemChild: "name",
                                    //         onChange: (val) {
                                    //           var result = DropConverter()
                                    //               .setDropValue(val);
                                    //           holidayCtrl.dropHint.value =
                                    //               result['name'];
                                    //           holidayCtrl.selectedVal.value =
                                    //               result['name'];
                                    //           holidayCtrl.selectedKey.value =
                                    //               result['val'];
                                    //           print(holidayCtrl
                                    //               .selectedKey.value);
                                    //         })
                                    //     : 
                                        DropDownBtn(
                                            hint: holidayCtrl.dropHint.value,
                                            data: holidayCtrl.vofList.toJson(),
                                            dropItemChild: "name",
                                            onChange: (val) {
                                              var result = DropConverter()
                                                  .setDropValue(val);
                                              holidayCtrl.dropHint.value =
                                                  result['name'];
                                              holidayCtrl.selectedVal.value =
                                                  result['name'];
                                              holidayCtrl.selectedKey.value =
                                                  result['val'];
                                              print(holidayCtrl
                                                  .selectedKey.value);
                                            }),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    DateInput(
                                      hint: "dd-MM-yyyy",
                                      fullLabel: true,
                                      fullLabelText: "Start Date",
                                      borderRadius: 6,
                                      readOnly: true,
                                      textEditingController:
                                          ctrl.startDateCtrl.value,
                                      lightTextBox: true,
                                      startDate: DateTime.now(),
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    DateInput(
                                      hint: "dd-MM-yyyy",
                                      fullLabel: true,
                                      fullLabelText: "End Date",
                                      borderRadius: 6,
                                      readOnly: true,
                                      disabled: ctrl.clickable.value,
                                      textEditingController:
                                          ctrl.endDateCtrl.value,
                                      startDate: ctrl.clickable.value
                                          ? DateTime.parse(ctrl.startDate.value)
                                          : null,
                                      clickable: ctrl.clickable.value,
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    TimeInput(
                                      hint: "HH:MM",
                                      readOnly: true,
                                      fullLabel: true,
                                      fullLabelText: "Start Time",
                                      borderRadius: 6,
                                      textEditingController:
                                          ctrl.startTimeCtrl.value,
                                      internationalTime: true,
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    TimeInput(
                                      hint: "HH:MM",
                                      readOnly: true,
                                      fullLabel: true,
                                      fullLabelText: "End Time",
                                      borderRadius: 6,
                                      textEditingController:
                                          ctrl.endTimeCtrl.value,
                                      internationalTime: true,
                                      timeValid: ctrl.validEndTime.value,
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    FormFields(
                                      hint: "Enter Number",
                                      fullLabelText: "Number of rooms",
                                      fullLabel: true,
                                      borderRadius: 6,
                                      textEditingController:
                                          ctrl.numberOfRooms.value,
                                      textInputType: TextInputType.number,
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    FormFields(
                                      hint: "Enter Number",
                                      fullLabelText: "Number of people",
                                      fullLabel: true,
                                      borderRadius: 6,
                                      textEditingController:
                                          ctrl.numberOfPeople.value,
                                      textInputType: TextInputType.number,
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    FormFields(
                                      hint: "Enter Number",
                                      fullLabelText: "Enter your mobile number",
                                      fullLabel: true,
                                      borderRadius: 6,
                                      textEditingController:
                                          ctrl.contactField.value,
                                      textInputType: TextInputType.number,
                                      validator: (val) {
                                        RegExp specialReg =
                                            RegExp(r'^[</>?!#_\-=@,\.;]+$');
                                        if (specialReg.hasMatch(val!) ||
                                            val.contains("<script>")) {
                                          var ctrls =
                                              Get.find<InputController>();
                                          ctrls.clearInput(
                                              ctrl.contactField.value);
                                          // setState(() {
                                          // widget.textEditingController!.text = "";
                                          // });
                                          // });
                                          return "Characters are not allowed";
                                        }

                                        if (val!.length > 10) {
                                          return "Mobile number must be of 10 digit";
                                        } else if (val.length == 0) {
                                          return "Mobile Number is Required";
                                        }
                                        return null;
                                      },
                                      showCustomMsg: false,
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    DropDownBtn(
                                            hint: ctrl.purpose.value,
                                            data: StaticDatas().purpose,
                                            dropItemChild: "name",
                                            value: ctrl.selcPurposeValue.value,
                                            onChange: (val) {
                                              var result = DropConverter()
                                                  .setDropValue(val);
                                              ctrl.purpose.value =
                                                  result['name'];
                                              ctrl.selcPurposeValue.value =
                                                  result['val'];
                                            },
                                          ),
                                    SizedBox(
                                      height:20 
                                    ),
                                    TextArea(
                                        hint: "Write here...",
                                        borderRadius: 6,
                                        fullLabel: true,
                                        fullLabelText: "Description",
                                        textEditingController:
                                            ctrl.descCtrl.value),
                                    SizedBox(
                                      height:20,
                                    ),
                                    ctrl.age.value > 60 || ctrl.age.value == 60?Container(): Row(
                                          children: [
                                            Checkbox(
                                                value: ctrl.opted.value, 
                                                onChanged: (val) {
                                                    ctrl.opted.value = val!;
                                                },
                                              ),
                                            Flexible(child: Text("As you have opted for VRS and you have not attained age of 60, To avail VOF kindly declare that after taking VRS, you have not taken up any employment or engaged in any business activity!!".tr))
                                          ],
                                        )
                                  ],
                                );
                              }
                            },
                          ),
                        ],
                      ),
                    );
                  },
                )
              ],
            ),
          ),
        ),
        bottomNavigationBar: GetX(
          init: HolidayDataController(),
          builder: (ctrl) {
            if (ctrl.loading == AppLoadingState.Loading) {
              return Container(
                height: 0,
              );
            } else {
              // return Container(
              //   height: 80,
              //   decoration: BoxDecoration(color: Colors.white),
              //   child: Container(
              //     padding: EdgeInsets.fromLTRB(10, 15, 15, 10),
              //     child: Row(
              //       mainAxisAlignment: MainAxisAlignment.end,
              //       children: [
              //         SizedBox(
              //           width: MediaQuery.of(context).size.width / 2.5,
              //           child: Material(
              //             color: Theme.of(context).colorScheme.primary,
              //             borderRadius: BorderRadius.circular(300),
              //             child: InkWell(
              //               onTap: () {
                              // var ctrl = Get.find<HolidayVofController>();
                              // ctrl.validateForm();
              //               },
              //               child: Center(
              //                 child: Row(
              //                   mainAxisAlignment: MainAxisAlignment.center,
              //                   children: [
              //                     SizedBox(
              //                       width: 10,
              //                     ),
              //                     Expanded(
              //                       child: Text(
              //                         textAlign: TextAlign.center,
              //                         "Submit",
              //                         style: TextStyle(
              //                             color: Colors.white,
              //                             fontWeight: FontWeight.w600,
              //                             fontSize: 15),
              //                       ),
              //                     ),
              //                     CircleAvatar(
              //                       backgroundColor:
              //                           Colors.white.withOpacity(0.5),
              //                       child: Icon(
              //                         Icons.chevron_right,
              //                         color: Colors.black,
              //                       ),
              //                     ),
              //                     SizedBox(
              //                       width: 10,
              //                     ),
              //                   ],
              //                 ),
              //               ),
              //             ),
              //           ),
              //         ),
              //       ],
              //     ),
              //   ),
              // );
              var ct = Get.find<HolidayVofController>();
                print(ct.selectedType == 1?ct.opted.value?false:true:false);
              return Container(
                height: 80,
                padding: EdgeInsets.fromLTRB(10, 15, 15, 10),
                decoration: BoxDecoration(color: Colors.white),
                child: Row(
                  children: [
                     Flexible(child: Container(),flex: 1,),
                    Flexible(
                      flex: 1,
                      child: MainButton(
                        disabled: ct.selectedType == 1?ct.opted.value?false:true:false,
                        buttonLable: "Submit",
                        onTap : (){
                          ct.validateForm(appType: "vf");
                        }  
                      ),
                        
                      ),
                     
                  ],
                ),
              );
            }
          },
        ));
  }
}
