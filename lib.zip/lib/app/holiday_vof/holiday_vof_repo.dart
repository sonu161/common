import 'dart:convert';

import 'package:sidbi_app/app/holiday_vof/model/SaveHolidayVofModel.dart';
import 'package:sidbi_app/app/holiday_vof/model/UtilityData.dart';
import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/entities/holiday_vof_entity/holiday_vof_ent.dart';

class HolidayVofRepo extends HolidayVofEnt {
  Helper helper = new Helper();

  @override
  getBookings({appType}) async {
    try {
      var userid = await helper.getSharedPrefString(keyName: "userid");
      var url = "getBookingList/$userid/$appType";
      print(url);
      var userFor = await helper.getSharedPrefString(keyName: "userFor");
      bool? userToken;
      if(userFor != null){
        var logUserid = await helper.getSharedPrefString(keyName: "userid");
        url = "adminHhVofHisList/$logUserid/$userFor";
        userToken = false;
      }
      var res = await helper.getService(url);
      return res;
    } catch (e) {
      return false;
    }
  }

  @override
  getHolidayHomeData() async {
    try {
      var userid = await helper.getSharedPrefString(keyName: "userid");
      var res = await helper.getService("getHolidayHomeList/$userid");
      return res;
    } catch (e) {}
  }

  @override
  getVofData() async {
    try {
      var userid = await helper.getSharedPrefString(keyName: "userid");
      var res = await helper.getService("getVOFList/$userid");
      return res;
    } catch (e) {}
  }

  @override
  submitForm({SaveHolidayVofModel? data}) async{
    try{
      var dataBody = data?.toJson();
      var res = await helper.postService(data: dataBody, url: "holiHomeVofFormSubmission");
      return res;
    }catch(e){

    }
  }

  @override
  cancelHHVfBooking({formId}) async{
    var userid = await helper.getSharedPrefString(keyName: "userid");
    var url = "vofHHDeleteBooking/$userid/$formId";
    var res = await helper.getService(url);
    return res;
  }
  
  @override
  getAge() async{
    var userid = await helper.getSharedPrefString(keyName: "userid");
    var url = "getRetireeAgeAndStatus/$userid";
    var res = await helper.getService(url);
    return res;
  }
  
  @override
  submitUtility({required UtilityData data, filepath}) async{
    var url = "hhUtilityChargesSubmission";
    print(data.toJson());
    // var res = await helper.postService(url: url,data: data.toJson());
    var res = await helper.postFormField(
          url: "hhUtilityChargesSubmission",
          data: data.toJson(),
          path: filepath,
          fileKey: "utilityFile",);
    return res;
  }
}
