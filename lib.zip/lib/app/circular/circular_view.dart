import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:sidbi_app/admin/admin_home/view/circular/retiree_circular.dart';

class CircularView extends StatefulWidget {
  const CircularView({super.key});

  @override
  State<CircularView> createState() => _CircularViewState();
}

class _CircularViewState extends State<CircularView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: RetireeCircular(viewUpload: false,),
    );
  }
}