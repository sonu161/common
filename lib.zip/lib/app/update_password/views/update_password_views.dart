import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/app/otp/controller/otp_controller.dart';
import 'package:sidbi_app/app/update_password/controller/update_pass_controller.dart';
import 'package:sidbi_app/components/form_field.dart';
import 'package:sidbi_app/components/light_button.dart';
import 'package:sidbi_app/components/load_d.dart';
import 'package:sidbi_app/components/pin_field.dart';

import '../../../components/input_field.dart';
import '../../../components/main_button.dart';
import '../../../components/presets.dart';

class UpdatePasswordViews extends StatefulWidget {
  const UpdatePasswordViews({super.key});

  @override
  State<UpdatePasswordViews> createState() => _UpdatePasswordViewsState();
}

class _UpdatePasswordViewsState extends State<UpdatePasswordViews> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        iconTheme: IconThemeData(color: Theme.of(context).colorScheme.primary),
        systemOverlayStyle:
            SystemUiOverlayStyle(statusBarIconBrightness: Brightness.dark),
        title: Text(
          "${Get.arguments}",
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.fromLTRB(20, 20, 20, 10),
          child: Column(
            children: [
              Container(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                      "Update \n"
                              "Your password"
                          .tr,
                      style: TextStyle(
                        color: Presets.boldBigSizeColor,
                        fontWeight: FontWeight.w700,
                        fontSize: 26,
                      )),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                child: Text(
                  "Here you can set new password and then you will proceed for login again."
                      .tr,
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.black54,
                      fontSize: 15),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              GetX(
                init: UpdatePassController(userid: Get.arguments),
                builder: (ctrl) {
                  return Form(
                    key: ctrl.formKey.value,
                    child: Column(
                      children: [
                        Container(
                          child: FormFields(
                            textEditingController: ctrl.newPassCtrl.value,
                            hint: '**********',
                            fullLabel: true,
                            fullLabelText: "New Password*".tr,
                            borderRadius: 10,
                            lightTextBox: true,
                            // validator: ctrl.newPassCheck.value,
                            validatorText: "New password is required".tr,
                            obsecureText: ctrl.obsecurePass.value,
                            obsecureToNoSecure: () {
                              ctrl.changeObsecurePass(
                                  varibleName: ctrl.obsecurePass);
                            },
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          child: FormFields(
                            textEditingController: ctrl.conPassCtrl.value,
                            hint: '***********',
                            fullLabel: true,
                            fullLabelText: "Confirm new password*".tr,
                            borderRadius: 10,
                            lightTextBox: true,
                            validator: (val) {
                              if (ctrl.conPassCtrl.value.text !=
                                  ctrl.newPassCtrl.value.text) {
                                return "Confirm password is not matching";
                              } else {
                                return null;
                              }
                            },
                            validatorText: "Please confirm the password".tr,
                            obsecureText: ctrl.obsecureConPass.value,
                            obsecureToNoSecure: () {
                              ctrl.changeObsecurePass(
                                  varibleName: ctrl.obsecureConPass);
                            },
                            showCustomMsg: false,
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        ctrl.appLoadingState == AppLoadingState.Loaded
                            ? Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: FormFields(
                                      textEditingController: ctrl.captcha.value,
                                      hint: 'Enter Captcha*',
                                      // fullLabel: false,
                                      // fullLabelText: "Ca",
                                      borderRadius: 10,
                                      lightTextBox: true,
                                      // validator: ctrl.emailCheck.value,
                                      validatorText: "Captcha is required",
                                      fieldIcon: Image(
                                          image: MemoryImage(base64Decode(
                                              ctrl.captchaImage.value))),
                                      bigFieldImage: true,
                                      trailingBtn: Icon(Icons.refresh),
                                      onTapTrailing: () {
                                        ctrl.refreshCaptcha();
                                      },
                                      showLoading: ctrl.loadingCtrl ==
                                              RefreshState.Loading
                                          ? true
                                          : false,
                                    ),
                                  ),
                                ],
                              )
                            : Container(
                                child: Center(
                                  child: LoadD(),
                                ),
                              ),
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          child: ctrl.passwordSubmited.value
                              ? Align(
                                  alignment: Alignment.centerLeft,
                                  child: PinField(
                                    controller: ctrl.otpPassCtrl.value,
                                    pinLength: 5,
                                    lable: "Enter OTP*",
                                    validator: ctrl.otpCheck.value,
                                    validatorText: "OTP is required",
                                  ),
                                )
                              : Container(),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        MainButton(
                          buttonLable: "Proceed",
                          onTap: () {
                            ctrl.checkFields();
                          },
                          borderRadius: 10,
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  ctrl.timeShow.value == 0?
                                  LightButton(
                                    showIcon: false,
                                    buttonLable: "Resend Otp",onTap: (){
                                    ctrl.resendOtp(useridParse: Get.arguments);
                                  },):Text("Resend in : ${ctrl.timeShow.value}s",style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold
                                  ),),
                                ],
                              ),
                            )
                      ],
                    ),
                  );
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
