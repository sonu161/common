import 'dart:convert';

import 'package:get/get.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:pinput/pinput.dart';
import 'package:sidbi_app/app/holiday_reimb/model/ReimburseData.dart';
import 'package:sidbi_app/app/holiday_reimb/repo/holiday_reim_repo.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/helper.dart';

class ReimbViewController extends GetxController{
  var loading = AppLoadingState.Initial.obs;
  HolidayReimRepo repo = new HolidayReimRepo();
  var listData = ReimburseData().obs;
  var listProp = <ReimburseData>[].obs;
  var holidayList = [
    {
      "applicationNo": "2410001345", // front
      "holidayHome": "Manali Sterling", // front
      "fromDate": "30-06-2024", // front
      "endDate": "01-07-2024",
      "noOfNights": "1",
      "totalEligibleAmt": "",
      "totalClaimAmt": "",
      "totalPaybleAmt": "",
      "status": "Submitted", // front
    },
    {
      "applicationNo": "2410001345",
      "holidayHome": "Manali Sterling",
      "fromDate": "30-06-2024",
      "endDate": "01-07-2024",
      "noOfNights": "1",
      "totalEligibleAmt": "",
      "totalClaimAmt": "",
      "totalPaybleAmt": "",
      "status": "Submitted",
    },
    {
      "applicationNo": "2410001345",
      "holidayHome": "Manali Sterling",
      "fromDate": "30-06-2024",
      "endDate": "01-07-2024",
      "noOfNights": "1",
      "totalEligibleAmt": "",
      "totalClaimAmt": "",
      "totalPaybleAmt": "",
      "status": "Submitted",
    },
    {
      "applicationNo": "2410001345",
      "holidayHome": "Manali Sterling",
      "fromDate": "30-06-2024",
      "endDate": "01-07-2024",
      "noOfNights": "1",
      "totalEligibleAmt": "",
      "totalClaimAmt": "",
      "totalPaybleAmt": "",
      "status": "Submitted",
    },
  ].obs;

  getBookings() async{
    try{
      listProp.clear();
      loading.value = AppLoadingState.Loading;
      var res = await repo.getList();
      var data = jsonDecode(res.body);
      print(data);
      for(var i =0; i < data.length; i++){
        listData.value = ReimburseData.fromJson(data[i]);
        listProp.add(listData.value);
      }
      listProp.refresh();
      loading.value = AppLoadingState.Loaded;
      
    }catch(e){
      Helper().messageAlert(title: "Error", message: e.toString(), type: AlertBoxType.Error);
    }
  }

  @override
  void onInit() {
    getBookings();
    super.onInit();
  }
}