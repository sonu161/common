import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/list_notifier.dart';
import 'package:intl/intl.dart';
import 'package:sidbi_app/app/holiday_reimb/controller/holiday_reimb_controller.dart';
import 'package:sidbi_app/app/holiday_reimb/model/reimburse_data.dart';
import 'package:sidbi_app/components/helper.dart';

class ReimbuController extends GetxController {
  var listEditorControllers = [
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
  ].obs;

  // var startDateCtrl = TextEditingController().obs;
  var formKey = GlobalKey<FormState>().obs;
  var list = new HolidayData().obs;
  var editableView = false.obs;
  var editigForIndex = 0.obs;
  // var eligibleAmount = 1100.obs;
  var statusHotelGst = true.obs;
  var statusFoodGst = true.obs;
  var startDate = DateTime.now().obs;
  var endDate = DateTime.now().obs;
  Timer? timer;
  var clickable = false.obs;

  void validateForm({type}) {
    final isValid = formKey.value.currentState?.validate();
    if (!isValid!) {
      // submitForm();

      return;
    } else {
      if (type == "add") {
        addData();
      } else {
        editField();
      }
    }
    formKey.value.currentState?.save();
  }

  addData() {
    // checkDateDiffs();
    var ctrl = Get.find<HolidayReimbController>();
    var dataLen = ctrl.addedHomeReim.length;
    var days = double.parse(listEditorControllers[11].text);
    if (dataLen > 0) {
      if (checkDateDiffs() == true) {
        if (days > 1) {
          Helper().messageAlert(
              title: "Information",
              message: "Day must be equals to 1",
              type: AlertBoxType.Error);
        } else {
          dataAssigning();
        }
      } else {
        print(false);
      }
    } else {
      if (days > 1) {
        Helper().messageAlert(
            title: "Information",
            message: "Day must be equals to 1",
            type: AlertBoxType.Error);
      } else {
        dataAssigning();
      }
    }
  }

  dataAssigning() {
    var ctrl = Get.find<HolidayReimbController>();
    var dataLen = ctrl.addedHomeReim.length;
    ctrl.addedHomeReim.value.add(HolidayData(
      roomTarrif: listEditorControllers[0].text,
      foodBill: listEditorControllers[1].text,
      eligibleAmt: listEditorControllers[2].text,
      hotelGstRate: listEditorControllers[3].text,
      foodGstRate: listEditorControllers[4].text,
      hotelGstAmt: listEditorControllers[5].text,
      foodGstAmt: listEditorControllers[6].text,
      totalGstAmt: listEditorControllers[7].text,
      hotelName: listEditorControllers[8].text,
      startDate: listEditorControllers[9].text,
      endDate: listEditorControllers[10].text,
      noOfDays: listEditorControllers[11].text,
      totalEligibleAmt: listEditorControllers[12].text,
      totalPayAmy: listEditorControllers[13].text,
      totalHotelFoodAmt: listEditorControllers[14].text,
    ));
    ctrl.addedHomeReim.refresh();
    ctrl.addToForm();
    // timer!.cancel();
    Get.back();
  }

  setDataOnTextField(
      {required HolidayData data, required bool edit, required int index}) {
    editableView.value = edit;
    editigForIndex.value = index;
    listEditorControllers[0].text = data.roomTarrif!;
    listEditorControllers[1].text = data.foodBill!;
    listEditorControllers[2].text = data.eligibleAmt!;
    listEditorControllers[3].text = data.hotelGstRate!;
    listEditorControllers[4].text = data.foodGstRate!;
    listEditorControllers[5].text = data.hotelGstAmt!;
    listEditorControllers[6].text = data.foodGstAmt!;
    listEditorControllers[7].text = data.totalGstAmt!;
    listEditorControllers[8].text = data.hotelName!;
    listEditorControllers[9].text = data.startDate!;
    listEditorControllers[10].text = data.endDate!;
    listEditorControllers[11].text = data.noOfDays!;
    listEditorControllers[12].text = data.totalEligibleAmt!;
    listEditorControllers[13].text = data.totalPayAmy!;
    listEditorControllers[14].text = data.totalHotelFoodAmt!;
  }

  editField() {
    var days = double.parse(listEditorControllers[11].text);
    var ctrl = Get.find<HolidayReimbController>();
    if (days > 1) {
      Helper().messageAlert(
          title: "Information",
          message: "Day must be equals to 1",
          type: AlertBoxType.Error);
    } else {
      for (var i = 0; i <= ctrl.addedHomeReim.length; i++) {
        if (i == editigForIndex.value) {
          ctrl.addedHomeReim[editigForIndex.value].roomTarrif =
              listEditorControllers[0].text;
          ctrl.addedHomeReim[editigForIndex.value].foodBill =
              listEditorControllers[1].text;
          ctrl.addedHomeReim[editigForIndex.value].eligibleAmt =
              listEditorControllers[2].text;
          ctrl.addedHomeReim[editigForIndex.value].hotelGstRate =
              listEditorControllers[3].text;
          ctrl.addedHomeReim[editigForIndex.value].foodGstRate =
              listEditorControllers[4].text;
          ctrl.addedHomeReim[editigForIndex.value].hotelGstAmt =
              listEditorControllers[5].text;
          ctrl.addedHomeReim[editigForIndex.value].foodGstAmt =
              listEditorControllers[6].text;
          ctrl.addedHomeReim[editigForIndex.value].totalGstAmt =
              listEditorControllers[7].text;
          ctrl.addedHomeReim[editigForIndex.value].hotelName =
              listEditorControllers[8].text;
          ctrl.addedHomeReim[editigForIndex.value].startDate =
              listEditorControllers[9].text;
          ctrl.addedHomeReim[editigForIndex.value].endDate =
              listEditorControllers[10].text;
          ctrl.addedHomeReim[editigForIndex.value].noOfDays =
              listEditorControllers[11].text;
          ctrl.addedHomeReim[editigForIndex.value].totalEligibleAmt =
              listEditorControllers[12].text;
          ctrl.addedHomeReim[editigForIndex.value].totalPayAmy =
              listEditorControllers[13].text;
          ctrl.addedHomeReim[editigForIndex.value].totalHotelFoodAmt =
              listEditorControllers[14].text;
        }
      }
      ctrl.addedHomeReim.refresh();
      ctrl.addToForm();
      // timer!.cancel();
      Get.back();
    }
  }

  @override
  void dispose() {
    Get.delete<ReimbuController>();
    super.dispose();
    for (var i = 0; i < listEditorControllers.length; i++) {
      listEditorControllers[i].clear();
    }
  }

  setFiels() async {
    var ctrl = Get.find<HolidayReimbController>();
    listEditorControllers[2].text = ctrl.elegibleAmt.value.toString();
  }

  simulateEaValues({val, type, eleAmt}) async {
    print(val);
    // eligibleAmount = eleAmt;
    var ctrl = Get.find<HolidayReimbController>();
    if (type == "RT") {
      statusHotelGst.value = val == "0" ? true : false;
      var rt = int.parse(val);
      var fb = double.parse(listEditorControllers[1].text == ""
          ? "0"
          : listEditorControllers[1].text);
      var sumRtFb = rt + fb;
      var elAmt = ctrl.elegibleAmt.value;
      if (sumRtFb < elAmt) {
        listEditorControllers[2].text = sumRtFb.toString();
      } else {
        listEditorControllers[2].text = ctrl.elegibleAmt.value.toString();
      }
      hotelGSTCount();
      // print(double.parse(listEditorControllers[7].text));
    } else {
      if (type == "FB") {
        statusFoodGst.value = val == "0" ? true : false;
        if (statusFoodGst.value = val == "0"){
          listEditorControllers[4].text = "0";
        }
        var rt = double.parse(listEditorControllers[0].text == ""
            ? "0"
            : listEditorControllers[0].text);
        ;
        var fb = double.parse(val);
        var sumRtFb = rt + fb;
        var elAmt = ctrl.elegibleAmt.value;
        if (sumRtFb < elAmt) {
          listEditorControllers[2].text = sumRtFb.toString();
          print(sumRtFb.toString());
        } else {
          listEditorControllers[2].text = ctrl.elegibleAmt.value.toString();
        }
        foodGSTCount();
      }
    }

    listEditorControllers[12].text = listEditorControllers[2].text;
    listEditorControllers[14].text = (double.parse(
                listEditorControllers[0].text == ""
                    ? "0"
                    : listEditorControllers[0].text) +
            double.parse(listEditorControllers[1].text == ""
                ? "0"
                : listEditorControllers[1].text))
        .toString();
    refresh();
  }

  hotelGSTCount({val}) async {
    if (listEditorControllers[3].text != "") {
      var getVal = val ?? listEditorControllers[3].text;
      var rt = double.parse(listEditorControllers[0].text);
      var tGstAmt = 0.0;
      // if(eligibleAmount > (double.parse(listEditorControllers[0].text)+double.parse(listEditorControllers[1].text))){
      // tGstAmt = rt > eligibleAmount.value
      //     ? (double.parse(getVal) / 100) * eligibleAmount.value
      //     : (double.parse(getVal) / 100) * rt;
      // }else{
      // tGstAmt = rt > eligibleAmount.value
      //     ? (double.parse(getVal) / 100) * eligibleAmount.value
      //     : (double.parse(getVal) / 100) * rt;
      // }

      var rateValue = (double.parse(getVal) / 100) * rt;
      listEditorControllers[5].text = rateValue.toStringAsFixed(2);
      totalGst();
      // listEditorControllers[7].text = tGstAmt.round().toString();
    } else {
      listEditorControllers[5].text = "";
    }
  }

  foodGSTCount({val}) async {
    if (listEditorControllers[4].text != "") {
      var getVal = val ?? listEditorControllers[4].text;
      var fb = double.parse(listEditorControllers[1].text);
      var rateValue = fb * (double.parse(getVal) / 100);
      listEditorControllers[6].text = rateValue.toStringAsFixed(2);
    } else {
      listEditorControllers[6].text = "";
    }
    totalGst();
  }

  totalGst() async {
    var ctrl = Get.find<HolidayReimbController>();
    if (listEditorControllers[3].text != "") {
      var getRtVal =
          listEditorControllers[3].text ?? listEditorControllers[3].text;
      var rt = double.parse(listEditorControllers[0].text);

      var getFbVal =
          listEditorControllers[4].text ?? listEditorControllers[4].text;
      var fb = double.parse(listEditorControllers[1].text);

      if ((rt + fb) > ctrl.elegibleAmt.value) {
        if (rt > ctrl.elegibleAmt.value)
          listEditorControllers[7].text =
              ((ctrl.elegibleAmt.value * double.parse(getRtVal)) / 100)
             
                  .toStringAsFixed(2);
        else
          listEditorControllers[7].text = ((rt * double.parse(getRtVal)) / 100 +
                  (((ctrl.elegibleAmt.value - rt) * double.parse(getFbVal))) / 100)
              
              .toStringAsFixed(2);
      } else {
        listEditorControllers[7].text =
            ((rt * double.parse(getRtVal)) / 100 + fb * double.parse(getFbVal) / 100)
               
                .toStringAsFixed(2);
      }
      // var tGstAmt = 0.0;

      var totalClaim = double.parse(listEditorControllers[2].text) +
          double.parse(listEditorControllers[7].text == ""
                  ? "0"
                  : listEditorControllers[7].text);
      listEditorControllers[13].text = totalClaim.toStringAsFixed(2);
    }
  }

  onChangeStartDate() {
    if(listEditorControllers[9].text != ""){
      clickable.value = true;
    }
    if (listEditorControllers[9].text != "" &&
        listEditorControllers[10].text != "") {
      if (listEditorControllers[9].text != "" &&
          listEditorControllers[10].text != 0) {
        DateTime parseDate1 =
            new DateFormat("dd-MM-yyyy").parse(listEditorControllers[9].text);
        DateTime parseDate2 =
            new DateFormat("dd-MM-yyyy").parse(listEditorControllers[10].text);
        var startDate = DateTime.parse(parseDate1.toString());
        var endDate = DateTime.parse(parseDate2.toString());
        var noOfDays = endDate.difference(startDate).inDays;
        // if (noOfDays > 1) {
        //   cancelTime();
        //   Helper().appDialogBox(
        //       title: 'Information',
        //       message: 'Date difference should not more then 1',
        //       onTap: () {
        //         timer = Timer.periodic(Duration(milliseconds: 10), (timer) {
        //           onChangeStartDate();

        //         });
        //       });
        // }else{

        // }
        listEditorControllers[11].text = noOfDays.toString();
      }
    }
  }

  checkDateDiffs() {
    var ctrl = Get.find<HolidayReimbController>();
    var dataLen = ctrl.addedHomeReim.length;
    if (ctrl.addedHomeReim.length > 0) {
      DateTime parseDate1 =
          new DateFormat("dd-MM-yyyy").parse(listEditorControllers[9].text);
      DateTime parseDate2 =
          new DateFormat("dd-MM-yyyy").parse(listEditorControllers[10].text);
      var startDate = DateTime.parse(parseDate1.toString());
      var endDate = DateTime.parse(parseDate2.toString());
      var noOfDays = endDate.difference(startDate).inDays;
      print(noOfDays);
      if (noOfDays > 1) {
        return false;
      } else {
        return true;
      }
    }
  }

  // cancelTime() {
  //   timer!.cancel();
  // }

  @override
  void onInit() {
    // TODO: implement onReady
    super.onInit();
    listEditorControllers[9].addListener(() {
      onChangeStartDate();
    });
    listEditorControllers[10].addListener(() {
      onChangeStartDate();
    });
  }
}
