import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/claims/controller/claim_ctrl.dart';
import 'package:sidbi_app/app/holiday_reimb/controller/reimb_view_controller.dart';
import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/load_d.dart';
import 'package:sidbi_app/components/loading.dart';

class HolidayReimbDetail extends StatefulWidget {
  const HolidayReimbDetail({
    super.key,
  });
  @override
  State<HolidayReimbDetail> createState() => _HolidayReimbDetailLoader();
}

class _HolidayReimbDetailLoader extends State<HolidayReimbDetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.inverseSurface,
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: GetX(
          init: ReimbViewController(),
          builder: (ctrl) {
            if (ctrl.loading2 == AppLoadingState.Loading) {
              return LoadingApp();
            } else {
              return ListView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemCount: ctrl.listDetail.length,
                  itemBuilder: (context, index) {
                    var gdata = ctrl.listDetail[index];

                    return Container(
                      decoration: BoxDecoration(
                          border: Border(
                              left: BorderSide(
                                  color: Color((math.Random().nextDouble() *
                                              0xFFFFFF)
                                          .toInt())
                                      .withOpacity(1.0),
                                  width: 5))),
                      margin: EdgeInsets.only(bottom: 10),
                      child: ExpansionTile(
                        onExpansionChanged: (val) {
                          print(val);
                          if (val == true) {
                            ctrl.openView.value = index;
                          } else {
                            ctrl.openView.value = -1;
                          }
                          print(ctrl.openView.value);
                        },
                        // Row(
                        //   children: [
                        //     Text(
                        //       "${gdata.convertedFromDate} To ${gdata.convertedFromDate}",
                        //       style: Theme.of(context).textTheme.headlineSmall,
                        //     ),
                        //   ],
                        // )
                        title: RichText(
                          text: TextSpan(
                            text: "${gdata.convertedFromDate}",
                            children: [
                              TextSpan(
                                text: " TO ",
                                style: TextStyle(
                                  fontWeight: FontWeight.bold
                                )
                              ),
                              TextSpan(
                                text: "${gdata.convertedToDate}"
                              ),
                            ],
                            style: Theme.of(context).textTheme.labelLarge,
                          ),
                        ),
                        backgroundColor:
                            Theme.of(context).colorScheme.tertiaryContainer,
                        collapsedBackgroundColor:
                            Theme.of(context).colorScheme.tertiaryContainer,
                        children: [
                          Container(
                            // height: MediaQuery.of(context).size.height * 0.1,
                            width: MediaQuery.of(context).size.width,
                            decoration: BoxDecoration(
                                color: Theme.of(context)
                                    .colorScheme
                                    .inverseSurface,
                                borderRadius: BorderRadius.circular(10)),
                            padding: EdgeInsets.fromLTRB(15, 10, 15, 8),
                            margin: EdgeInsets.fromLTRB(15, 0, 15, 8),
                            child: Column(
                              children: [
                                DetailRow(
                                    heading: "Room Tally",
                                    detail: "\u{20B9} ${gdata.roomTally}"),
                                Spacer(),
                                DetailRow(
                                    heading: "Food Bill",
                                    detail: "\u{20B9} ${gdata.foodBill}"),
                                Spacer(),
                                DetailRow(
                                    heading: "Hotel Gst Rate",
                                    detail: "${gdata.hotelGstRate}%"),
                                Spacer(),
                                DetailRow(
                                    heading: "Food Gst Rate",
                                    detail: "${gdata.foodGstRate}%"),
                                Spacer(),
                                DetailRow(
                                    heading: "Hotel Gst Amount",
                                    detail: "\u{20B9}${gdata.hotelGstAmount}"),
                                Spacer(),
                                DetailRow(
                                    heading: "Food Gst Amount",
                                    detail: "\u{20B9}${gdata.foodGstAmount}"),
                                Spacer(),
                                DetailRow(
                                    heading: "Total Gst Amount",
                                    detail: "\u{20B9}${gdata.totalGstAmount}"),
                                Spacer(),
                                DetailRow(
                                    heading: "Eligible Amount",
                                    detail: "\u{20B9}${gdata.eligibleAmount}"),
                                Spacer(),
                                DetailRow(
                                    heading: "Total Amount",
                                    detail: "\u{20B9}${gdata.totalAmount}"),
                                Spacer(),
                                DetailRow(
                                    heading: "Total Payable Amount",
                                    detail:
                                        "\u{20B9}${gdata.totalPayableAmount}"),
                                Spacer(),
                                DetailRow(
                                    heading: "Hotel Name",
                                    detail: gdata.hotelName)
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  });
            }
          },
        ),
      ),
    );
  }

  Widget Spacer() {
    return SizedBox(
      height: 10,
    );
  }

  Widget DetailRow({heading, detail}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(child: Text(
          "$heading",
          style: TextStyle(
            color: Theme.of(context).colorScheme.onSecondary
          ),
        )),
        Flexible(child: Text("$detail",style: Theme.of(context).textTheme.bodyLarge,))
      ],
    );
  }
}
