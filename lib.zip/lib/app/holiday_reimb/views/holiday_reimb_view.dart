import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sidbi_app/app/holiday_reimb/controller/reimb_view_controller.dart';
import 'package:sidbi_app/app/holiday_reimb/model/ReimburseData.dart';
import 'package:sidbi_app/app/holiday_reimb/views/holiday_reimb_detail.dart';
import 'package:sidbi_app/app/holiday_reimb/views/holiday_reimb_form.dart';

import 'dart:math' as math;

import 'package:sidbi_app/app/login/controller/loging_ctrl.dart';
import 'package:sidbi_app/components/loading.dart';
import 'package:sidbi_app/components/main_button.dart';
import 'package:sidbi_app/components/no_data.dart';

class HolidayReimbView extends StatefulWidget {
  const HolidayReimbView({
    super.key,
  });

  @override
  State<HolidayReimbView> createState() => _HolidayReimbViewState();
}

class _HolidayReimbViewState extends State<HolidayReimbView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        actions: [
          GestureDetector(
            onTap: () {
              Get.to(() => HolidayReimbForm(), transition: Transition.fadeIn);
            },
            child: Row(
              children: [
                Text(
                  "ADD",
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 5,
                ),
                Icon(
                  Icons.add,
                  size: 22,
                )
              ],
            ),
          ),
          SizedBox(
            width: 20,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.only(top: 15),
        child: GetX(
          init: ReimbViewController(),
          builder: (ctrl) {
            if (ctrl.loading.value == AppLoadingState.Loading) {
              return LoadingApp();
            } else {
              if (ctrl.listProp.length > 0) {
                return ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: ctrl.listProp.length,
                  itemBuilder: (context, index) {
                    // return expansionTileView(data: ctrl.claimList[index]);
                    return dataCard(data: ctrl.listProp[index]);
                  },
                );
              }else{
                return NoData(refresh: ()=>ctrl.getBookings(),);
              }
            }
          },
        ),
      ),
    );
  }

  Widget dataCard({ReimburseData? data}) {
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.only(left: 30, right: 15, bottom: 10),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)],
              border: Border(
                  left: BorderSide(
                      color:
                          Color((math.Random().nextDouble() * 0xFFFFFF).toInt())
                              .withOpacity(1.0),
                      width: 5))),
          child: ExpansionTile(
            backgroundColor:
                Theme.of(context).colorScheme.primary.withOpacity(0.07),
            tilePadding:
                EdgeInsets.only(top: 10, bottom: 10, left: 15, right: 15),
            subtitle: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                    child: Text(
                  "${data!.holidayHome}",
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.w600),
                )),
                Row(
                  children: [
                    Icon(
                      Icons.calendar_month,
                      color: Colors.black54,
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Text("${data.fromDate}",
                        style: TextStyle(fontSize: 15, color: Colors.black54)),
                  ],
                )
              ],
            ),
            title: Container(
              margin: EdgeInsets.only(left: 30),
              child: Column(
                children: [
                  Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Application No".tr,
                          style: TextStyle(fontSize: 15, color: Colors.black54),
                        ),
                        Text("${data.status}".tr,
                            style:
                                TextStyle(fontSize: 15, color: Colors.black54))
                      ],
                    ),
                  ),
                  Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "${data.appNo}",
                          style: TextStyle(
                              fontSize: 19,
                              fontWeight: FontWeight.w600,
                              color: Theme.of(context).colorScheme.onSecondary),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  // Container(
                  //   child: Row(
                  //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //     children: [
                  //       Container(
                  //         padding: EdgeInsets.only(
                  //             left: 10,
                  //             right: 10,
                  //             top: 3,
                  //             bottom: 3
                  //         ),
                  //         decoration:BoxDecoration(
                  //             border: Border.all(
                  //               color: Theme.of(context).colorScheme.primary,
                  //             ),
                  //             borderRadius: BorderRadius.circular(300)
                  //         ),
                  //         child: Row(
                  //           children: [
                  //             Text("${data['holidayHome']}",style: TextStyle(
                  //                 color: Theme.of(context).colorScheme.primary,
                  //                 fontWeight: FontWeight.w600
                  //             ),)
                  //           ],
                  //         ),
                  //       ),
                  //       Row(
                  //         children: [
                  //           Icon(Icons.calendar_month,color: Colors.black54,),
                  //           SizedBox(
                  //             width: 5,
                  //           ),
                  //           Text("${data['fromDate']}",style: TextStyle(
                  //               fontSize: 15,
                  //               color: Colors.black54
                  //           )),
                  //         ],
                  //       )
                  //     ],
                  //   ),
                  // )
                ],
              ),
            ),
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text("End Date".tr)),
                    SizedBox(
                      width: 10,
                    ),
                    Flexible(child: Text("${data.endDate}"))
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text("No of Night".tr)),
                    SizedBox(
                      width: 10,
                    ),
                    Flexible(child: Text("${data.noOfNights}"))
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text("Total Eligible Amount".tr)),
                    SizedBox(
                      width: 10,
                    ),
                    Flexible(
                        child: Text("\u{20B9} ${data.totalEligibleAmount}"))
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(20, 10, 20, 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text("Total Claim Amount (Excl GST)".tr)),
                    SizedBox(
                      width: 10,
                    ),
                    Flexible(child: Text("\u{20B9} ${data.totalClaimAmount}"))
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.fromLTRB(20, 10, 20, 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text("Total Payble Amount".tr)),
                    SizedBox(
                      width: 10,
                    ),
                    Flexible(child: Text("${data.totalPayableAmount}"))
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.fromLTRB(20, 0, 20, 20),
                child: MainButton(
                  buttonLable: "View Detail",borderRadius: 10,
                  onTap: (){
                    Get.to(()=>HolidayReimbDetail());
                    var ctrl = Get.find<ReimbViewController>();
                    ctrl.getBookingDetail(appId: data.appNo);
                  },
                ),
              )
            ],
          ),
        ),
        Positioned(
          left: 10,
          top: 10,
          child: Container(
            decoration: BoxDecoration(
                border: Border.all(
                  color: Theme.of(context)
                      .colorScheme
                      .onSecondary
                      .withOpacity(0.3),
                ),
                borderRadius: BorderRadius.circular(300)),
            child: CircleAvatar(
              maxRadius: 30,
              backgroundColor: Color(0xfff1fbff),
              child: Image.asset(
                "assets/icons/hotel.png",
                height: 30,
                width: 30,
              ),
            ),
          ),
        )
      ],
    );
  }
}
