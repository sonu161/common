import 'dart:convert';

import 'package:sidbi_app/components/helper.dart';
import 'package:sidbi_app/entities/holiday_reim_entity/holiday_reim_entity.dart';
import 'package:http/http.dart' as http;
import '/network/app_config.dart';

class HolidayReimRepo extends HolidayReimEntity {
  Helper helper = new Helper();
  @override
  getList() async {
    try {
      var userid = await helper.getSharedPrefString(keyName: "userid");
      // var token = await helper.getSharedPrefString(keyName: "token");
      // var headers = {
      //   'Authorization': 'Bearer $token',
      //   'Content-Type': 'application/json',
      // };
      // print(headers);
      // print('${config?[baseUrl]}hhReimb/hhReimbHist/$userid');
      // var request = http.MultipartRequest(
      //     'GET',
      //     Uri.parse(
      //         '${config?[baseUrl]}hhReimb/hhReimbHist/$userid'));

      // request.headers.addAll(headers);

      // http.StreamedResponse response = await request.send();

      // if (response.statusCode == 200) {
      //   return response;
      // } else {
      //   print(response.reasonPhrase);
      // }
      var url = "hhReimb/hhReimbHist/$userid";
      var res = await helper.getService("$url");
      return res;
    } catch (e) {}
  }

  @override
  submitData({data, fileBill, fileId}) async {
    var userid = await helper.getSharedPrefString(keyName: "userid");
    var token = await helper.getSharedPrefString(keyName: "token");
    // var dataa = {"data": data.toString()};
    // List files = [
    //   {"fileName": "fileId", "path": "$fileId"},
    //   {"fileName": "fileBill", "path": "$fileBill"}
    // ];
    // var daat = {
    //   "data":jsonEncode(data)
    // };
    // var res = await helper.postFormField(
    //     url: "hhReimb/holidayHomeReibuesmentSave",
    //     data: daat,
    //     multifile: files);
    // return res;
    var headers = {
      'Authorization': 'Bearer $token',
    };
    var request = http.MultipartRequest(
        'POST',
        Uri.parse(
            '${config?[baseUrl]}hhReimb/holidayHomeReibuesmentSave'));
    var daat = {"data": jsonEncode(data).replaceAll("'\'", "")};
    request.fields.addAll(daat);
    request.files.add(await http.MultipartFile.fromPath('fileId', '$fileId'));
    request.files
        .add(await http.MultipartFile.fromPath('fileBill', '$fileBill'));
    request.headers.addAll(headers);

    http.StreamedResponse response = await request.send();

    if (response.statusCode == 200) {
      // print(await response.stream.bytesToString());
      return await response.stream.bytesToString();
    } else {
      print(response.reasonPhrase);
    }
  }

  getReimbElg() async {
    try {
      var salCode = await helper.getSharedPrefString(keyName: "userid");
      var empGrade = await helper.getSharedPrefString(keyName: "empGrade");
      var token = await helper.getSharedPrefString(keyName: "token");
      var body = {"salCodes": "$salCode", "empGrade": "$empGrade"};
      print(body);
      print("${config?[baseUrl]}hhReimb/getReimbElg");
      var headers = {
        'Authorization':
            'Bearer $token',
        'Content-Type': 'application/json',
      };
      var request = http.Request(
          'POST',
          Uri.parse(
              '${config?[baseUrl]}hhReimb/getReimbElg'));
      request.body = json.encode(body);
      request.headers.addAll(headers);
      http.StreamedResponse response = await request.send();

      if (response.statusCode == 200) {
        return response;
      } else {
        print(response.reasonPhrase);
      }
    } catch (e) {}
  }

  getReimbElgg() async{
    var salCode = await helper.getSharedPrefString(keyName: "userid");
      var empGrade = await helper.getSharedPrefString(keyName: "empGrade");
      var token = await helper.getSharedPrefString(keyName: "token");
      var body = {"salCodes": "$salCode", "empGrade": "$empGrade"};
      var res = await helper.postNew(data: body, url: "hhReimb/getReimbElg",tokenRequired: true);
      return res;
  }

  getBookingList() async{
    try{
      var userid = await helper.getSharedPrefString(keyName: "userid");
      var res = await helper.getService("hhReimb/getHhList/$userid");
      return res;
    }catch(e){

    }
  }
}
