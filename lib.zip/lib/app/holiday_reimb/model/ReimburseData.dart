class ReimburseData {
  ReimburseData({
      this.appNo, 
      this.holidayHome, 
      this.fromDate, 
      this.endDate, 
      this.noOfNights, 
      this.totalEligibleAmount, 
      this.totalClaimAmount, 
      this.totalPayableAmount, 
      this.status, 
      this.tokenStatus,});

  ReimburseData.fromJson(dynamic json) {
    appNo = json['appNo'];
    holidayHome = json['holidayHome'];
    fromDate = json['fromDate'];
    endDate = json['endDate'];
    noOfNights = json['noOfNights'];
    totalEligibleAmount = json['totalEligibleAmount'];
    totalClaimAmount = json['totalClaimAmount'];
    totalPayableAmount = json['totalPayableAmount'];
    status = json['status'];
    tokenStatus = json['tokenStatus'];
  }
  String? appNo;
  String? holidayHome;
  String? fromDate;
  String? endDate;
  String? noOfNights;
  String? totalEligibleAmount;
  String? totalClaimAmount;
  String? totalPayableAmount;
  String? status;
  dynamic tokenStatus;
ReimburseData copyWith({  String? appNo,
  String? holidayHome,
  String? fromDate,
  String? endDate,
  String? noOfNights,
  String? totalEligibleAmount,
  String? totalClaimAmount,
  String? totalPayableAmount,
  String? status,
  dynamic tokenStatus,
}) => ReimburseData(  appNo: appNo ?? this.appNo,
  holidayHome: holidayHome ?? this.holidayHome,
  fromDate: fromDate ?? this.fromDate,
  endDate: endDate ?? this.endDate,
  noOfNights: noOfNights ?? this.noOfNights,
  totalEligibleAmount: totalEligibleAmount ?? this.totalEligibleAmount,
  totalClaimAmount: totalClaimAmount ?? this.totalClaimAmount,
  totalPayableAmount: totalPayableAmount ?? this.totalPayableAmount,
  status: status ?? this.status,
  tokenStatus: tokenStatus ?? this.tokenStatus,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['appNo'] = appNo;
    map['holidayHome'] = holidayHome;
    map['fromDate'] = fromDate;
    map['endDate'] = endDate;
    map['noOfNights'] = noOfNights;
    map['totalEligibleAmount'] = totalEligibleAmount;
    map['totalClaimAmount'] = totalClaimAmount;
    map['totalPayableAmount'] = totalPayableAmount;
    map['status'] = status;
    map['tokenStatus'] = tokenStatus;
    return map;
  }

}