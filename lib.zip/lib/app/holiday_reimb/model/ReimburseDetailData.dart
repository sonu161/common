class ReimburseDetailData {
  ReimburseDetailData({
      this.holidayHomeReimDtlPK, 
      this.roomTally, 
      this.foodBill, 
      this.hotelGstRate, 
      this.foodGstRate, 
      this.hotelGstAmount, 
      this.foodGstAmount, 
      this.totalGstAmount, 
      this.eligibleAmount, 
      this.fromDate, 
      this.toDate, 
      this.hotelName, 
      this.noOfRooms, 
      this.totalDays, 
      this.totalAmount, 
      this.empCode, 
      this.totalPayableAmount, 
      this.appNo, 
      this.tokenStatus, 
      this.serialNumber, 
      this.convertedFromDate, 
      this.convertedToDate,});

  ReimburseDetailData.fromJson(dynamic json) {
    holidayHomeReimDtlPK = json['holidayHomeReimDtlPK'];
    roomTally = json['roomTally'];
    foodBill = json['foodBill'];
    hotelGstRate = json['hotelGstRate'];
    foodGstRate = json['foodGstRate'];
    hotelGstAmount = json['hotelGstAmount'];
    foodGstAmount = json['foodGstAmount'];
    totalGstAmount = json['totalGstAmount'];
    eligibleAmount = json['eligibleAmount'];
    fromDate = json['fromDate'];
    toDate = json['toDate'];
    hotelName = json['hotelName'];
    noOfRooms = json['noOfRooms'];
    totalDays = json['totalDays'];
    totalAmount = json['totalAmount'];
    empCode = json['empCode'];
    totalPayableAmount = json['totalPayableAmount'];
    appNo = json['appNo'];
    tokenStatus = json['tokenStatus'];
    serialNumber = json['serialNumber'];
    convertedFromDate = json['convertedFromDate'];
    convertedToDate = json['convertedToDate'];
  }
  dynamic holidayHomeReimDtlPK;
  String? roomTally;
  String? foodBill;
  String? hotelGstRate;
  String? foodGstRate;
  String? hotelGstAmount;
  String? foodGstAmount;
  String? totalGstAmount;
  String? eligibleAmount;
  dynamic fromDate;
  dynamic toDate;
  String? hotelName;
  String? noOfRooms;
  dynamic totalDays;
  String? totalAmount;
  String? empCode;
  String? totalPayableAmount;
  String? appNo;
  dynamic tokenStatus;
  String? serialNumber;
  String? convertedFromDate;
  String? convertedToDate;
ReimburseDetailData copyWith({  dynamic holidayHomeReimDtlPK,
  String? roomTally,
  String? foodBill,
  String? hotelGstRate,
  String? foodGstRate,
  String? hotelGstAmount,
  String? foodGstAmount,
  String? totalGstAmount,
  String? eligibleAmount,
  dynamic fromDate,
  dynamic toDate,
  String? hotelName,
  String? noOfRooms,
  dynamic totalDays,
  String? totalAmount,
  String? empCode,
  String? totalPayableAmount,
  String? appNo,
  dynamic tokenStatus,
  String? serialNumber,
  String? convertedFromDate,
  String? convertedToDate,
}) => ReimburseDetailData(  holidayHomeReimDtlPK: holidayHomeReimDtlPK ?? this.holidayHomeReimDtlPK,
  roomTally: roomTally ?? this.roomTally,
  foodBill: foodBill ?? this.foodBill,
  hotelGstRate: hotelGstRate ?? this.hotelGstRate,
  foodGstRate: foodGstRate ?? this.foodGstRate,
  hotelGstAmount: hotelGstAmount ?? this.hotelGstAmount,
  foodGstAmount: foodGstAmount ?? this.foodGstAmount,
  totalGstAmount: totalGstAmount ?? this.totalGstAmount,
  eligibleAmount: eligibleAmount ?? this.eligibleAmount,
  fromDate: fromDate ?? this.fromDate,
  toDate: toDate ?? this.toDate,
  hotelName: hotelName ?? this.hotelName,
  noOfRooms: noOfRooms ?? this.noOfRooms,
  totalDays: totalDays ?? this.totalDays,
  totalAmount: totalAmount ?? this.totalAmount,
  empCode: empCode ?? this.empCode,
  totalPayableAmount: totalPayableAmount ?? this.totalPayableAmount,
  appNo: appNo ?? this.appNo,
  tokenStatus: tokenStatus ?? this.tokenStatus,
  serialNumber: serialNumber ?? this.serialNumber,
  convertedFromDate: convertedFromDate ?? this.convertedFromDate,
  convertedToDate: convertedToDate ?? this.convertedToDate,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['holidayHomeReimDtlPK'] = holidayHomeReimDtlPK;
    map['roomTally'] = roomTally;
    map['foodBill'] = foodBill;
    map['hotelGstRate'] = hotelGstRate;
    map['foodGstRate'] = foodGstRate;
    map['hotelGstAmount'] = hotelGstAmount;
    map['foodGstAmount'] = foodGstAmount;
    map['totalGstAmount'] = totalGstAmount;
    map['eligibleAmount'] = eligibleAmount;
    map['fromDate'] = fromDate;
    map['toDate'] = toDate;
    map['hotelName'] = hotelName;
    map['noOfRooms'] = noOfRooms;
    map['totalDays'] = totalDays;
    map['totalAmount'] = totalAmount;
    map['empCode'] = empCode;
    map['totalPayableAmount'] = totalPayableAmount;
    map['appNo'] = appNo;
    map['tokenStatus'] = tokenStatus;
    map['serialNumber'] = serialNumber;
    map['convertedFromDate'] = convertedFromDate;
    map['convertedToDate'] = convertedToDate;
    return map;
  }

}