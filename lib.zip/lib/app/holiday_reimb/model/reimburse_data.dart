class HolidayData {
  String? roomTarrif;
  String? foodBill;
  String? eligibleAmt;
  String? hotelGstRate;
  String? foodGstRate;
  String? hotelGstAmt;
  String? foodGstAmt;
  String? totalGstAmt;
  String? hotelName;
  String? startDate;
  String? endDate;
  String? noOfDays;
  String? totalEligibleAmt;
  String? totalPayAmy;
  String? totalHotelFoodAmt;

  HolidayData({
    this.roomTarrif,
    this.foodBill,
    this.eligibleAmt,
    this.hotelGstRate,
    this.foodGstRate,
    this.hotelGstAmt,
    this.foodGstAmt,
    this.totalGstAmt,
    this.hotelName,
    this.startDate,
    this.endDate,
    this.noOfDays,
    this.totalEligibleAmt,
    this.totalPayAmy,
    this.totalHotelFoodAmt,
  });

  HolidayData copyWith({
    String? roomTarrif,
    String? foodBill,
    String? eligibleAmt,
    String? hotelGstRate,
    String? foodGstRate,
    String? hotelGstAmt,
    String? foodGstAmt,
    String? totalGstAmt,
    String? hotelName,
    String? startDate,
    String? endDate,
    String? noOfDays,
    String? totalEligibleAmt,
    String? totalPayAmy,
    String? totalHotelFoodAmt,
  }) =>
      HolidayData(
        roomTarrif: roomTarrif ?? this.roomTarrif,
        foodBill: foodBill ?? this.foodBill,
        eligibleAmt: eligibleAmt ?? this.eligibleAmt,
        hotelGstRate: hotelGstRate ?? this.hotelGstRate,
        foodGstRate: foodGstRate ?? this.foodGstRate,
        hotelGstAmt: hotelGstAmt ?? this.hotelGstAmt,
        foodGstAmt: foodGstAmt ?? this.foodGstAmt,
        totalGstAmt: totalGstAmt ?? this.totalGstAmt,
        hotelName: hotelName ?? this.hotelName,
        startDate: startDate ?? this.startDate,
        endDate: endDate ?? this.endDate,
        noOfDays: noOfDays ?? this.noOfDays,
        totalEligibleAmt: totalEligibleAmt ?? this.totalEligibleAmt,
        totalPayAmy: totalPayAmy ?? this.totalPayAmy,
        totalHotelFoodAmt: totalHotelFoodAmt ?? this.totalHotelFoodAmt,
      );
}
